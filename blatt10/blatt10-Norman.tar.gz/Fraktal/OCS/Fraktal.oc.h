

#ifndef AFraktal_included
#define AFraktal_included

#define __AFraktal_Afraktal __AFraktal_1
extern OBJ __AFraktal_Afraktal;

#define __AFraktal_Aexit __AFraktal_3
extern OBJ __AFraktal_Aexit;

#define __AFraktal_Aexit_ __AFraktal_4
#define _AFraktal_Aexit_ _AFraktal_4
extern OBJ __AFraktal_Aexit_;
extern OBJ _AFraktal_Aexit_(OBJ);

#define __AFraktal_Atriangle __AFraktal_6
#define _AFraktal_Atriangle _AFraktal_6
extern OBJ __AFraktal_Atriangle;
extern OBJ _AFraktal_Atriangle(OBJ,OBJ,OBJ);

#define __AFraktal_Atriangle_ __AFraktal_7
#define _AFraktal_Atriangle_ _AFraktal_7
extern OBJ __AFraktal_Atriangle_;
extern OBJ _AFraktal_Atriangle_(OBJ);

#define __AFraktal_Ap3 __AFraktal_8
#define _AFraktal_Ap3 _AFraktal_8
extern OBJ __AFraktal_Ap3;
extern OBJ _AFraktal_Ap3(OBJ);

#define __AFraktal_Ap2 __AFraktal_9
#define _AFraktal_Ap2 _AFraktal_9
extern OBJ __AFraktal_Ap2;
extern OBJ _AFraktal_Ap2(OBJ);

#define __AFraktal_Ap1 __AFraktal_10
#define _AFraktal_Ap1 _AFraktal_10
extern OBJ __AFraktal_Ap1;
extern OBJ _AFraktal_Ap1(OBJ);

#define __AFraktal_Agui __AFraktal_12
#define _AFraktal_Agui _AFraktal_12
extern OBJ __AFraktal_Agui;
extern OBJ _AFraktal_Agui(OBJ,OBJ,OBJ,OBJ);

#define __AFraktal_Agui_ __AFraktal_13
#define _AFraktal_Agui_ _AFraktal_13
extern OBJ __AFraktal_Agui_;
extern OBJ _AFraktal_Agui_(OBJ);

#define __AFraktal_Agrad __AFraktal_14
#define _AFraktal_Agrad _AFraktal_14
extern OBJ __AFraktal_Agrad;
extern OBJ _AFraktal_Agrad(OBJ);

#define __AFraktal_Atitle __AFraktal_15
#define _AFraktal_Atitle _AFraktal_15
extern OBJ __AFraktal_Atitle;
extern OBJ _AFraktal_Atitle(OBJ);

#define __AFraktal_Aemit __AFraktal_16
#define _AFraktal_Aemit _AFraktal_16
extern OBJ __AFraktal_Aemit;
extern OBJ _AFraktal_Aemit(OBJ);

#define __AFraktal_Aedit __AFraktal_17
#define _AFraktal_Aedit _AFraktal_17
extern OBJ __AFraktal_Aedit;
extern OBJ _AFraktal_Aedit(OBJ);

#define __AFraktal_AsetupGui __AFraktal_18
#define _AFraktal_AsetupGui _AFraktal_18
extern OBJ __AFraktal_AsetupGui;
extern OBJ _AFraktal_AsetupGui(OBJ);

#define __AFraktal_AsetupWindow __AFraktal_19
#define _AFraktal_AsetupWindow _AFraktal_19
extern OBJ __AFraktal_AsetupWindow;
extern OBJ _AFraktal_AsetupWindow(OBJ);

#define __AFraktal_AwaitForTermination __AFraktal_20
#define _AFraktal_AwaitForTermination _AFraktal_20
extern OBJ __AFraktal_AwaitForTermination;
extern OBJ _AFraktal_AwaitForTermination(OBJ,OBJ);

#define __AFraktal_AdisplayTriangles __AFraktal_21
#define _AFraktal_AdisplayTriangles _AFraktal_21
extern OBJ __AFraktal_AdisplayTriangles;
extern OBJ _AFraktal_AdisplayTriangles(OBJ);

#define __AFraktal_AdrawTriangles __AFraktal_22
#define _AFraktal_AdrawTriangles _AFraktal_22
extern OBJ __AFraktal_AdrawTriangles;
extern OBJ _AFraktal_AdrawTriangles(OBJ);

#define __AFraktal_AremoveCenterTriangle __AFraktal_23
#define _AFraktal_AremoveCenterTriangle _AFraktal_23
extern OBJ __AFraktal_AremoveCenterTriangle;
extern OBJ _AFraktal_AremoveCenterTriangle(OBJ,OBJ);

#define __AFraktal_AdrawTriangle __AFraktal_24
#define _AFraktal_AdrawTriangle _AFraktal_24
extern OBJ __AFraktal_AdrawTriangle;
extern OBJ _AFraktal_AdrawTriangle(OBJ,OBJ);

#define __AFraktal_AhalveCoordinates __AFraktal_25
#define _AFraktal_AhalveCoordinates _AFraktal_25
extern OBJ __AFraktal_AhalveCoordinates;
extern OBJ _AFraktal_AhalveCoordinates(OBJ);

#define __AFraktal_Aframe __AFraktal_26
#define _AFraktal_Aframe _AFraktal_26
extern OBJ __AFraktal_Aframe;
extern OBJ _AFraktal_Aframe(OBJ);

#define __AFraktal_Apad __AFraktal_27
#define _AFraktal_Apad _AFraktal_27
extern OBJ __AFraktal_Apad;
extern OBJ _AFraktal_Apad(OBJ);

#define __AFraktal_AexitButton __AFraktal_28
#define _AFraktal_AexitButton _AFraktal_28
extern OBJ __AFraktal_AexitButton;
extern OBJ _AFraktal_AexitButton(OBJ);

#define __AFraktal_AcanvasWidth __AFraktal_29
extern OBJ __AFraktal_AcanvasWidth;

#define __AFraktal_AcanvasHeight __AFraktal_30
extern OBJ __AFraktal_AcanvasHeight;

#define __AFraktal_AcanvasSize __AFraktal_31
extern OBJ __AFraktal_AcanvasSize;

#define __AFraktal_AsideLength __AFraktal_32
extern OBJ __AFraktal_AsideLength;

#define __AFraktal_AcanvasBackground __AFraktal_33
extern OBJ __AFraktal_AcanvasBackground;

#define __AFraktal_Acolor1 __AFraktal_34
extern OBJ __AFraktal_Acolor1;

#define __AFraktal_Acolor2 __AFraktal_35
extern OBJ __AFraktal_Acolor2;

#define __AFraktal_AfirstTriangle __AFraktal_36
extern OBJ __AFraktal_AfirstTriangle;

#ifndef AFraktal_Aexit_
#define AFraktal_Aexit_(x1,x2) {x2=_AFraktal_Aexit_(x1);}
#endif

#ifndef AFraktal_Atriangle
#define AFraktal_Atriangle(x1,x2,x3,x4) {x4=_AFraktal_Atriangle(x1,x2,x3);}
#endif

#ifndef AFraktal_Atriangle_
#define AFraktal_Atriangle_(x1,x2) {x2=_AFraktal_Atriangle_(x1);}
#endif

#ifndef AFraktal_Ap3
#define AFraktal_Ap3(x1,x5) {x5=_AFraktal_Ap3(x1);}
#endif

#ifndef AFraktal_Ap2
#define AFraktal_Ap2(x1,x5) {x5=_AFraktal_Ap2(x1);}
#endif

#ifndef AFraktal_Ap1
#define AFraktal_Ap1(x1,x5) {x5=_AFraktal_Ap1(x1);}
#endif

#ifndef AFraktal_Agui
#define AFraktal_Agui(x1,x2,x3,x4,x5) {x5=_AFraktal_Agui(x1,x2,x3,x4);}
#endif

#ifndef AFraktal_Agui_
#define AFraktal_Agui_(x1,x2) {x2=_AFraktal_Agui_(x1);}
#endif

#ifndef AFraktal_Agrad
#define AFraktal_Agrad(x1,x6) {x6=_AFraktal_Agrad(x1);}
#endif

#ifndef AFraktal_Atitle
#define AFraktal_Atitle(x1,x6) {x6=_AFraktal_Atitle(x1);}
#endif

#ifndef AFraktal_Aemit
#define AFraktal_Aemit(x1,x6) {x6=_AFraktal_Aemit(x1);}
#endif

#ifndef AFraktal_Aedit
#define AFraktal_Aedit(x1,x6) {x6=_AFraktal_Aedit(x1);}
#endif

#ifndef AFraktal_AsetupGui
#define AFraktal_AsetupGui(x1,x3) {x3=_AFraktal_AsetupGui(x1);}
#endif

#ifndef AFraktal_AsetupWindow
#define AFraktal_AsetupWindow(x1,x5) {x5=_AFraktal_AsetupWindow(x1);}
#endif

#ifndef AFraktal_AwaitForTermination
#define AFraktal_AwaitForTermination(x1,x2,x6) {x6=_AFraktal_AwaitForTermination(x1,x2);}
#endif

#ifndef AFraktal_AdisplayTriangles
#define AFraktal_AdisplayTriangles(x1,x5) {x5=_AFraktal_AdisplayTriangles(x1);}
#endif

#ifndef AFraktal_AdrawTriangles
#define AFraktal_AdrawTriangles(x1,x4) {x4=_AFraktal_AdrawTriangles(x1);}
#endif

#ifndef AFraktal_AremoveCenterTriangle
#define AFraktal_AremoveCenterTriangle(x1,x2,x82) {x82=_AFraktal_AremoveCenterTriangle(x1,x2);}
#endif

#ifndef AFraktal_AdrawTriangle
#define AFraktal_AdrawTriangle(x1,x2,x9) {x9=_AFraktal_AdrawTriangle(x1,x2);}
#endif

#ifndef AFraktal_AhalveCoordinates
#define AFraktal_AhalveCoordinates(x1,x7) {x7=_AFraktal_AhalveCoordinates(x1);}
#endif

#ifndef AFraktal_Aframe
#define AFraktal_Aframe(x1,x6) {x6=_AFraktal_Aframe(x1);}
#endif

#ifndef AFraktal_Apad
#define AFraktal_Apad(x1,x7) {x7=_AFraktal_Apad(x1);}
#endif

#ifndef AFraktal_AexitButton
#define AFraktal_AexitButton(x1,x5) {x5=_AFraktal_AexitButton(x1);}
#endif

#ifndef AFraktal_Afraktal_L38
#define AFraktal_Afraktal_L38(x1,x2,x5) {x5=_AFraktal_Afraktal_L38(x1,x2);}
#endif

#ifndef AFraktal_Afraktal_L39
#define AFraktal_Afraktal_L39(x1,x4) {x4=_AFraktal_Afraktal_L39(x1);}
#endif

#ifndef AFraktal_Afraktal_L40
#define AFraktal_Afraktal_L40(x1,x2,x5) {x5=_AFraktal_Afraktal_L40(x1,x2);}
#endif

#ifndef AFraktal_Afraktal_L41
#define AFraktal_Afraktal_L41(x1,x4) {x4=_AFraktal_Afraktal_L41(x1);}
#endif

#ifndef AFraktal_Afraktal_L42
#define AFraktal_Afraktal_L42(x1,x3) {x3=_AFraktal_Afraktal_L42(x1);}
#endif

#ifndef AFraktal_Afraktal_L43
#define AFraktal_Afraktal_L43(x1,x5) {x5=_AFraktal_Afraktal_L43(x1);}
#endif

#ifndef AFraktal_AsetupGui_L45
#define AFraktal_AsetupGui_L45(x1,x2,x3,x6) {x6=_AFraktal_AsetupGui_L45(x1,x2,x3);}
#endif

#ifndef AFraktal_AsetupGui_L46
#define AFraktal_AsetupGui_L46(x1,x2,x4) {x4=_AFraktal_AsetupGui_L46(x1,x2);}
#endif

#ifndef AFraktal_AsetupWindow_L47
#define AFraktal_AsetupWindow_L47(x1,x2,x3) {x3=_AFraktal_AsetupWindow_L47(x1,x2);}
#endif

#ifndef AFraktal_AsetupWindow_L48
#define AFraktal_AsetupWindow_L48(x1,x2,x5) {x5=_AFraktal_AsetupWindow_L48(x1,x2);}
#endif

#ifndef AFraktal_AsetupWindow_L49
#define AFraktal_AsetupWindow_L49(x1,x2,x7) {x7=_AFraktal_AsetupWindow_L49(x1,x2);}
#endif

#ifndef AFraktal_AwaitForTermination_L50
#define AFraktal_AwaitForTermination_L50(x1,x2,x8) {x8=_AFraktal_AwaitForTermination_L50(x1,x2);}
#endif

#endif
