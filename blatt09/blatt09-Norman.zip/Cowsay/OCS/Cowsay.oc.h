

#ifndef ACowsay_included
#define ACowsay_included

#define __ACowsay_Acowsay __ACowsay_1
extern OBJ __ACowsay_Acowsay;

#define __ACowsay_Aart __ACowsay_2
#define _ACowsay_Aart _ACowsay_2
extern OBJ __ACowsay_Aart;
extern OBJ _ACowsay_Aart(OBJ);

#ifndef ACowsay_Aart
#define ACowsay_Aart(x1,x33) {x33=_ACowsay_Aart(x1);}
#endif

#ifndef ACowsay_Acowsay_L5
#define ACowsay_Acowsay_L5(x1,x7) {x7=_ACowsay_Acowsay_L5(x1);}
#endif

#ifndef ACowsay_Aart_L35
#define ACowsay_Aart_L35(x1,x2,x5) {x5=_ACowsay_Aart_L35(x1,x2);}
#endif

#endif
