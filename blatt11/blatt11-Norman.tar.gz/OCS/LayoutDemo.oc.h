

#ifndef ALayoutDemo_included
#define ALayoutDemo_included

#define __ALayoutDemo_AlayoutDemo __ALayoutDemo_1
extern OBJ __ALayoutDemo_AlayoutDemo;

#define __ALayoutDemo_Aexit __ALayoutDemo_3
extern OBJ __ALayoutDemo_Aexit;

#define __ALayoutDemo_Aexit_ __ALayoutDemo_4
#define _ALayoutDemo_Aexit_ _ALayoutDemo_4
extern OBJ __ALayoutDemo_Aexit_;
extern OBJ _ALayoutDemo_Aexit_(OBJ);

#define __ALayoutDemo_Agui __ALayoutDemo_6
#define _ALayoutDemo_Agui _ALayoutDemo_6
extern OBJ __ALayoutDemo_Agui;
extern OBJ _ALayoutDemo_Agui(OBJ,OBJ,OBJ);

#define __ALayoutDemo_Agui_ __ALayoutDemo_7
#define _ALayoutDemo_Agui_ _ALayoutDemo_7
extern OBJ __ALayoutDemo_Agui_;
extern OBJ _ALayoutDemo_Agui_(OBJ);

#define __ALayoutDemo_Atitle __ALayoutDemo_8
#define _ALayoutDemo_Atitle _ALayoutDemo_8
extern OBJ __ALayoutDemo_Atitle;
extern OBJ _ALayoutDemo_Atitle(OBJ);

#define __ALayoutDemo_Aemit __ALayoutDemo_9
#define _ALayoutDemo_Aemit _ALayoutDemo_9
extern OBJ __ALayoutDemo_Aemit;
extern OBJ _ALayoutDemo_Aemit(OBJ);

#define __ALayoutDemo_Aedit __ALayoutDemo_10
#define _ALayoutDemo_Aedit _ALayoutDemo_10
extern OBJ __ALayoutDemo_Aedit;
extern OBJ _ALayoutDemo_Aedit(OBJ);

#define __ALayoutDemo_Ainfo __ALayoutDemo_12
#define _ALayoutDemo_Ainfo _ALayoutDemo_12
extern OBJ __ALayoutDemo_Ainfo;
extern OBJ _ALayoutDemo_Ainfo(OBJ,OBJ);

#define __ALayoutDemo_Ainfo_ __ALayoutDemo_13
#define _ALayoutDemo_Ainfo_ _ALayoutDemo_13
extern OBJ __ALayoutDemo_Ainfo_;
extern OBJ _ALayoutDemo_Ainfo_(OBJ);

#define __ALayoutDemo_AargInfo __ALayoutDemo_14
#define _ALayoutDemo_AargInfo _ALayoutDemo_14
extern OBJ __ALayoutDemo_AargInfo;
extern OBJ _ALayoutDemo_AargInfo(OBJ);

#define __ALayoutDemo_AguiInfo __ALayoutDemo_15
#define _ALayoutDemo_AguiInfo _ALayoutDemo_15
extern OBJ __ALayoutDemo_AguiInfo;
extern OBJ _ALayoutDemo_AguiInfo(OBJ);

#define __ALayoutDemo_Aboxes __ALayoutDemo_17
#define _ALayoutDemo_Aboxes _ALayoutDemo_17
extern OBJ __ALayoutDemo_Aboxes;
extern OBJ _ALayoutDemo_Aboxes(OBJ,OBJ);

#define __ALayoutDemo_Aboxes_ __ALayoutDemo_18
#define _ALayoutDemo_Aboxes_ _ALayoutDemo_18
extern OBJ __ALayoutDemo_Aboxes_;
extern OBJ _ALayoutDemo_Aboxes_(OBJ);

#define __ALayoutDemo_Awidths __ALayoutDemo_19
#define _ALayoutDemo_Awidths _ALayoutDemo_19
extern OBJ __ALayoutDemo_Awidths;
extern OBJ _ALayoutDemo_Awidths(OBJ);

#define __ALayoutDemo_Aaligns __ALayoutDemo_20
#define _ALayoutDemo_Aaligns _ALayoutDemo_20
extern OBJ __ALayoutDemo_Aaligns;
extern OBJ _ALayoutDemo_Aaligns(OBJ);

#define __ALayoutDemo_Aright __ALayoutDemo_22
extern OBJ __ALayoutDemo_Aright;

#define __ALayoutDemo_Aright_ __ALayoutDemo_23
#define _ALayoutDemo_Aright_ _ALayoutDemo_23
extern OBJ __ALayoutDemo_Aright_;
extern OBJ _ALayoutDemo_Aright_(OBJ);

#define __ALayoutDemo_Acenter __ALayoutDemo_24
extern OBJ __ALayoutDemo_Acenter;

#define __ALayoutDemo_Acenter_ __ALayoutDemo_25
#define _ALayoutDemo_Acenter_ _ALayoutDemo_25
extern OBJ __ALayoutDemo_Acenter_;
extern OBJ _ALayoutDemo_Acenter_(OBJ);

#define __ALayoutDemo_Aleft __ALayoutDemo_26
extern OBJ __ALayoutDemo_Aleft;

#define __ALayoutDemo_Aleft_ __ALayoutDemo_27
#define _ALayoutDemo_Aleft_ _ALayoutDemo_27
extern OBJ __ALayoutDemo_Aleft_;
extern OBJ _ALayoutDemo_Aleft_(OBJ);

#define __ALayoutDemo_Ainitialize __ALayoutDemo_28
extern OBJ __ALayoutDemo_Ainitialize;

#define __ALayoutDemo_AsetupWindow __ALayoutDemo_29
#define _ALayoutDemo_AsetupWindow _ALayoutDemo_29
extern OBJ __ALayoutDemo_AsetupWindow;
extern OBJ _ALayoutDemo_AsetupWindow(OBJ);

#define __ALayoutDemo_Ausage __ALayoutDemo_30
#define _ALayoutDemo_Ausage _ALayoutDemo_30
extern OBJ __ALayoutDemo_Ausage;
extern OBJ _ALayoutDemo_Ausage(OBJ);

#define __ALayoutDemo_AgetAlign __ALayoutDemo_31
#define _ALayoutDemo_AgetAlign _ALayoutDemo_31
extern OBJ __ALayoutDemo_AgetAlign;
extern OBJ _ALayoutDemo_AgetAlign(OBJ);

#define __ALayoutDemo_AisDenAlign __ALayoutDemo_32
#define _ALayoutDemo_AisDenAlign _ALayoutDemo_32
extern OBJ __ALayoutDemo_AisDenAlign;
extern OBJ _ALayoutDemo_AisDenAlign(OBJ);

#define __ALayoutDemo_AprocArgSeq __ALayoutDemo_33
#define _ALayoutDemo_AprocArgSeq _ALayoutDemo_33
extern OBJ __ALayoutDemo_AprocArgSeq;
extern OBJ _ALayoutDemo_AprocArgSeq(OBJ);

#define __ALayoutDemo_AprocessArgs __ALayoutDemo_34
extern OBJ __ALayoutDemo_AprocessArgs;

#define __ALayoutDemo_AdrawLayout __ALayoutDemo_35
#define _ALayoutDemo_AdrawLayout _ALayoutDemo_35
extern OBJ __ALayoutDemo_AdrawLayout;
extern OBJ _ALayoutDemo_AdrawLayout(OBJ);

#define __ALayoutDemo_AleftX __ALayoutDemo_36
#define _ALayoutDemo_AleftX _ALayoutDemo_36
extern OBJ __ALayoutDemo_AleftX;
extern OBJ _ALayoutDemo_AleftX(OBJ,OBJ);

#define __ALayoutDemo_Apicture __ALayoutDemo_37
#define _ALayoutDemo_Apicture _ALayoutDemo_37
extern OBJ __ALayoutDemo_Apicture;
extern OBJ _ALayoutDemo_Apicture(OBJ);

#define __ALayoutDemo_AhandleEmits __ALayoutDemo_38
#define _ALayoutDemo_AhandleEmits _ALayoutDemo_38
extern OBJ __ALayoutDemo_AhandleEmits;
extern OBJ _ALayoutDemo_AhandleEmits(OBJ,OBJ);

#define __ALayoutDemo_Aframe __ALayoutDemo_39
#define _ALayoutDemo_Aframe _ALayoutDemo_39
extern OBJ __ALayoutDemo_Aframe;
extern OBJ _ALayoutDemo_Aframe(OBJ);

#define __ALayoutDemo_Apad __ALayoutDemo_40
#define _ALayoutDemo_Apad _ALayoutDemo_40
extern OBJ __ALayoutDemo_Apad;
extern OBJ _ALayoutDemo_Apad(OBJ);

#define __ALayoutDemo_AexitButton __ALayoutDemo_41
#define _ALayoutDemo_AexitButton _ALayoutDemo_41
extern OBJ __ALayoutDemo_AexitButton;
extern OBJ _ALayoutDemo_AexitButton(OBJ);

#define __ALayoutDemo_AcanvasWidth __ALayoutDemo_42
extern OBJ __ALayoutDemo_AcanvasWidth;

#define __ALayoutDemo_AcanvasHeight __ALayoutDemo_43
extern OBJ __ALayoutDemo_AcanvasHeight;

#define __ALayoutDemo_AcanvasSize __ALayoutDemo_44
extern OBJ __ALayoutDemo_AcanvasSize;

#define __ALayoutDemo_Amargin __ALayoutDemo_45
extern OBJ __ALayoutDemo_Amargin;

#define __ALayoutDemo_Atop __ALayoutDemo_46
extern OBJ __ALayoutDemo_Atop;

#define __ALayoutDemo_Abottom __ALayoutDemo_47
extern OBJ __ALayoutDemo_Abottom;

#define __ALayoutDemo_Aleft_O1 __ALayoutDemo_48
extern OBJ __ALayoutDemo_Aleft_O1;

#define __ALayoutDemo_Aright_O1 __ALayoutDemo_49
extern OBJ __ALayoutDemo_Aright_O1;

#ifndef ALayoutDemo_Aexit_
#define ALayoutDemo_Aexit_(x1,x2) {x2=_ALayoutDemo_Aexit_(x1);}
#endif

#ifndef ALayoutDemo_Agui
#define ALayoutDemo_Agui(x1,x2,x3,x4) {x4=_ALayoutDemo_Agui(x1,x2,x3);}
#endif

#ifndef ALayoutDemo_Agui_
#define ALayoutDemo_Agui_(x1,x2) {x2=_ALayoutDemo_Agui_(x1);}
#endif

#ifndef ALayoutDemo_Atitle
#define ALayoutDemo_Atitle(x1,x5) {x5=_ALayoutDemo_Atitle(x1);}
#endif

#ifndef ALayoutDemo_Aemit
#define ALayoutDemo_Aemit(x1,x5) {x5=_ALayoutDemo_Aemit(x1);}
#endif

#ifndef ALayoutDemo_Aedit
#define ALayoutDemo_Aedit(x1,x5) {x5=_ALayoutDemo_Aedit(x1);}
#endif

#ifndef ALayoutDemo_Ainfo
#define ALayoutDemo_Ainfo(x1,x2,x3) {x3=_ALayoutDemo_Ainfo(x1,x2);}
#endif

#ifndef ALayoutDemo_Ainfo_
#define ALayoutDemo_Ainfo_(x1,x2) {x2=_ALayoutDemo_Ainfo_(x1);}
#endif

#ifndef ALayoutDemo_AargInfo
#define ALayoutDemo_AargInfo(x1,x4) {x4=_ALayoutDemo_AargInfo(x1);}
#endif

#ifndef ALayoutDemo_AguiInfo
#define ALayoutDemo_AguiInfo(x1,x4) {x4=_ALayoutDemo_AguiInfo(x1);}
#endif

#ifndef ALayoutDemo_Aboxes
#define ALayoutDemo_Aboxes(x1,x2,x3) {x3=_ALayoutDemo_Aboxes(x1,x2);}
#endif

#ifndef ALayoutDemo_Aboxes_
#define ALayoutDemo_Aboxes_(x1,x2) {x2=_ALayoutDemo_Aboxes_(x1);}
#endif

#ifndef ALayoutDemo_Awidths
#define ALayoutDemo_Awidths(x1,x4) {x4=_ALayoutDemo_Awidths(x1);}
#endif

#ifndef ALayoutDemo_Aaligns
#define ALayoutDemo_Aaligns(x1,x4) {x4=_ALayoutDemo_Aaligns(x1);}
#endif

#ifndef ALayoutDemo_Aright_
#define ALayoutDemo_Aright_(x1,x2) {x2=_ALayoutDemo_Aright_(x1);}
#endif

#ifndef ALayoutDemo_Acenter_
#define ALayoutDemo_Acenter_(x1,x2) {x2=_ALayoutDemo_Acenter_(x1);}
#endif

#ifndef ALayoutDemo_Aleft_
#define ALayoutDemo_Aleft_(x1,x2) {x2=_ALayoutDemo_Aleft_(x1);}
#endif

#ifndef ALayoutDemo_AsetupWindow
#define ALayoutDemo_AsetupWindow(x1,x7) {x7=_ALayoutDemo_AsetupWindow(x1);}
#endif

#ifndef ALayoutDemo_Ausage
#define ALayoutDemo_Ausage(x1,x4) {x4=_ALayoutDemo_Ausage(x1);}
#endif

#ifndef ALayoutDemo_AgetAlign
#define ALayoutDemo_AgetAlign(x1,x5) {x5=_ALayoutDemo_AgetAlign(x1);}
#endif

#ifndef ALayoutDemo_AisDenAlign
#define ALayoutDemo_AisDenAlign(x1,x7) {x7=_ALayoutDemo_AisDenAlign(x1);}
#endif

#ifndef ALayoutDemo_AprocArgSeq
#define ALayoutDemo_AprocArgSeq(x1,x6) {x6=_ALayoutDemo_AprocArgSeq(x1);}
#endif

#ifndef ALayoutDemo_AdrawLayout
#define ALayoutDemo_AdrawLayout(x1,x6) {x6=_ALayoutDemo_AdrawLayout(x1);}
#endif

#ifndef ALayoutDemo_AleftX
#define ALayoutDemo_AleftX(x1,x2,x7) {x7=_ALayoutDemo_AleftX(x1,x2);}
#endif

#ifndef ALayoutDemo_Apicture
#define ALayoutDemo_Apicture(x1,x16) {x16=_ALayoutDemo_Apicture(x1);}
#endif

#ifndef ALayoutDemo_AhandleEmits
#define ALayoutDemo_AhandleEmits(x1,x2,x7) {x7=_ALayoutDemo_AhandleEmits(x1,x2);}
#endif

#ifndef ALayoutDemo_Aframe
#define ALayoutDemo_Aframe(x1,x6) {x6=_ALayoutDemo_Aframe(x1);}
#endif

#ifndef ALayoutDemo_Apad
#define ALayoutDemo_Apad(x1,x7) {x7=_ALayoutDemo_Apad(x1);}
#endif

#ifndef ALayoutDemo_AexitButton
#define ALayoutDemo_AexitButton(x1,x5) {x5=_ALayoutDemo_AexitButton(x1);}
#endif

#ifndef ALayoutDemo_AprocArgSeq_L53
#define ALayoutDemo_AprocArgSeq_L53(x1,x3) {x3=_ALayoutDemo_AprocArgSeq_L53(x1);}
#endif

#ifndef ALayoutDemo_AlayoutDemo_L54
#define ALayoutDemo_AlayoutDemo_L54(x1,x2,x5) {x5=_ALayoutDemo_AlayoutDemo_L54(x1,x2);}
#endif

#ifndef ALayoutDemo_AlayoutDemo_L55
#define ALayoutDemo_AlayoutDemo_L55(x1,x4) {x4=_ALayoutDemo_AlayoutDemo_L55(x1);}
#endif

#ifndef ALayoutDemo_AprocessArgs_L56
#define ALayoutDemo_AprocessArgs_L56(x1,x9) {x9=_ALayoutDemo_AprocessArgs_L56(x1);}
#endif

#ifndef ALayoutDemo_Apicture_L57
#define ALayoutDemo_Apicture_L57(x1,x2,x5) {x5=_ALayoutDemo_Apicture_L57(x1,x2);}
#endif

#ifndef ALayoutDemo_Apicture_L58
#define ALayoutDemo_Apicture_L58(x1,x2,x8) {x8=_ALayoutDemo_Apicture_L58(x1,x2);}
#endif

#ifndef ALayoutDemo_Apicture_L59
#define ALayoutDemo_Apicture_L59(x1,x2,x11) {x11=_ALayoutDemo_Apicture_L59(x1,x2);}
#endif

#ifndef ALayoutDemo_AhandleEmits_L60
#define ALayoutDemo_AhandleEmits_L60(x1,x2,x8) {x8=_ALayoutDemo_AhandleEmits_L60(x1,x2);}
#endif

#ifndef ALayoutDemo_Ainitialize_L66
#define ALayoutDemo_Ainitialize_L66(x1,x2,x3,x6) {x6=_ALayoutDemo_Ainitialize_L66(x1,x2,x3);}
#endif

#ifndef ALayoutDemo_Ainitialize_L67
#define ALayoutDemo_Ainitialize_L67(x1,x2,x4) {x4=_ALayoutDemo_Ainitialize_L67(x1,x2);}
#endif

#ifndef ALayoutDemo_Ainitialize_L68
#define ALayoutDemo_Ainitialize_L68(x1,x3) {x3=_ALayoutDemo_Ainitialize_L68(x1);}
#endif

#ifndef ALayoutDemo_AsetupWindow_L69
#define ALayoutDemo_AsetupWindow_L69(x1,x2,x9) {x9=_ALayoutDemo_AsetupWindow_L69(x1,x2);}
#endif

#endif
