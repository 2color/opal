

#line 1 "BinSearchTree.impl"
#include "BUILTIN.h"
extern OBJ __ABinTree_2;
extern OBJ __ABinTree_3;
extern OBJ __ABinTree_4;
extern OBJ __ABinTree_5;
extern OBJ __ABinTree_6;
extern OBJ __ABinTree_7;
extern OBJ __ABinTree_8;
extern OBJ __AOption_2;
extern OBJ __AOption_4;
extern OBJ __AOption_5;
extern OBJ __AOption_6;
extern OBJ __ABool_4;
extern OBJ _ABinSearchTree_3(OBJ,OBJ,OBJ);OBJ __ABinSearchTree_3; /* insert */
extern OBJ _ABinSearchTree_4(OBJ,OBJ,OBJ);OBJ __ABinSearchTree_4; /* find */
extern OBJ _ABinSearchTree_5(OBJ,OBJ,OBJ);OBJ __ABinSearchTree_5; /* delete */
extern OBJ _ABinSearchTree_9(OBJ,OBJ);OBJ __ABinSearchTree_9; /* findBiggest */
extern OBJ _ABinSearchTree_10(OBJ,OBJ,OBJ);OBJ __ABinSearchTree_10; /* > */
extern OBJ _ABinSearchTree_11(OBJ,OBJ,OBJ);OBJ __ABinSearchTree_11; /* = */

extern OBJ _ABinSearchTree_3(OBJ x1,OBJ x2,OBJ x3) /* insert */
{OBJ r;
 CPCLS(__ABinTree_8,1);
 COPY(x3,1);
#line 19
 {OBJ x4;
#line 19
  x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x3);
#line 19
  if(ISTGPRM(x4,1)){
#line 19
   FRCLS(x1,1);
#line 19
   FREE(x3,1);
#line 19
   CPCLS(__ABinTree_2,1);
#line 19
   COPY(__ABinTree_7,2);
#line 19
   r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x2,__ABinTree_7,__ABinTree_7);
#line 19
  }else{
#line 19
   COPY(x3,1);
#line 19
   CPCLS(__ABinTree_3,1);
#line 19
   {OBJ x5;
#line 19
    x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_3,1))(__ABinTree_3,x3);
#line 19
    if(ISTGPRM(x5,1)){
#line 19
     CPCLS(x1,1);
#line 19
     COPY(x2,1);
#line 19
     COPY(x3,2);
#line 19
     CPCLS(__ABinTree_4,1);
#line 19
     CPCLS(__ABinTree_5,1);
#line 19
     CPCLS(__ABinTree_6,1);
#line 19
     {OBJ x6;OBJ x7;OBJ x8;OBJ x9;
#line 20
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_6,1))(__ABinTree_6,x3);
#line 20
      COPY(x6,1);
#line 20
      x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_5,1))(__ABinTree_5,x3);
#line 20
      x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_4,1))(__ABinTree_4,x3);
#line 21
      x9=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(x1,2))(x1,x2,x6);
#line 21
      if(ISTGPRM(x9,1)){
#line 21
       CPCLS(__ABinSearchTree_3,1);
#line 21
       CPCLS(__ABinTree_2,1);
#line 21
       {OBJ x10;
#line 21
	x10=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,x1,x2,x7);
#line 21
	r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x6,x10,x8);}
#line 21
      }else{
#line 21
       CPCLS(x1,1);
#line 21
       COPY(x2,1);
#line 21
       COPY(x6,1);
#line 21
       CPCLS(__ABinSearchTree_10,1);
#line 21
       {OBJ x11;
#line 22
	x11=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_10,3))(__ABinSearchTree_10,x1,x2,x6);
#line 22
	if(ISTGPRM(x11,1)){
#line 22
	 CPCLS(__ABinSearchTree_3,1);
#line 22
	 CPCLS(__ABinTree_2,1);
#line 22
	 {OBJ x12;
#line 22
	  x12=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,x1,x2,x8);
#line 22
	  r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x6,x7,x12);}
#line 22
	}else{
#line 22
	 COPY(x6,1);
#line 22
	 CPCLS(__ABinSearchTree_11,1);
#line 22
	 {OBJ x13;
#line 23
	  x13=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_11,3))(__ABinSearchTree_11,x1,x2,x6);
#line 23
	  if(ISTGPRM(x13,1)){
#line 23
	   CPCLS(__ABinTree_2,1);
#line 23
	   r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x6,x7,x8);
#line 23
	  }else{
#line 21
	   HLT("BinSearchTree at <21,8-23,49> : missing else in insert\'BinSearchTree:alpha**binTree->binTree");}}}}}}
#line 21
    }else{
#line 21
     HLT("BinSearchTree at <unknown> : missing else in insert\'BinSearchTree:alpha**binTree->binTree");}}}}
#line 21
 return r;}

extern OBJ _ABinSearchTree_4(OBJ x1,OBJ x2,OBJ x3) /* find */
{OBJ r;
 CPCLS(__ABinTree_8,1);
 COPY(x3,1);
#line 9
 {OBJ x4;
#line 9
  x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x3);
#line 9
  if(ISTGPRM(x4,1)){
#line 9
   FRCLS(x1,1);
#line 9
   FREE(x2,1);
#line 9
   FREE(x3,1);
#line 9
   COPY(__AOption_5,1);
#line 9
   r=__AOption_5;
#line 9
  }else{
#line 9
   COPY(x3,1);
#line 9
   CPCLS(__ABinTree_3,1);
#line 9
   {OBJ x5;
#line 9
    x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_3,1))(__ABinTree_3,x3);
#line 9
    if(ISTGPRM(x5,1)){
#line 9
     CPCLS(x1,1);
#line 9
     COPY(x2,1);
#line 9
     COPY(x3,2);
#line 9
     CPCLS(__ABinTree_4,1);
#line 9
     CPCLS(__ABinTree_5,1);
#line 9
     CPCLS(__ABinTree_6,1);
#line 9
     {OBJ x6;OBJ x7;OBJ x8;OBJ x9;
#line 10
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_6,1))(__ABinTree_6,x3);
#line 10
      COPY(x6,1);
#line 10
      x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_5,1))(__ABinTree_5,x3);
#line 10
      x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_4,1))(__ABinTree_4,x3);
#line 11
      x9=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(x1,2))(x1,x2,x6);
#line 11
      if(ISTGPRM(x9,1)){
#line 11
       FREE(x6,1);
#line 11
       FREE(x8,1);
#line 11
       CPCLS(__ABinSearchTree_4,1);
#line 11
       r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_4,3))(__ABinSearchTree_4,x1,x2,x7);
#line 11
      }else{
#line 11
       FREE(x7,1);
#line 11
       CPCLS(x1,1);
#line 11
       COPY(x2,1);
#line 11
       COPY(x6,1);
#line 11
       CPCLS(__ABinSearchTree_10,1);
#line 11
       {OBJ x10;
#line 12
	x10=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_10,3))(__ABinSearchTree_10,x1,x2,x6);
#line 12
	if(ISTGPRM(x10,1)){
#line 12
	 FREE(x6,1);
#line 12
	 CPCLS(__ABinSearchTree_4,1);
#line 12
	 r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_4,3))(__ABinSearchTree_4,x1,x2,x8);
#line 12
	}else{
#line 12
	 FREE(x8,1);
#line 12
	 COPY(x6,1);
#line 12
	 CPCLS(__ABinSearchTree_11,1);
#line 12
	 {OBJ x11;
#line 13
	  x11=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_11,3))(__ABinSearchTree_11,x1,x2,x6);
#line 13
	  if(ISTGPRM(x11,1)){
#line 13
	   CPCLS(__AOption_2,1);
#line 13
	   r=(*(OBJ(*)(OBJ,OBJ))METHOD(__AOption_2,1))(__AOption_2,x6);
#line 13
	  }else{
#line 11
	   HLT("BinSearchTree at <11,6-13,35> : missing else in find\'BinSearchTree:alpha**binTree->option");}}}}}}
#line 11
    }else{
#line 11
     HLT("BinSearchTree at <unknown> : missing else in find\'BinSearchTree:alpha**binTree->option");}}}}
#line 11
 return r;}

extern OBJ _ABinSearchTree_5(OBJ x1,OBJ x2,OBJ x3) /* delete */
{OBJ r;
 CPCLS(__ABinTree_8,1);
 COPY(x3,1);
#line 39
 {OBJ x4;
#line 39
  x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x3);
#line 39
  if(ISTGPRM(x4,1)){
#line 39
   FRCLS(x1,1);
#line 39
   FREE(x2,1);
#line 39
   FREE(x3,1);
#line 39
   COPY(__ABinTree_7,1);
#line 39
   r=__ABinTree_7;
#line 39
  }else{
#line 39
   COPY(x3,1);
#line 39
   CPCLS(__ABinTree_3,1);
#line 39
   {OBJ x5;
#line 39
    x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_3,1))(__ABinTree_3,x3);
#line 39
    if(ISTGPRM(x5,1)){
#line 39
     CPCLS(x1,2);
#line 39
     COPY(x2,1);
#line 39
     COPY(x3,2);
#line 39
     CPCLS(__ABinSearchTree_4,1);
#line 39
     CPCLS(__ABinSearchTree_9,1);
#line 39
     CPCLS(__ABinTree_2,1);
#line 39
     CPCLS(__ABinTree_4,1);
#line 39
     CPCLS(__ABinTree_5,1);
#line 39
     CPCLS(__ABinTree_6,1);
#line 39
     CPCLS(__AOption_6,1);
#line 39
     {OBJ x6;OBJ x7;OBJ x8;OBJ x9;OBJ x10;OBJ x11;OBJ x12;
#line 40
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_6,1))(__ABinTree_6,x3);
#line 40
      COPY(x6,1);
#line 40
      x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_5,1))(__ABinTree_5,x3);
#line 40
      COPY(x7,2);
#line 40
      x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_4,1))(__ABinTree_4,x3);
#line 40
      COPY(x8,1);
#line 57
      x9=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_9,2))(__ABinSearchTree_9,x1,x7);
#line 56
      x10=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x6,x7,x8);
#line 56
      COPY(x10,1);
#line 41
      x11=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_4,3))(__ABinSearchTree_4,x1,x2,x10);
#line 41
      x12=(*(OBJ(*)(OBJ,OBJ))METHOD(__AOption_6,1))(__AOption_6,x11);
#line 41
      if(ISTGPRM(x12,1)){
#line 41
       FRCLS(x1,1);
#line 41
       FREE(x2,1);
#line 41
       FREE(x6,1);
#line 41
       FREE(x7,1);
#line 41
       FREE(x8,1);
#line 41
       FREE(x9,1);
#line 41
       r=x10;
#line 41
      }else{
#line 41
       FREE(x10,1);
#line 41
       CPCLS(x1,1);
#line 41
       COPY(x2,1);
#line 41
       COPY(x6,1);
#line 41
       CPCLS(__ABinSearchTree_11,1);
#line 41
       {OBJ x13;
#line 43
	x13=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_11,3))(__ABinSearchTree_11,x1,x2,x6);
#line 43
	if(ISTGPRM(x13,1)){
#line 43
	 FREE(x2,1);
#line 43
	 FREE(x6,1);
#line 43
	 COPY(x7,1);
#line 43
	 COPY(x8,1);
#line 43
	 CPCLS(__ABinTree_8,2);
#line 43
	 {OBJ x14;OBJ x15;OBJ x16;
#line 44
	  x14=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x7);
#line 44
	  x15=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x8);
#line 44
	  ABUILTIN_9(x14,x15,x16);
#line 44
	  if(ISTGPRM(x16,1)){
#line 44
	   FRCLS(x1,1);
#line 44
	   FREE(x7,1);
#line 44
	   FREE(x8,1);
#line 44
	   FREE(x9,1);
#line 44
	   COPY(__ABinTree_7,1);
#line 44
	   r=__ABinTree_7;
#line 44
	  }else{
#line 44
	   COPY(x7,1);
#line 44
	   CPCLS(__ABinTree_3,1);
#line 44
	   {OBJ x17;OBJ x18;
#line 45
	    x17=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_3,1))(__ABinTree_3,x7);
#line 45
	    ABUILTIN_9(x17,x15,x18);
#line 45
	    if(ISTGPRM(x18,1)){
#line 45
	     FRCLS(x1,1);
#line 45
	     FREE(x8,1);
#line 45
	     FREE(x9,1);
#line 45
	     r=x7;
#line 45
	    }else{
#line 45
	     COPY(x8,1);
#line 45
	     CPCLS(__ABinTree_3,1);
#line 45
	     {OBJ x19;OBJ x20;
#line 46
	      x19=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_3,1))(__ABinTree_3,x8);
#line 46
	      ABUILTIN_9(x14,x19,x20);
#line 46
	      if(ISTGPRM(x20,1)){
#line 46
	       FRCLS(x1,1);
#line 46
	       FREE(x7,1);
#line 46
	       FREE(x9,1);
#line 46
	       r=x8;
#line 46
	      }else{
#line 46
	       {OBJ x21;
#line 47
		ABUILTIN_9(x17,x19,x21);
#line 47
		if(ISTGPRM(x21,1)){
#line 47
		 CPCLS(__ABinSearchTree_5,1);
#line 47
		 CPCLS(__ABinTree_2,1);
#line 47
		 CPCLS(__AOption_4,1);
#line 47
		 {OBJ x22;OBJ x23;
#line 47
		  x22=(*(OBJ(*)(OBJ,OBJ))METHOD(__AOption_4,1))(__AOption_4,x9);
#line 47
		  COPY(x22,1);
#line 47
		  x23=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_5,3))(__ABinSearchTree_5,x1,x22,x7);
#line 47
		  r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x22,x23,x8);}
#line 47
		}else{
#line 44
		 HLT("BinSearchTree at <44,14-47,105> : missing else in delete\'BinSearchTree:alpha**binTree->binTree");}}}}}}}}
#line 44
	}else{
#line 44
	 FREE(x9,1);
#line 44
	 CPCLS(x1,1);
#line 44
	 COPY(x2,1);
#line 44
	 COPY(x6,1);
#line 44
	 CPCLS(__ABinSearchTree_10,1);
#line 44
	 {OBJ x24;
#line 50
	  x24=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_10,3))(__ABinSearchTree_10,x1,x2,x6);
#line 50
	  if(ISTGPRM(x24,1)){
#line 50
	   CPCLS(__ABinSearchTree_5,1);
#line 50
	   CPCLS(__ABinTree_2,1);
#line 50
	   {OBJ x25;
#line 50
	    x25=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_5,3))(__ABinSearchTree_5,x1,x2,x8);
#line 50
	    r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x6,x7,x25);}
#line 50
	  }else{
#line 50
	   CPCLS(x1,1);
#line 50
	   COPY(x2,1);
#line 50
	   COPY(x6,1);
#line 50
	   {OBJ x26;
#line 51
	    x26=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(x1,2))(x1,x2,x6);
#line 51
	    if(ISTGPRM(x26,1)){
#line 51
	     CPCLS(__ABinSearchTree_5,1);
#line 51
	     CPCLS(__ABinTree_2,1);
#line 51
	     {OBJ x27;
#line 51
	      x27=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_5,3))(__ABinSearchTree_5,x1,x2,x7);
#line 51
	      r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x6,x27,x8);}
#line 51
	    }else{
#line 50
	     HLT("BinSearchTree at <50,10-51,62> : missing else in delete\'BinSearchTree:alpha**binTree->binTree");}}}}}}}}
#line 50
    }else{
#line 50
     HLT("BinSearchTree at <unknown> : missing else in delete\'BinSearchTree:alpha**binTree->binTree");}}}}
#line 50
 return r;}

extern OBJ _ABinSearchTree_9(OBJ x1,OBJ x2) /* findBiggest */
{OBJ r;
 CPCLS(__ABinTree_8,1);
 COPY(x2,1);
#line 61
 {OBJ x3;
#line 60
  x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x2);
#line 60
  if(ISTGPRM(x3,1)){
#line 60
   FRCLS(x1,1);
#line 60
   FREE(x2,1);
#line 60
   COPY(__AOption_5,1);
#line 61
   r=__AOption_5;
#line 61
  }else{
#line 61
   COPY(x2,1);
#line 61
   CPCLS(__ABinTree_3,1);
#line 61
   {OBJ x4;
#line 60
    x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_3,1))(__ABinTree_3,x2);
#line 60
    if(ISTGPRM(x4,1)){
#line 60
     COPY(x2,1);
#line 60
     CPCLS(__ABinTree_4,1);
#line 60
     CPCLS(__ABinTree_6,1);
#line 60
     CPCLS(__ABinTree_8,1);
#line 60
     {OBJ x5;OBJ x6;OBJ x7;
#line 62
      x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_6,1))(__ABinTree_6,x2);
#line 62
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_4,1))(__ABinTree_4,x2);
#line 62
      COPY(x6,1);
#line 63
      x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x6);
#line 63
      if(ISTGPRM(x7,1)){
#line 63
       FRCLS(x1,1);
#line 63
       FREE(x6,1);
#line 63
       CPCLS(__AOption_2,1);
#line 63
       r=(*(OBJ(*)(OBJ,OBJ))METHOD(__AOption_2,1))(__AOption_2,x5);
#line 63
      }else{
#line 63
       FREE(x5,1);
#line 63
       CPCLS(__ABinSearchTree_9,1);
#line 64
       r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_9,2))(__ABinSearchTree_9,x1,x6);}}
#line 64
    }else{
#line 60
     HLT("BinSearchTree at <60,5-15> : missing else in findBiggest\'BinSearchTree:binTree->option");}}}}
#line 60
 return r;}

extern OBJ _ABinSearchTree_10(OBJ x1,OBJ x2,OBJ x3) /* > */
{OBJ r;
#line 70
 r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(x1,2))(x1,x3,x2);
#line 70
 return r;}

extern OBJ _ABinSearchTree_11(OBJ x1,OBJ x2,OBJ x3) /* = */
{OBJ r;
 CPCLS(__ABinSearchTree_10,2);
 CPCLS(__ABool_4,2);
 CPCLS(x1,1);
 COPY(x2,1);
 COPY(x3,1);
#line 74
 {OBJ x4;OBJ x5;OBJ x6;OBJ x7;
#line 74
  x4=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_10,3))(__ABinSearchTree_10,x1,x2,x3);
#line 74
  x5=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_10,3))(__ABinSearchTree_10,x1,x3,x2);
#line 74
  x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABool_4,1))(__ABool_4,x4);
#line 74
  x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABool_4,1))(__ABool_4,x5);
#line 74
  ABUILTIN_9(x6,x7,r);}
#line 74
 return r;}

static OBJ _mt_2_0_1(OBJ t,OBJ t1) 
{OBJ r;
 DPCLS(t,r);
 INCCLS(r,0,1);
 FLDCLS(r,1)=t1;
 return r;}

static OBJ _mt_2_0_2(OBJ t,OBJ t1,OBJ t2) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ,OBJ))ENTRY(t))(t1,t2);
 return r;}

static OBJ _mt_2_1_1(OBJ t,OBJ t1) 
{OBJ r;
 if(EXCLS(t)){
  DSCLSF(t);
 }else{
  COPY(FLDCLS(t,1),1);
  DCCLS(t,1);}
 r=(*(OBJ(*)(OBJ,OBJ))ENTRY(t))(FLDCLS(t,1),t1);
 return r;}
static OBJ _mt_2_1_1_l(OBJ t,OBJ t1) 
{OBJ r;
 r=(*(OBJ(*)(OBJ,OBJ))ENTRY(t))(FLDCLS(t,1),t1);
 if(EXCLS(t)){
  DSCLSF(t);
 }else{
  DCCLS(t,1);
  FLDCLS(t,1)=NIL;
  COPY(r,1);LZYCLS(t,r);}
 return r;}

static OBJ _mt_3_0_1(OBJ t,OBJ t1) 
{OBJ r;
 DPCLS(t,r);
 INCCLS(r,0,1);
 FLDCLS(r,1)=t1;
 return r;}

static OBJ _mt_3_0_3(OBJ t,OBJ t1,OBJ t2,OBJ t3) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ,OBJ,OBJ))ENTRY(t))(t1,t2,t3);
 return r;}

static OBJ _mt_3_1_2(OBJ t,OBJ t1,OBJ t2) 
{OBJ r;
 if(EXCLS(t)){
  DSCLSF(t);
 }else{
  COPY(FLDCLS(t,1),1);
  DCCLS(t,1);}
 r=(*(OBJ(*)(OBJ,OBJ,OBJ))ENTRY(t))(FLDCLS(t,1),t1,t2);
 return r;}

extern void init_ABinTree();
extern void init_AOption();
extern void init_ASeq();
extern void init_ANat();
extern void init_ABool();
void init_ABinSearchTree()
{
 static int visited=0; if(visited) return; visited=1;
 init_ABinTree();
 init_AOption();
 init_ASeq();
 init_ANat();
 init_ABool();
 CLS(3,_ABinSearchTree_11,__ABinSearchTree_11);
 CLS(3,_ABinSearchTree_10,__ABinSearchTree_10);
 CLS(2,_ABinSearchTree_9,__ABinSearchTree_9);
 CLS(3,_ABinSearchTree_5,__ABinSearchTree_5);
 CLS(3,_ABinSearchTree_4,__ABinSearchTree_4);
 CLS(3,_ABinSearchTree_3,__ABinSearchTree_3);
 MTH(2,0,1,_mt_2_0_1);LZYMTH(2,0,1,_mt_2_0_1);
 MTH(2,0,2,_mt_2_0_2);LZYMTH(2,0,2,_mt_2_0_2);
 MTH(2,1,1,_mt_2_1_1);LZYMTH(2,1,1,_mt_2_1_1_l);
 MTH(3,0,1,_mt_3_0_1);LZYMTH(3,0,1,_mt_3_0_1);
 MTH(3,0,3,_mt_3_0_3);LZYMTH(3,0,3,_mt_3_0_3);
 MTH(3,1,2,_mt_3_1_2);LZYMTH(3,1,2,_mt_3_1_2);}

