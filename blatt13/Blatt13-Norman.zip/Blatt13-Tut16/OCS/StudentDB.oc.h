

#ifndef AStudentDB_included
#define AStudentDB_included

#define __AStudentDB_Af __AStudentDB_2
extern OBJ __AStudentDB_Af;

#define __AStudentDB_Af_ __AStudentDB_3
#define _AStudentDB_Af_ _AStudentDB_3
extern OBJ __AStudentDB_Af_;
extern OBJ _AStudentDB_Af_(OBJ);

#define __AStudentDB_Am __AStudentDB_4
extern OBJ __AStudentDB_Am;

#define __AStudentDB_Am_ __AStudentDB_5
#define _AStudentDB_Am_ _AStudentDB_5
extern OBJ __AStudentDB_Am_;
extern OBJ _AStudentDB_Am_(OBJ);

#define __AStudentDB_Astudent __AStudentDB_7
#define _AStudentDB_Astudent _AStudentDB_7
extern OBJ __AStudentDB_Astudent;
extern OBJ _AStudentDB_Astudent(OBJ,OBJ,OBJ,OBJ);

#define __AStudentDB_Astudent_ __AStudentDB_8
#define _AStudentDB_Astudent_ _AStudentDB_8
extern OBJ __AStudentDB_Astudent_;
extern OBJ _AStudentDB_Astudent_(OBJ);

#define __AStudentDB_Asex __AStudentDB_9
#define _AStudentDB_Asex _AStudentDB_9
extern OBJ __AStudentDB_Asex;
extern OBJ _AStudentDB_Asex(OBJ);

#define __AStudentDB_Asurname __AStudentDB_10
#define _AStudentDB_Asurname _AStudentDB_10
extern OBJ __AStudentDB_Asurname;
extern OBJ _AStudentDB_Asurname(OBJ);

#define __AStudentDB_Aname __AStudentDB_11
#define _AStudentDB_Aname _AStudentDB_11
extern OBJ __AStudentDB_Aname;
extern OBJ _AStudentDB_Aname(OBJ);

#define __AStudentDB_Amatric __AStudentDB_12
#define _AStudentDB_Amatric _AStudentDB_12
extern OBJ __AStudentDB_Amatric;
extern OBJ _AStudentDB_Amatric(OBJ);

#define __AStudentDB_AstudentList __AStudentDB_13
#define _AStudentDB_AstudentList _AStudentDB_13
extern OBJ __AStudentDB_AstudentList;
extern OBJ _AStudentDB_AstudentList(OBJ);

#define __AStudentDB_AstudentTree __AStudentDB_14
extern OBJ __AStudentDB_AstudentTree;

#define __AStudentDB_Sl __AStudentDB_15
#define _AStudentDB_Sl _AStudentDB_15
extern OBJ __AStudentDB_Sl;
extern OBJ _AStudentDB_Sl(OBJ,OBJ);

#define __AStudentDB_Sq __AStudentDB_16
#define _AStudentDB_Sq _AStudentDB_16
extern OBJ __AStudentDB_Sq;
extern OBJ _AStudentDB_Sq(OBJ);

#define __AStudentDB_Sq_O1 __AStudentDB_27
#define _AStudentDB_Sq_O1 _AStudentDB_27
extern OBJ __AStudentDB_Sq_O1;
extern OBJ _AStudentDB_Sq_O1(OBJ);

#define __AStudentDB_Astudent1 __AStudentDB_28
extern OBJ __AStudentDB_Astudent1;

#define __AStudentDB_Astudent2 __AStudentDB_29
extern OBJ __AStudentDB_Astudent2;

#define __AStudentDB_Astudent3 __AStudentDB_30
extern OBJ __AStudentDB_Astudent3;

#define __AStudentDB_Astudent4 __AStudentDB_31
extern OBJ __AStudentDB_Astudent4;

#define __AStudentDB_Astudent5 __AStudentDB_32
extern OBJ __AStudentDB_Astudent5;

#define __AStudentDB_Astudent6 __AStudentDB_33
extern OBJ __AStudentDB_Astudent6;

#define __AStudentDB_Astudent7 __AStudentDB_34
extern OBJ __AStudentDB_Astudent7;

#define __AStudentDB_Astudent8 __AStudentDB_35
extern OBJ __AStudentDB_Astudent8;

#define __AStudentDB_Astudent9 __AStudentDB_36
extern OBJ __AStudentDB_Astudent9;

#ifndef AStudentDB_Af_
#define AStudentDB_Af_(x1,x2) {x2=_AStudentDB_Af_(x1);}
#endif

#ifndef AStudentDB_Am_
#define AStudentDB_Am_(x1,x2) {x2=_AStudentDB_Am_(x1);}
#endif

#ifndef AStudentDB_Astudent
#define AStudentDB_Astudent(x1,x2,x3,x4,x5) {x5=_AStudentDB_Astudent(x1,x2,x3,x4);}
#endif

#ifndef AStudentDB_Astudent_
#define AStudentDB_Astudent_(x1,x2) {x2=_AStudentDB_Astudent_(x1);}
#endif

#ifndef AStudentDB_Asex
#define AStudentDB_Asex(x1,x6) {x6=_AStudentDB_Asex(x1);}
#endif

#ifndef AStudentDB_Asurname
#define AStudentDB_Asurname(x1,x6) {x6=_AStudentDB_Asurname(x1);}
#endif

#ifndef AStudentDB_Aname
#define AStudentDB_Aname(x1,x6) {x6=_AStudentDB_Aname(x1);}
#endif

#ifndef AStudentDB_Amatric
#define AStudentDB_Amatric(x1,x6) {x6=_AStudentDB_Amatric(x1);}
#endif

#ifndef AStudentDB_AstudentList
#define AStudentDB_AstudentList(x1,x8) {x8=_AStudentDB_AstudentList(x1);}
#endif

#ifndef AStudentDB_Sl
#define AStudentDB_Sl(x1,x2,x7) {x7=_AStudentDB_Sl(x1,x2);}
#endif

#ifndef AStudentDB_Sq
#define AStudentDB_Sq(x1,x15) {x15=_AStudentDB_Sq(x1);}
#endif

#ifndef AStudentDB_Sq_O1
#define AStudentDB_Sq_O1(x1,x4) {x4=_AStudentDB_Sq_O1(x1);}
#endif

#endif
