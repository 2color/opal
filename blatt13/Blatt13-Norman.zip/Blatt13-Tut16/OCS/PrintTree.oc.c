

#line 1 "PrintTree.impl"
#include "BUILTIN.h"
extern OBJ __ABinTree_3;
extern OBJ __ABinTree_4;
extern OBJ __ABinTree_5;
extern OBJ __ABinTree_6;
extern OBJ __ABinTree_8;
extern OBJ __ATree_2;
extern OBJ __ATree_7;
extern OBJ __ATreeConv_4;
extern OBJ _APrintTree_2(OBJ,OBJ);OBJ __APrintTree_2; /* ` */
extern OBJ _APrintTree_3(OBJ);OBJ __APrintTree_3; /* treeTrans */

extern OBJ _APrintTree_2(OBJ x1,OBJ x2) /* ` */
{OBJ r;
 CPCLS(__APrintTree_3,1);
 CPCLS(__ATreeConv_4,1);
#line 9
 {OBJ x3;
#line 9
  x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__APrintTree_3,1))(__APrintTree_3,x2);
#line 9
  r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ATreeConv_4,2))(__ATreeConv_4,x1,x3);}
#line 9
 return r;}

extern OBJ _APrintTree_3(OBJ x1) /* treeTrans */
{OBJ r;
 CPCLS(__ABinTree_8,1);
 COPY(x1,1);
#line 13
 {OBJ x2;
#line 12
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x1);
#line 12
  if(ISTGPRM(x2,1)){
#line 12
   FREE(x1,1);
#line 12
   COPY(__ATree_7,1);
#line 13
   r=__ATree_7;
#line 13
  }else{
#line 13
   COPY(x1,1);
#line 13
   CPCLS(__ABinTree_3,1);
#line 13
   {OBJ x3;
#line 12
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_3,1))(__ABinTree_3,x1);
#line 12
    if(ISTGPRM(x3,1)){
#line 12
     COPY(x1,2);
#line 12
     CPCLS(__APrintTree_3,2);
#line 12
     CPCLS(__ABinTree_4,1);
#line 12
     CPCLS(__ABinTree_5,1);
#line 12
     CPCLS(__ABinTree_6,1);
#line 12
     CPCLS(__ATree_2,1);
#line 12
     {OBJ x4;OBJ x5;OBJ x6;OBJ x8;OBJ x7;
#line 14
      x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_6,1))(__ABinTree_6,x1);
#line 14
      x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_5,1))(__ABinTree_5,x1);
#line 14
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_4,1))(__ABinTree_4,x1);
#line 14
      x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__APrintTree_3,1))(__APrintTree_3,x6);
#line 14
      x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__APrintTree_3,1))(__APrintTree_3,x5);
#line 14
      r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ATree_2,3))(__ATree_2,x4,x7,x8);}
#line 14
    }else{
#line 12
     HLT("PrintTree at <12,5-13> : missing else in treeTrans\'PrintTree:binTree->tree");}}}}
#line 12
 return r;}

static OBJ _mt_1_0_1(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 return r;}
static OBJ _mt_1_0_1_l(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 COPY(r,1);LZYCLS(t,r);
 return r;}

static OBJ _mt_2_0_1(OBJ t,OBJ t1) 
{OBJ r;
 DPCLS(t,r);
 INCCLS(r,0,1);
 FLDCLS(r,1)=t1;
 return r;}

static OBJ _mt_2_0_2(OBJ t,OBJ t1,OBJ t2) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ,OBJ))ENTRY(t))(t1,t2);
 return r;}

static OBJ _mt_2_1_1(OBJ t,OBJ t1) 
{OBJ r;
 if(EXCLS(t)){
  DSCLSF(t);
 }else{
  COPY(FLDCLS(t,1),1);
  DCCLS(t,1);}
 r=(*(OBJ(*)(OBJ,OBJ))ENTRY(t))(FLDCLS(t,1),t1);
 return r;}
static OBJ _mt_2_1_1_l(OBJ t,OBJ t1) 
{OBJ r;
 r=(*(OBJ(*)(OBJ,OBJ))ENTRY(t))(FLDCLS(t,1),t1);
 if(EXCLS(t)){
  DSCLSF(t);
 }else{
  DCCLS(t,1);
  FLDCLS(t,1)=NIL;
  COPY(r,1);LZYCLS(t,r);}
 return r;}

extern void init_ADenotation();
extern void init_ABinTree();
extern void init_ASeq();
extern void init_ANat();
extern void init_AOption();
extern void init_AChar();
extern void init_ATree();
extern void init_ATreeConv();
extern void init_AString();
void init_APrintTree()
{
 static int visited=0; if(visited) return; visited=1;
 init_ADenotation();
 init_ABinTree();
 init_ASeq();
 init_ANat();
 init_AOption();
 init_AChar();
 init_ATree();
 init_ATreeConv();
 init_AString();
 CLS(1,_APrintTree_3,__APrintTree_3);
 CLS(2,_APrintTree_2,__APrintTree_2);
 MTH(1,0,1,_mt_1_0_1);LZYMTH(1,0,1,_mt_1_0_1_l);
 MTH(2,0,1,_mt_2_0_1);LZYMTH(2,0,1,_mt_2_0_1);
 MTH(2,0,2,_mt_2_0_2);LZYMTH(2,0,2,_mt_2_0_2);
 MTH(2,1,1,_mt_2_1_1);LZYMTH(2,1,1,_mt_2_1_1_l);}

