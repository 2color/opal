

#ifndef ATreeTest_included
#define ATreeTest_included

#define __ATreeTest_AexampleTree __ATreeTest_1
extern OBJ __ATreeTest_AexampleTree;

#define __ATreeTest_Atest __ATreeTest_2
extern OBJ __ATreeTest_Atest;

#define __ATreeTest_AexampleSearchTree __ATreeTest_3
extern OBJ __ATreeTest_AexampleSearchTree;

#ifndef ATreeTest_Atest_L17
#define ATreeTest_Atest_L17(x1,x3) {x3=_ATreeTest_Atest_L17(x1);}
#endif

#endif
