

#line 1 "BinTree.impl"
#include "BUILTIN.h"
extern OBJ __ASeq_2;
extern OBJ __ASeq_6;
extern OBJ __ASeq_23;
extern OBJ __ASeq_26;
extern OBJ __ASeq_29;
extern OBJ _ABinTree_2(OBJ,OBJ,OBJ);OBJ __ABinTree_2; /* node */
extern OBJ _ABinTree_3(OBJ);OBJ __ABinTree_3; /* node? */
extern OBJ _ABinTree_4(OBJ);OBJ __ABinTree_4; /* right */
extern OBJ _ABinTree_5(OBJ);OBJ __ABinTree_5; /* left */
extern OBJ _ABinTree_6(OBJ);OBJ __ABinTree_6; /* data */
OBJ __ABinTree_7; /* nil */
extern OBJ _ABinTree_8(OBJ);OBJ __ABinTree_8; /* nil? */
extern OBJ _ABinTree_10(OBJ);OBJ __ABinTree_10; /* preorder */
extern OBJ _ABinTree_11(OBJ);OBJ __ABinTree_11; /* inorder */
extern OBJ _ABinTree_12(OBJ);OBJ __ABinTree_12; /* postorder */

extern OBJ _ABinTree_2(OBJ x1,OBJ x2,OBJ x3) /* node */
{OBJ r;
 PRD1(3,r);FLD1(r,1)=x1;FLD1(r,2)=x2;FLD1(r,3)=x3;
 return r;}

extern OBJ _ABinTree_3(OBJ x1) /* node? */
{OBJ r;
#line 8
 if(ISPRD(x1)){
#line 8
  if(EXPRD(x1,1)){
#line 8
   DSPRD(x1);
#line 8
  }else{
#line 8
   DCPRD(x1,1);}
#line 8
  r=__ABUILTIN_5;
#line 8
 }else{
#line 8
  FREE(x1,1);
#line 8
  r=__ABUILTIN_3;}
#line 8
 return r;}

extern OBJ _ABinTree_4(OBJ x1) /* right */
{OBJ r;
 if(ISPRD(x1)){
  {OBJ x4=FLD1(x1,3);
   if(EXPRD(x1,1)){
    FLD1(x1,3)=NIL;DSPRD(x1);
   }else{
    COPY(x4,1);
    FRPRD(x1,1);}
   r=x4;}
 }else{
  HLT("BinTree at <unknown> : undefined selection right\'BinTree:binTree->binTree");}
 return r;}

extern OBJ _ABinTree_5(OBJ x1) /* left */
{OBJ r;
 if(ISPRD(x1)){
  {OBJ x3=FLD1(x1,2);
   if(EXPRD(x1,1)){
    FLD1(x1,2)=NIL;DSPRD(x1);
   }else{
    COPY(x3,1);
    FRPRD(x1,1);}
   r=x3;}
 }else{
  HLT("BinTree at <unknown> : undefined selection left\'BinTree:binTree->binTree");}
 return r;}

extern OBJ _ABinTree_6(OBJ x1) /* data */
{OBJ r;
 if(ISPRD(x1)){
  {OBJ x2=FLD1(x1,1);
   if(EXPRD(x1,1)){
    FLD1(x1,1)=NIL;DSPRD(x1);
   }else{
    COPY(x2,1);
    FRPRD(x1,1);}
   r=x2;}
 }else{
  HLT("BinTree at <unknown> : undefined selection data\'BinTree:binTree->alpha");}
 return r;}

extern OBJ _ABinTree_8(OBJ x1) /* nil? */
{OBJ r;
#line 7
 if(ISPRM(x1)){
#line 7
  r=__ABUILTIN_5;
#line 7
 }else{
#line 7
  FREE(x1,1);
#line 7
  r=__ABUILTIN_3;}
#line 7
 return r;}

extern OBJ _ABinTree_10(OBJ x1) /* preorder */
{OBJ r;
 CPCLS(__ABinTree_8,1);
 COPY(x1,1);
#line 11
 {OBJ x2;
#line 11
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x1);
#line 11
  if(ISTGPRM(x2,1)){
#line 11
   FREE(x1,1);
#line 11
   COPY(__ASeq_6,1);
#line 12
   r=__ASeq_6;
#line 12
  }else{
#line 12
   COPY(x1,1);
#line 12
   CPCLS(__ABinTree_3,1);
#line 12
   {OBJ x3;
#line 12
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_3,1))(__ABinTree_3,x1);
#line 12
    if(ISTGPRM(x3,1)){
#line 12
     COPY(x1,2);
#line 12
     CPCLS(__ABinTree_4,1);
#line 12
     CPCLS(__ABinTree_5,1);
#line 12
     CPCLS(__ABinTree_6,1);
#line 12
     CPCLS(__ABinTree_10,2);
#line 12
     CPCLS(__ASeq_2,1);
#line 12
     CPCLS(__ASeq_26,1);
#line 12
     {OBJ x4;OBJ x5;OBJ x6;OBJ x8;OBJ x7;OBJ x9;
#line 11
      x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_6,1))(__ABinTree_6,x1);
#line 11
      x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_5,1))(__ABinTree_5,x1);
#line 11
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_4,1))(__ABinTree_4,x1);
#line 11
      x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_10,1))(__ABinTree_10,x6);
#line 11
      x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_10,1))(__ABinTree_10,x5);
#line 11
      x9=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_26,2))(__ASeq_26,x7,x8);
#line 11
      r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_2,2))(__ASeq_2,x4,x9);}
#line 11
    }else{
#line 11
     HLT("BinTree at <unknown> : missing else in preorder\'BinTree:binTree->seq");}}}}
#line 11
 return r;}

extern OBJ _ABinTree_11(OBJ x1) /* inorder */
{OBJ r;
 CPCLS(__ABinTree_8,1);
 COPY(x1,1);
#line 14
 {OBJ x2;
#line 14
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x1);
#line 14
  if(ISTGPRM(x2,1)){
#line 14
   FREE(x1,1);
#line 14
   COPY(__ASeq_6,1);
#line 15
   r=__ASeq_6;
#line 15
  }else{
#line 15
   COPY(x1,1);
#line 15
   CPCLS(__ABinTree_3,1);
#line 15
   {OBJ x3;
#line 15
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_3,1))(__ABinTree_3,x1);
#line 15
    if(ISTGPRM(x3,1)){
#line 15
     COPY(x1,2);
#line 15
     CPCLS(__ABinTree_4,1);
#line 15
     CPCLS(__ABinTree_5,1);
#line 15
     CPCLS(__ABinTree_6,1);
#line 15
     CPCLS(__ABinTree_11,2);
#line 15
     CPCLS(__ASeq_29,1);
#line 15
     {OBJ x4;OBJ x5;OBJ x6;OBJ x8;OBJ x7;
#line 14
      x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_6,1))(__ABinTree_6,x1);
#line 14
      x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_5,1))(__ABinTree_5,x1);
#line 14
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_4,1))(__ABinTree_4,x1);
#line 14
      x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_11,1))(__ABinTree_11,x6);
#line 14
      x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_11,1))(__ABinTree_11,x5);
#line 14
      r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ASeq_29,3))(__ASeq_29,x4,x7,x8);}
#line 14
    }else{
#line 14
     HLT("BinTree at <unknown> : missing else in inorder\'BinTree:binTree->seq");}}}}
#line 14
 return r;}

extern OBJ _ABinTree_12(OBJ x1) /* postorder */
{OBJ r;
 CPCLS(__ABinTree_8,1);
 COPY(x1,1);
#line 17
 {OBJ x2;
#line 17
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x1);
#line 17
  if(ISTGPRM(x2,1)){
#line 17
   FREE(x1,1);
#line 17
   COPY(__ASeq_6,1);
#line 18
   r=__ASeq_6;
#line 18
  }else{
#line 18
   COPY(x1,1);
#line 18
   CPCLS(__ABinTree_3,1);
#line 18
   {OBJ x3;
#line 18
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_3,1))(__ABinTree_3,x1);
#line 18
    if(ISTGPRM(x3,1)){
#line 18
     COPY(x1,2);
#line 18
     CPCLS(__ABinTree_4,1);
#line 18
     CPCLS(__ABinTree_5,1);
#line 18
     CPCLS(__ABinTree_6,1);
#line 18
     CPCLS(__ABinTree_12,2);
#line 18
     CPCLS(__ASeq_23,1);
#line 18
     CPCLS(__ASeq_26,1);
#line 18
     {OBJ x4;OBJ x5;OBJ x6;OBJ x8;OBJ x7;OBJ x9;
#line 17
      x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_6,1))(__ABinTree_6,x1);
#line 17
      x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_5,1))(__ABinTree_5,x1);
#line 17
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_4,1))(__ABinTree_4,x1);
#line 17
      x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_12,1))(__ABinTree_12,x6);
#line 17
      x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_12,1))(__ABinTree_12,x5);
#line 17
      x9=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_26,2))(__ASeq_26,x7,x8);
#line 17
      r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_23,2))(__ASeq_23,x9,x4);}
#line 17
    }else{
#line 17
     HLT("BinTree at <unknown> : missing else in postorder\'BinTree:binTree->seq");}}}}
#line 17
 return r;}


static OBJ _mt_1_0_1(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 return r;}
static OBJ _mt_1_0_1_l(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 COPY(r,1);LZYCLS(t,r);
 return r;}

static OBJ _mt_3_0_3(OBJ t,OBJ t1,OBJ t2,OBJ t3) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ,OBJ,OBJ))ENTRY(t))(t1,t2,t3);
 return r;}

extern void init_ASeq();
extern void init_ANat();
extern void init_AOption();
void init_ABinTree()
{
 static int visited=0; if(visited) return; visited=1;
 init_ASeq();
 init_ANat();
 init_AOption();
 CLS(1,_ABinTree_12,__ABinTree_12);
 CLS(1,_ABinTree_11,__ABinTree_11);
 CLS(1,_ABinTree_10,__ABinTree_10);
 CLS(1,_ABinTree_8,__ABinTree_8);
 CLS(1,_ABinTree_6,__ABinTree_6);
 CLS(1,_ABinTree_5,__ABinTree_5);
 CLS(1,_ABinTree_4,__ABinTree_4);
 CLS(1,_ABinTree_3,__ABinTree_3);
 CLS(3,_ABinTree_2,__ABinTree_2);
 MTH(1,0,1,_mt_1_0_1);LZYMTH(1,0,1,_mt_1_0_1_l);
 MTH(3,0,3,_mt_3_0_3);LZYMTH(3,0,3,_mt_3_0_3);
 PRM1(__ABinTree_7);}

