

#ifndef APrintTree_included
#define APrintTree_included

#define __APrintTree_Sq __APrintTree_2
#define _APrintTree_Sq _APrintTree_2
extern OBJ __APrintTree_Sq;
extern OBJ _APrintTree_Sq(OBJ,OBJ);

#define __APrintTree_AtreeTrans __APrintTree_3
#define _APrintTree_AtreeTrans _APrintTree_3
extern OBJ __APrintTree_AtreeTrans;
extern OBJ _APrintTree_AtreeTrans(OBJ);

#ifndef APrintTree_Sq
#define APrintTree_Sq(x1,x2,x4) {x4=_APrintTree_Sq(x1,x2);}
#endif

#ifndef APrintTree_AtreeTrans
#define APrintTree_AtreeTrans(x1,x9) {x9=_APrintTree_AtreeTrans(x1);}
#endif

#endif
