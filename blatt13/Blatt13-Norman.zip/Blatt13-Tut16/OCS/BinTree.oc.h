

#ifndef ABinTree_included
#define ABinTree_included

#define __ABinTree_Anode __ABinTree_2
#define _ABinTree_Anode _ABinTree_2
extern OBJ __ABinTree_Anode;
extern OBJ _ABinTree_Anode(OBJ,OBJ,OBJ);

#define __ABinTree_Anode_ __ABinTree_3
#define _ABinTree_Anode_ _ABinTree_3
extern OBJ __ABinTree_Anode_;
extern OBJ _ABinTree_Anode_(OBJ);

#define __ABinTree_Aright __ABinTree_4
#define _ABinTree_Aright _ABinTree_4
extern OBJ __ABinTree_Aright;
extern OBJ _ABinTree_Aright(OBJ);

#define __ABinTree_Aleft __ABinTree_5
#define _ABinTree_Aleft _ABinTree_5
extern OBJ __ABinTree_Aleft;
extern OBJ _ABinTree_Aleft(OBJ);

#define __ABinTree_Adata __ABinTree_6
#define _ABinTree_Adata _ABinTree_6
extern OBJ __ABinTree_Adata;
extern OBJ _ABinTree_Adata(OBJ);

#define __ABinTree_Anil __ABinTree_7
extern OBJ __ABinTree_Anil;

#define __ABinTree_Anil_ __ABinTree_8
#define _ABinTree_Anil_ _ABinTree_8
extern OBJ __ABinTree_Anil_;
extern OBJ _ABinTree_Anil_(OBJ);

#define __ABinTree_Apreorder __ABinTree_10
#define _ABinTree_Apreorder _ABinTree_10
extern OBJ __ABinTree_Apreorder;
extern OBJ _ABinTree_Apreorder(OBJ);

#define __ABinTree_Ainorder __ABinTree_11
#define _ABinTree_Ainorder _ABinTree_11
extern OBJ __ABinTree_Ainorder;
extern OBJ _ABinTree_Ainorder(OBJ);

#define __ABinTree_Apostorder __ABinTree_12
#define _ABinTree_Apostorder _ABinTree_12
extern OBJ __ABinTree_Apostorder;
extern OBJ _ABinTree_Apostorder(OBJ);

#ifndef ABinTree_Anode
#define ABinTree_Anode(x1,x2,x3,x4) {x4=_ABinTree_Anode(x1,x2,x3);}
#endif

#ifndef ABinTree_Anode_
#define ABinTree_Anode_(x1,x5) {x5=_ABinTree_Anode_(x1);}
#endif

#ifndef ABinTree_Aright
#define ABinTree_Aright(x1,x5) {x5=_ABinTree_Aright(x1);}
#endif

#ifndef ABinTree_Aleft
#define ABinTree_Aleft(x1,x5) {x5=_ABinTree_Aleft(x1);}
#endif

#ifndef ABinTree_Adata
#define ABinTree_Adata(x1,x5) {x5=_ABinTree_Adata(x1);}
#endif

#ifndef ABinTree_Anil_
#define ABinTree_Anil_(x1,x2) {x2=_ABinTree_Anil_(x1);}
#endif

#ifndef ABinTree_Apreorder
#define ABinTree_Apreorder(x1,x10) {x10=_ABinTree_Apreorder(x1);}
#endif

#ifndef ABinTree_Ainorder
#define ABinTree_Ainorder(x1,x9) {x9=_ABinTree_Ainorder(x1);}
#endif

#ifndef ABinTree_Apostorder
#define ABinTree_Apostorder(x1,x10) {x10=_ABinTree_Apostorder(x1);}
#endif

#endif
