

#line 1 "StudentDB.impl"
#include "BUILTIN.h"
extern OBJ __ANat_60;
extern OBJ __ANat_80;
extern OBJ __ABinSearchTree_3;
extern OBJ __ASeq_6;
extern OBJ __ABinTree_2;
extern OBJ __ABinTree_3;
extern OBJ __ABinTree_4;
extern OBJ __ABinTree_5;
extern OBJ __ABinTree_6;
extern OBJ __ABinTree_7;
extern OBJ __ABinTree_8;
extern OBJ __ABinTree_11;
extern OBJ __ANatConv_1;
extern OBJ __ADenotation_4;
OBJ __AStudentDB_2; /* f */
extern OBJ _AStudentDB_3(OBJ);OBJ __AStudentDB_3; /* f? */
OBJ __AStudentDB_4; /* m */
extern OBJ _AStudentDB_5(OBJ);OBJ __AStudentDB_5; /* m? */
extern OBJ _AStudentDB_7(OBJ,OBJ,OBJ,OBJ);OBJ __AStudentDB_7; /* student */
extern OBJ _AStudentDB_8(OBJ);OBJ __AStudentDB_8; /* student? */
extern OBJ _AStudentDB_9(OBJ);OBJ __AStudentDB_9; /* sex */
extern OBJ _AStudentDB_10(OBJ);OBJ __AStudentDB_10; /* surname */
extern OBJ _AStudentDB_11(OBJ);OBJ __AStudentDB_11; /* name */
extern OBJ _AStudentDB_12(OBJ);OBJ __AStudentDB_12; /* matric */
extern OBJ _AStudentDB_13(OBJ);OBJ __AStudentDB_13; /* studentList */
OBJ __AStudentDB_14; /* studentTree */
extern OBJ _AStudentDB_15(OBJ,OBJ);OBJ __AStudentDB_15; /* < */
extern OBJ _AStudentDB_16(OBJ);OBJ __AStudentDB_16; /* ` */
extern OBJ _AStudentDB_27(OBJ);OBJ __AStudentDB_27; /* `,1 */
OBJ __AStudentDB_28; /* student1 */
OBJ __AStudentDB_29; /* student2 */
OBJ __AStudentDB_30; /* student3 */
OBJ __AStudentDB_31; /* student4 */
OBJ __AStudentDB_32; /* student5 */
OBJ __AStudentDB_33; /* student6 */
OBJ __AStudentDB_34; /* student7 */
OBJ __AStudentDB_35; /* student8 */
OBJ __AStudentDB_36; /* student9 */
OBJ __AStudentDB_37; /* student5'37 */
OBJ __AStudentDB_38; /* student5'38 */
OBJ __AStudentDB_39; /* student5'39 */
OBJ __AStudentDB_40; /* student6'40 */
OBJ __AStudentDB_41; /* student6'41 */
OBJ __AStudentDB_42; /* student6'42 */
OBJ __AStudentDB_43; /* student7'43 */
OBJ __AStudentDB_44; /* student7'44 */
OBJ __AStudentDB_45; /* student7'45 */
OBJ __AStudentDB_46; /* student8'46 */
OBJ __AStudentDB_47; /* student8'47 */
OBJ __AStudentDB_48; /* student8'48 */
OBJ __AStudentDB_49; /* student9'49 */
OBJ __AStudentDB_50; /* student9'50 */
OBJ __AStudentDB_51; /* student9'51 */
OBJ __AStudentDB_52; /* `'52 */
OBJ __AStudentDB_53; /* `'53 */
OBJ __AStudentDB_54; /* `'54 */
OBJ __AStudentDB_55; /* `'55 */
OBJ __AStudentDB_56; /* `,1'56 */
OBJ __AStudentDB_57; /* `,1'57 */
OBJ __AStudentDB_58; /* student1'58 */
OBJ __AStudentDB_59; /* student1'59 */
OBJ __AStudentDB_60; /* student1'60 */
OBJ __AStudentDB_61; /* student2'61 */
OBJ __AStudentDB_62; /* student2'62 */
OBJ __AStudentDB_63; /* student2'63 */
OBJ __AStudentDB_64; /* student3'64 */
OBJ __AStudentDB_65; /* student3'65 */
OBJ __AStudentDB_66; /* student3'66 */
OBJ __AStudentDB_67; /* student4'67 */
OBJ __AStudentDB_68; /* student4'68 */
OBJ __AStudentDB_69; /* student4'69 */

extern OBJ _AStudentDB_3(OBJ x1) /* f? */
{OBJ r;
#line 13
 if(ISTGPRM(x1,1)){
#line 13
  r=__ABUILTIN_5;
#line 13
 }else{
#line 13
  r=__ABUILTIN_3;}
#line 13
 return r;}

extern OBJ _AStudentDB_5(OBJ x1) /* m? */
{OBJ r;
#line 13
 if(ISTGPRM(x1,0)){
#line 13
  r=__ABUILTIN_5;
#line 13
 }else{
#line 13
  r=__ABUILTIN_3;}
#line 13
 return r;}

extern OBJ _AStudentDB_7(OBJ x1,OBJ x2,OBJ x3,OBJ x4) /* student */
{OBJ r;
 PRD1(4,r);FLD1(r,1)=x1;FLD1(r,2)=x2;FLD1(r,3)=x3;FLD1(r,4)=x4;
 return r;}

extern OBJ _AStudentDB_8(OBJ x1) /* student? */
{OBJ r;
 FRPRD(x1,1);
#line 12
 r=__ABUILTIN_5;
#line 12
 return r;}

extern OBJ _AStudentDB_9(OBJ x1) /* sex */
{OBJ r;
 {OBJ x5=FLD1(x1,4);
  if(EXPRD(x1,1)){
   DSPRD(x1);
  }else{
   FRPRD(x1,1);}
  r=x5;}
 return r;}

extern OBJ _AStudentDB_10(OBJ x1) /* surname */
{OBJ r;
 {OBJ x4=FLD1(x1,3);
  if(EXPRD(x1,1)){
   FLD1(x1,3)=NIL;DSPRD(x1);
  }else{
   CPPRD(x4,1);
   FRPRD(x1,1);}
  r=x4;}
 return r;}

extern OBJ _AStudentDB_11(OBJ x1) /* name */
{OBJ r;
 {OBJ x3=FLD1(x1,2);
  if(EXPRD(x1,1)){
   FLD1(x1,2)=NIL;DSPRD(x1);
  }else{
   CPPRD(x3,1);
   FRPRD(x1,1);}
  r=x3;}
 return r;}

extern OBJ _AStudentDB_12(OBJ x1) /* matric */
{OBJ r;
 {OBJ x2=FLD1(x1,1);
  if(EXPRD(x1,1)){
   FLD1(x1,1)=NIL;DSPRD(x1);
  }else{
   COPY(x2,1);
   FRPRD(x1,1);}
  r=x2;}
 return r;}

extern OBJ _AStudentDB_13(OBJ x1) /* studentList */
{OBJ r;
 CPCLS(__ABinTree_8,1);
 COPY(x1,1);
#line 16
 {OBJ x2;
#line 16
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_8,1))(__ABinTree_8,x1);
#line 16
  if(ISTGPRM(x2,1)){
#line 16
   FREE(x1,1);
#line 16
   COPY(__ASeq_6,1);
#line 16
   r=__ASeq_6;
#line 16
  }else{
#line 16
   COPY(x1,1);
#line 16
   CPCLS(__ABinTree_3,1);
#line 16
   {OBJ x3;
#line 16
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_3,1))(__ABinTree_3,x1);
#line 16
    if(ISTGPRM(x3,1)){
#line 16
     COPY(x1,2);
#line 16
     CPCLS(__ABinTree_2,1);
#line 16
     CPCLS(__ABinTree_4,1);
#line 16
     CPCLS(__ABinTree_5,1);
#line 16
     CPCLS(__ABinTree_6,1);
#line 16
     CPCLS(__ABinTree_11,1);
#line 16
     {OBJ x4;OBJ x5;OBJ x6;OBJ x7;
#line 17
      x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_6,1))(__ABinTree_6,x1);
#line 17
      x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_5,1))(__ABinTree_5,x1);
#line 17
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_4,1))(__ABinTree_4,x1);
#line 17
      x7=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x4,x5,x6);
#line 17
      r=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_11,1))(__ABinTree_11,x7);}
#line 17
    }else{
#line 17
     HLT("StudentDB at <unknown> : missing else in studentList\'StudentDB:binTree->seq");}}}}
#line 17
 return r;}

extern OBJ _AStudentDB_15(OBJ x1,OBJ x2) /* < */
{OBJ r;
 CPCLS(__AStudentDB_8,1);
 CPPRD(x1,1);
#line 21
 {OBJ x3;
#line 21
  x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_8,1))(__AStudentDB_8,x1);
#line 21
  if(ISTGPRM(x3,1)){
#line 21
   CPPRD(x2,1);
#line 21
   CPCLS(__AStudentDB_8,1);
#line 21
   {OBJ x4;
#line 21
    x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_8,1))(__AStudentDB_8,x2);
#line 21
    if(ISTGPRM(x4,1)){
#line 21
     CPCLS(__AStudentDB_12,2);
#line 21
     CPCLS(__ANat_80,1);
#line 21
     {OBJ x5;OBJ x6;
#line 21
      x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_12,1))(__AStudentDB_12,x1);
#line 21
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_12,1))(__AStudentDB_12,x2);
#line 21
      r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ANat_80,2))(__ANat_80,x5,x6);}
#line 21
    }else{
#line 21
     HLT("StudentDB at <unknown> : missing else in <\'StudentDB:student**student->bool");}}
#line 21
  }else{
#line 21
   HLT("StudentDB at <unknown> : missing else in <\'StudentDB:student**student->bool");}}
#line 21
 return r;}

extern OBJ _AStudentDB_16(OBJ x1) /* ` */
{OBJ r;
 CPCLS(__AStudentDB_8,1);
 CPPRD(x1,1);
#line 24
 {OBJ x2;
#line 24
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_8,1))(__AStudentDB_8,x1);
#line 24
  if(ISTGPRM(x2,1)){
#line 24
   CPPRD(x1,3);
#line 24
   CPCLS(__AStudentDB_9,1);
#line 24
   CPCLS(__AStudentDB_10,1);
#line 24
   CPCLS(__AStudentDB_11,1);
#line 24
   CPCLS(__AStudentDB_12,1);
#line 24
   CPCLS(__AStudentDB_27,1);
#line 24
   CPPRD(__AStudentDB_52,1);
#line 24
   CPPRD(__AStudentDB_53,1);
#line 24
   CPPRD(__AStudentDB_54,1);
#line 24
   CPPRD(__AStudentDB_55,1);
#line 24
   CPCLS(__ANatConv_1,1);
#line 24
   CPCLS(__ADenotation_4,7);
#line 24
   {OBJ x3;OBJ x4;OBJ x5;OBJ x6;OBJ x7;OBJ x8;OBJ x9;OBJ x10;OBJ x11;OBJ x12;OBJ x13;OBJ x14;
#line 24
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_12,1))(__AStudentDB_12,x1);
#line 24
    x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_11,1))(__AStudentDB_11,x1);
#line 24
    x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_10,1))(__AStudentDB_10,x1);
#line 24
    x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_9,1))(__AStudentDB_9,x1);
#line 24
    x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANatConv_1,1))(__ANatConv_1,x3);
#line 24
    x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_27,1))(__AStudentDB_27,x6);
#line 24
    x9=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x8,__AStudentDB_52);
#line 24
    x10=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AStudentDB_53,x9);
#line 24
    x11=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x7,x10);
#line 24
    x12=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AStudentDB_54,x11);
#line 24
    x13=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x5,x12);
#line 24
    x14=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AStudentDB_55,x13);
#line 24
    r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x4,x14);}
#line 24
  }else{
#line 24
   HLT("StudentDB at <unknown> : missing else in `\'StudentDB:student->denotation");}}
#line 24
 return r;}

extern OBJ _AStudentDB_27(OBJ x1) /* `,1 */
{OBJ r;
 CPCLS(__AStudentDB_5,1);
#line 27
 {OBJ x2;
#line 26
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_5,1))(__AStudentDB_5,x1);
#line 26
  if(ISTGPRM(x2,1)){
#line 26
   CPPRD(__AStudentDB_57,1);
#line 26
   r=__AStudentDB_57;
#line 26
  }else{
#line 26
   CPCLS(__AStudentDB_3,1);
#line 26
   {OBJ x3;
#line 26
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_3,1))(__AStudentDB_3,x1);
#line 26
    if(ISTGPRM(x3,1)){
#line 26
     CPPRD(__AStudentDB_56,1);
#line 26
     r=__AStudentDB_56;
#line 26
    }else{
#line 26
     HLT("StudentDB at <26,5> : missing else in `\'StudentDB:sex->denotation");}}}}
#line 26
 return r;}



static void ___AStudentDB_14()
{
 CPCLS(__AStudentDB_15,9);
 CPPRD(__AStudentDB_28,1);
 CPPRD(__AStudentDB_29,1);
 CPPRD(__AStudentDB_30,1);
 CPPRD(__AStudentDB_31,1);
 CPPRD(__AStudentDB_32,1);
 CPPRD(__AStudentDB_33,1);
 CPPRD(__AStudentDB_34,1);
 CPPRD(__AStudentDB_35,1);
 CPPRD(__AStudentDB_36,1);
 CPCLS(__ABinSearchTree_3,9);
 COPY(__ABinTree_7,1);
 {OBJ x1;OBJ x2;OBJ x3;OBJ x4;OBJ x5;OBJ x6;OBJ x7;OBJ x8;
#line 42
  x1=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__AStudentDB_15,__AStudentDB_36,__ABinTree_7);
#line 42
  x2=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__AStudentDB_15,__AStudentDB_35,x1);
#line 42
  x3=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__AStudentDB_15,__AStudentDB_34,x2);
#line 42
  x4=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__AStudentDB_15,__AStudentDB_33,x3);
#line 42
  x5=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__AStudentDB_15,__AStudentDB_32,x4);
#line 42
  x6=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__AStudentDB_15,__AStudentDB_31,x5);
#line 42
  x7=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__AStudentDB_15,__AStudentDB_30,x6);
#line 42
  x8=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__AStudentDB_15,__AStudentDB_29,x7);
#line 42
  __AStudentDB_14=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__AStudentDB_15,__AStudentDB_28,x8);}}

static void ___AStudentDB_28()
{
 CPPRD(__AStudentDB_7,1);
 CPPRD(__AStudentDB_58,1);
 CPPRD(__AStudentDB_59,1);
 CPPRD(__AStudentDB_60,1);
 CPCLS(__ANat_60,1);
 {OBJ x1;
#line 32
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__AStudentDB_58);
#line 32
  __AStudentDB_28=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AStudentDB_7,4))(__AStudentDB_7,x1,__AStudentDB_59,__AStudentDB_60,__AStudentDB_4);}}

static void ___AStudentDB_29()
{
 CPPRD(__AStudentDB_7,1);
 CPPRD(__AStudentDB_61,1);
 CPPRD(__AStudentDB_62,1);
 CPPRD(__AStudentDB_63,1);
 CPCLS(__ANat_60,1);
 {OBJ x1;
#line 33
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__AStudentDB_61);
#line 33
  __AStudentDB_29=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AStudentDB_7,4))(__AStudentDB_7,x1,__AStudentDB_62,__AStudentDB_63,__AStudentDB_4);}}

static void ___AStudentDB_30()
{
 CPPRD(__AStudentDB_7,1);
 CPPRD(__AStudentDB_64,1);
 CPPRD(__AStudentDB_65,1);
 CPPRD(__AStudentDB_66,1);
 CPCLS(__ANat_60,1);
 {OBJ x1;
#line 34
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__AStudentDB_64);
#line 34
  __AStudentDB_30=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AStudentDB_7,4))(__AStudentDB_7,x1,__AStudentDB_65,__AStudentDB_66,__AStudentDB_4);}}

static void ___AStudentDB_31()
{
 CPPRD(__AStudentDB_7,1);
 CPPRD(__AStudentDB_67,1);
 CPPRD(__AStudentDB_68,1);
 CPPRD(__AStudentDB_69,1);
 CPCLS(__ANat_60,1);
 {OBJ x1;
#line 35
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__AStudentDB_67);
#line 35
  __AStudentDB_31=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AStudentDB_7,4))(__AStudentDB_7,x1,__AStudentDB_68,__AStudentDB_69,__AStudentDB_2);}}

static void ___AStudentDB_32()
{
 CPPRD(__AStudentDB_7,1);
 CPPRD(__AStudentDB_37,1);
 CPPRD(__AStudentDB_38,1);
 CPPRD(__AStudentDB_39,1);
 CPCLS(__ANat_60,1);
 {OBJ x1;
#line 36
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__AStudentDB_37);
#line 36
  __AStudentDB_32=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AStudentDB_7,4))(__AStudentDB_7,x1,__AStudentDB_38,__AStudentDB_39,__AStudentDB_4);}}

static void ___AStudentDB_33()
{
 CPPRD(__AStudentDB_7,1);
 CPPRD(__AStudentDB_40,1);
 CPPRD(__AStudentDB_41,1);
 CPPRD(__AStudentDB_42,1);
 CPCLS(__ANat_60,1);
 {OBJ x1;
#line 37
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__AStudentDB_40);
#line 37
  __AStudentDB_33=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AStudentDB_7,4))(__AStudentDB_7,x1,__AStudentDB_41,__AStudentDB_42,__AStudentDB_2);}}

static void ___AStudentDB_34()
{
 CPPRD(__AStudentDB_7,1);
 CPPRD(__AStudentDB_43,1);
 CPPRD(__AStudentDB_44,1);
 CPPRD(__AStudentDB_45,1);
 CPCLS(__ANat_60,1);
 {OBJ x1;
#line 38
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__AStudentDB_43);
#line 38
  __AStudentDB_34=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AStudentDB_7,4))(__AStudentDB_7,x1,__AStudentDB_44,__AStudentDB_45,__AStudentDB_4);}}

static void ___AStudentDB_35()
{
 CPPRD(__AStudentDB_7,1);
 CPPRD(__AStudentDB_46,1);
 CPPRD(__AStudentDB_47,1);
 CPPRD(__AStudentDB_48,1);
 CPCLS(__ANat_60,1);
 {OBJ x1;
#line 39
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__AStudentDB_46);
#line 39
  __AStudentDB_35=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AStudentDB_7,4))(__AStudentDB_7,x1,__AStudentDB_47,__AStudentDB_48,__AStudentDB_4);}}

static void ___AStudentDB_36()
{
 CPPRD(__AStudentDB_7,1);
 CPPRD(__AStudentDB_49,1);
 CPPRD(__AStudentDB_50,1);
 CPPRD(__AStudentDB_51,1);
 CPCLS(__ANat_60,1);
 {OBJ x1;
#line 40
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__AStudentDB_49);
#line 40
  __AStudentDB_36=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AStudentDB_7,4))(__AStudentDB_7,x1,__AStudentDB_50,__AStudentDB_51,__AStudentDB_2);}}

static OBJ _mt_1_0_1(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 return r;}
static OBJ _mt_1_0_1_l(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 COPY(r,1);LZYCLS(t,r);
 return r;}

static OBJ _mt_2_0_2(OBJ t,OBJ t1,OBJ t2) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ,OBJ))ENTRY(t))(t1,t2);
 return r;}

static OBJ _mt_4_0_4(OBJ t,OBJ t1,OBJ t2,OBJ t3,OBJ t4) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))ENTRY(t))(t1,t2,t3,t4);
 return r;}

extern void init_ANat();
extern void init_AReal();
extern void init_ABinSearchTree();
extern void init_ASeq();
extern void init_AOption();
extern void init_ABinTree();
extern void init_ANatConv();
extern void init_ADenotation();
extern void init_AChar();
extern void init_AInt();
void init_AStudentDB()
{
 static int visited=0; if(visited) return; visited=1;
 init_ANat();
 init_AReal();
 init_ABinSearchTree();
 init_ASeq();
 init_AOption();
 init_ABinTree();
 init_ANatConv();
 init_ADenotation();
 init_AChar();
 init_AInt();
 DEN("Edelstein",__AStudentDB_63);
 DEN("Ofir",__AStudentDB_62);
 DEN("163",__AStudentDB_61);
 DEN("Norman",__AStudentDB_60);
 DEN("Daniel",__AStudentDB_59);
 CLS(1,_AStudentDB_27,__AStudentDB_27);
 DEN("362",__AStudentDB_58);
 DEN("male",__AStudentDB_57);
 DEN("female",__AStudentDB_56);
 DEN(", ",__AStudentDB_55);
 DEN("  Matr.Nr.: ",__AStudentDB_54);
 DEN(" sex: ",__AStudentDB_53);
 DEN("\n",__AStudentDB_52);
 DEN("Norman",__AStudentDB_51);
 DEN("Anat",__AStudentDB_50);
 DEN("999",__AStudentDB_49);
 DEN("Norman",__AStudentDB_48);
 CLS(1,_AStudentDB_16,__AStudentDB_16);
 DEN("Rod",__AStudentDB_47);
 CLS(2,_AStudentDB_15,__AStudentDB_15);
 DEN("502",__AStudentDB_46);
 DEN("Wo",__AStudentDB_45);
 CLS(1,_AStudentDB_13,__AStudentDB_13);
 DEN("Wah",__AStudentDB_44);
 CLS(1,_AStudentDB_12,__AStudentDB_12);
 DEN("120",__AStudentDB_43);
 CLS(1,_AStudentDB_11,__AStudentDB_11);
 DEN("Hendler",__AStudentDB_42);
 CLS(1,_AStudentDB_10,__AStudentDB_10);
 DEN("Micky",__AStudentDB_41);
 CLS(1,_AStudentDB_9,__AStudentDB_9);
 DEN("864",__AStudentDB_40);
 CLS(1,_AStudentDB_8,__AStudentDB_8);
 DEN("Bergman",__AStudentDB_39);
 CLS(4,_AStudentDB_7,__AStudentDB_7);
 DEN("Wolf",__AStudentDB_38);
 DEN("Ezra",__AStudentDB_69);
 CLS(1,_AStudentDB_5,__AStudentDB_5);
 DEN("478",__AStudentDB_37);
 DEN("Jessica",__AStudentDB_68);
 DEN("645",__AStudentDB_67);
 CLS(1,_AStudentDB_3,__AStudentDB_3);
 DEN("Weinstock",__AStudentDB_66);
 DEN("Arik",__AStudentDB_65);
 DEN("742",__AStudentDB_64);
 MTH(1,0,1,_mt_1_0_1);LZYMTH(1,0,1,_mt_1_0_1_l);
 MTH(2,0,2,_mt_2_0_2);LZYMTH(2,0,2,_mt_2_0_2);
 MTH(4,0,4,_mt_4_0_4);LZYMTH(4,0,4,_mt_4_0_4);
 PRM(1,__AStudentDB_2);
 PRM(0,__AStudentDB_4);
 ___AStudentDB_28();
 ___AStudentDB_29();
 ___AStudentDB_30();
 ___AStudentDB_31();
 ___AStudentDB_32();
 ___AStudentDB_33();
 ___AStudentDB_34();
 ___AStudentDB_35();
 ___AStudentDB_36();
 ___AStudentDB_14();}

