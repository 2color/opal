

#line 1 "TreeTest.impl"
#include "BUILTIN.h"
extern OBJ __ANat_60;
extern OBJ __ANat_80;
extern OBJ __ABinTree_2;
extern OBJ __ABinTree_7;
extern OBJ __ABinTree_10;
extern OBJ __ABinTree_11;
extern OBJ __ABinTree_12;
extern OBJ __ADenotation_4;
extern OBJ __APrintTree_2;
extern OBJ __ANatConv_1;
extern OBJ __ASeqConv_2;
extern OBJ __ABinSearchTree_3;
extern OBJ __ABinSearchTree_5;
extern OBJ __AStudentDB_12;
extern OBJ __AStudentDB_13;
extern OBJ __AStudentDB_14;
extern OBJ __AStudentDB_16;
OBJ __ATreeTest_1; /* exampleTree */
OBJ __ATreeTest_2; /* test */
OBJ __ATreeTest_3; /* exampleSearchTree */
OBJ __ATreeTest_4; /* exampleTree'4 */
OBJ __ATreeTest_5; /* exampleTree'5 */
OBJ __ATreeTest_6; /* exampleTree'6 */
OBJ __ATreeTest_7; /* exampleTree'7 */
OBJ __ATreeTest_8; /* exampleTree'8 */
OBJ __ATreeTest_9; /* exampleTree'9 */
OBJ __ATreeTest_10; /* exampleTree'10 */
OBJ __ATreeTest_11; /* exampleTree'11 */
OBJ __ATreeTest_12; /* exampleTree'12 */
OBJ __ATreeTest_13; /* test'13 */
OBJ __ATreeTest_14; /* test'14 */
OBJ __ATreeTest_15; /* test'15 */
OBJ __ATreeTest_16; /* test'16 */
extern OBJ _ATreeTest_17(OBJ);OBJ __ATreeTest_17; /* test'17 */
OBJ __ATreeTest_18; /* test'18 */
OBJ __ATreeTest_19; /* test'19 */
OBJ __ATreeTest_20; /* test'20 */
OBJ __ATreeTest_21; /* test'21 */
OBJ __ATreeTest_22; /* test'22 */
OBJ __ATreeTest_23; /* test'23 */
OBJ __ATreeTest_24; /* test'24 */
OBJ __ATreeTest_25; /* test'25 */
OBJ __ATreeTest_26; /* test'26 */
OBJ __ATreeTest_27; /* test'27 */
OBJ __ATreeTest_28; /* test'28 */
OBJ __ATreeTest_29; /* test'29 */
OBJ __ATreeTest_30; /* test'30 */
OBJ __ATreeTest_31; /* test'31 */
OBJ __ATreeTest_32; /* test'32 */
OBJ __ATreeTest_33; /* test'33 */
OBJ __ATreeTest_34; /* test'34 */
OBJ __ATreeTest_35; /* test'35 */
OBJ __ATreeTest_36; /* test'36 */
OBJ __ATreeTest_37; /* test'37 */
OBJ __ATreeTest_38; /* test'38 */
OBJ __ATreeTest_39; /* test'39 */
OBJ __ATreeTest_40; /* test'40 */
OBJ __ATreeTest_41; /* test'41 */
OBJ __ATreeTest_42; /* test'42 */
OBJ __ATreeTest_43; /* test'43 */
OBJ __ATreeTest_44; /* test'44 */
OBJ __ATreeTest_45; /* test'45 */
OBJ __ATreeTest_46; /* test'46 */
OBJ __ATreeTest_47; /* test'47 */
OBJ __ATreeTest_48; /* test'48 */
OBJ __ATreeTest_49; /* test'49 */
OBJ __ATreeTest_50; /* test'50 */
OBJ __ATreeTest_51; /* test'51 */
OBJ __ATreeTest_52; /* test'52 */
OBJ __ATreeTest_53; /* test'53 */
OBJ __ATreeTest_54; /* exampleSearchTree'54 */
OBJ __ATreeTest_55; /* exampleSearchTree'55 */
OBJ __ATreeTest_56; /* exampleSearchTree'56 */
OBJ __ATreeTest_57; /* exampleSearchTree'57 */
OBJ __ATreeTest_58; /* exampleSearchTree'58 */
OBJ __ATreeTest_59; /* exampleSearchTree'59 */
OBJ __ATreeTest_60; /* exampleSearchTree'60 */
OBJ __ATreeTest_61; /* exampleSearchTree'61 */
OBJ __ATreeTest_62; /* exampleSearchTree'62 */
OBJ __ATreeTest_63; /* exampleSearchTree'63 */
OBJ __ATreeTest_64; /* exampleSearchTree'64 */
OBJ __ATreeTest_65; /* exampleSearchTree'65 */

extern OBJ _ATreeTest_17(OBJ x1) /* test'17 */
{OBJ r;
 CPCLS(__ANatConv_1,1);
 CPCLS(__AStudentDB_12,1);
#line 48
 {OBJ x2;
#line 48
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_12,1))(__AStudentDB_12,x1);
#line 48
  r=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANatConv_1,1))(__ANatConv_1,x2);}
#line 48
 return r;}

static void ___ATreeTest_1()
{
 CPPRD(__ATreeTest_4,1);
 CPPRD(__ATreeTest_5,1);
 CPPRD(__ATreeTest_6,1);
 CPPRD(__ATreeTest_7,1);
 CPPRD(__ATreeTest_8,1);
 CPPRD(__ATreeTest_9,1);
 CPPRD(__ATreeTest_10,1);
 CPPRD(__ATreeTest_11,1);
 CPPRD(__ATreeTest_12,1);
 CPCLS(__ANat_60,9);
 CPCLS(__ABinTree_2,9);
 COPY(__ABinTree_7,10);
 {OBJ x1;OBJ x2;OBJ x3;OBJ x4;OBJ x5;OBJ x6;OBJ x7;OBJ x8;OBJ x9;OBJ x10;OBJ x11;OBJ x12;OBJ x13;OBJ x14;OBJ x15;OBJ x16;OBJ x17;
#line 60
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_4);
#line 61
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_5);
#line 62
  x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_6);
#line 66
  x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_7);
#line 67
  x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_8);
#line 74
  x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_9);
#line 75
  x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_10);
#line 77
  x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_11);
#line 82
  x9=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_12);
#line 62
  x10=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x3,__ABinTree_7,__ABinTree_7);
#line 67
  x11=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x5,__ABinTree_7,__ABinTree_7);
#line 77
  x12=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x8,__ABinTree_7,__ABinTree_7);
#line 82
  x13=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x9,__ABinTree_7,__ABinTree_7);
#line 66
  x14=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x4,x11,__ABinTree_7);
#line 75
  x15=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x7,__ABinTree_7,x12);
#line 61
  x16=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x2,x10,x14);
#line 74
  x17=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x6,x15,x13);
#line 60
  __ATreeTest_1=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinTree_2,3))(__ABinTree_2,x1,x16,x17);}}

static void ___ATreeTest_2()
{
 COPY(__ATreeTest_1,4);
 COPY(__ATreeTest_3,3);
 CPPRD(__ATreeTest_13,1);
 CPPRD(__ATreeTest_14,1);
 CPPRD(__ATreeTest_15,1);
 CPPRD(__ATreeTest_16,1);
 CPCLS(__ATreeTest_17,1);
 CPPRD(__ATreeTest_18,1);
 CPPRD(__ATreeTest_19,1);
 CPPRD(__ATreeTest_20,1);
 CPPRD(__ATreeTest_21,1);
 CPPRD(__ATreeTest_22,1);
 CPPRD(__ATreeTest_23,1);
 CPPRD(__ATreeTest_24,1);
 CPPRD(__ATreeTest_25,1);
 CPPRD(__ATreeTest_26,1);
 CPPRD(__ATreeTest_27,1);
 CPPRD(__ATreeTest_28,1);
 CPPRD(__ATreeTest_29,1);
 CPPRD(__ATreeTest_30,1);
 CPPRD(__ATreeTest_31,1);
 CPPRD(__ATreeTest_32,1);
 CPPRD(__ATreeTest_33,1);
 CPPRD(__ATreeTest_34,1);
 CPPRD(__ATreeTest_35,1);
 CPPRD(__ATreeTest_36,1);
 CPPRD(__ATreeTest_37,1);
 CPPRD(__ATreeTest_38,1);
 CPPRD(__ATreeTest_39,1);
 CPPRD(__ATreeTest_40,1);
 CPPRD(__ATreeTest_41,1);
 CPPRD(__ATreeTest_42,1);
 CPPRD(__ATreeTest_43,1);
 CPPRD(__ATreeTest_44,1);
 CPPRD(__ATreeTest_45,1);
 CPPRD(__ATreeTest_46,1);
 CPPRD(__ATreeTest_47,1);
 CPPRD(__ATreeTest_48,1);
 CPPRD(__ATreeTest_49,1);
 CPPRD(__ATreeTest_50,1);
 CPPRD(__ATreeTest_51,1);
 CPPRD(__ATreeTest_52,1);
 CPPRD(__ATreeTest_53,1);
 CPCLS(__ANat_60,2);
 CPCLS(__ANat_80,2);
 CPCLS(__ABinTree_10,1);
 CPCLS(__ABinTree_11,1);
 CPCLS(__ABinTree_12,1);
 CPCLS(__ADenotation_4,49);
 CPCLS(__APrintTree_2,5);
 CPCLS(__ANatConv_1,7);
 CPCLS(__ASeqConv_2,4);
 CPCLS(__ABinSearchTree_5,2);
 CPCLS(__AStudentDB_13,1);
 COPY(__AStudentDB_14,2);
 CPCLS(__AStudentDB_16,1);
 {OBJ x1;OBJ x2;OBJ x3;OBJ x4;OBJ x5;OBJ x6;OBJ x7;OBJ x8;OBJ x9;OBJ x10;OBJ x11;OBJ x12;OBJ x13;OBJ x14;OBJ x15;OBJ x16;OBJ x17;OBJ x18;OBJ x19;OBJ x20;OBJ x21;OBJ x22;OBJ x23;OBJ x24;OBJ x25;OBJ x26;OBJ x27;OBJ x28;OBJ x29;OBJ x30;OBJ x31;OBJ x32;OBJ x33;OBJ x34;OBJ x35;OBJ x36;OBJ x37;OBJ x38;OBJ x39;OBJ x40;OBJ x41;OBJ x42;OBJ x43;OBJ x44;OBJ x45;OBJ x46;OBJ x47;OBJ x48;OBJ x49;OBJ x50;OBJ x51;OBJ x52;OBJ x53;OBJ x54;OBJ x55;OBJ x56;OBJ x57;OBJ x58;OBJ x59;OBJ x60;OBJ x61;OBJ x62;OBJ x63;OBJ x64;OBJ x65;
#line 19
  x1=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__APrintTree_2,2))(__APrintTree_2,__ANatConv_1,__ATreeTest_1);
#line 19
  CPPRD(x1,2);
#line 20
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_10,1))(__ABinTree_10,__ATreeTest_1);
#line 25
  x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_11,1))(__ABinTree_11,__ATreeTest_1);
#line 30
  x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABinTree_12,1))(__ABinTree_12,__ATreeTest_1);
#line 34
  x5=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__APrintTree_2,2))(__APrintTree_2,__ANatConv_1,__ATreeTest_3);
#line 34
  CPPRD(x5,1);
#line 37
  x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_13);
#line 44
  x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_14);
#line 51
  x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__AStudentDB_13,1))(__AStudentDB_13,__AStudentDB_14);
#line 51
  x9=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_15,__ATreeTest_16);
#line 20
  x10=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeqConv_2,2))(__ASeqConv_2,__ANatConv_1,x2);
#line 25
  x11=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeqConv_2,2))(__ASeqConv_2,__ANatConv_1,x3);
#line 30
  x12=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeqConv_2,2))(__ASeqConv_2,__ANatConv_1,x4);
#line 37
  x13=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_5,3))(__ABinSearchTree_5,__ANat_80,x6,__ATreeTest_3);
#line 44
  x14=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_5,3))(__ABinSearchTree_5,__ANat_80,x7,__ATreeTest_3);
#line 51
  x15=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeqConv_2,2))(__ASeqConv_2,__AStudentDB_16,x8);
#line 37
  x16=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__APrintTree_2,2))(__APrintTree_2,__ANatConv_1,x13);
#line 44
  x17=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__APrintTree_2,2))(__APrintTree_2,__ANatConv_1,x14);
#line 51
  x18=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x15,x9);
#line 48
  x19=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__APrintTree_2,2))(__APrintTree_2,__ATreeTest_17,__AStudentDB_14);
#line 50
  x20=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_18,x18);
#line 49
  x21=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_19,x20);
#line 48
  x22=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_20,x21);
#line 48
  x23=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x19,x22);
#line 47
  x24=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_21,x23);
#line 46
  x25=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_22,x24);
#line 45
  x26=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_23,x25);
#line 44
  x27=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_24,x26);
#line 44
  x28=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x17,x27);
#line 43
  x29=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_25,x28);
#line 42
  x30=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_26,x29);
#line 41
  x31=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_27,x30);
#line 41
  x32=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x5,x31);
#line 40
  x33=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_28,x32);
#line 39
  x34=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_29,x33);
#line 38
  x35=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_30,x34);
#line 37
  x36=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_31,x35);
#line 37
  x37=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x16,x36);
#line 36
  x38=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_32,x37);
#line 35
  x39=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_33,x38);
#line 34
  x40=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_34,x39);
#line 34
  x41=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x5,x40);
#line 33
  x42=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_35,x41);
#line 32
  x43=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_36,x42);
#line 31
  x44=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_37,x43);
#line 30
  x45=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_38,x44);
#line 30
  x46=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x12,x45);
#line 29
  x47=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_39,x46);
#line 28
  x48=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_40,x47);
#line 28
  x49=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x1,x48);
#line 27
  x50=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_41,x49);
#line 26
  x51=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_42,x50);
#line 25
  x52=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_43,x51);
#line 25
  x53=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x11,x52);
#line 24
  x54=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_44,x53);
#line 23
  x55=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_45,x54);
#line 23
  x56=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x1,x55);
#line 22
  x57=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_46,x56);
#line 21
  x58=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_47,x57);
#line 20
  x59=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_48,x58);
#line 20
  x60=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x10,x59);
#line 19
  x61=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_49,x60);
#line 19
  x62=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x1,x61);
#line 18
  x63=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_50,x62);
#line 17
  x64=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_51,x63);
#line 16
  x65=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_52,x64);
#line 15
  __ATreeTest_2=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__ATreeTest_53,x65);}}

static void ___ATreeTest_3()
{
 CPPRD(__ATreeTest_54,1);
 CPPRD(__ATreeTest_55,1);
 CPPRD(__ATreeTest_56,1);
 CPPRD(__ATreeTest_57,1);
 CPPRD(__ATreeTest_58,1);
 CPPRD(__ATreeTest_59,1);
 CPPRD(__ATreeTest_60,1);
 CPPRD(__ATreeTest_61,1);
 CPPRD(__ATreeTest_62,1);
 CPPRD(__ATreeTest_63,1);
 CPPRD(__ATreeTest_64,1);
 CPPRD(__ATreeTest_65,1);
 CPCLS(__ANat_60,12);
 CPCLS(__ANat_80,13);
 COPY(__ABinTree_7,1);
 CPCLS(__ABinSearchTree_3,13);
 {OBJ x1;OBJ x2;OBJ x3;OBJ x4;OBJ x5;OBJ x6;OBJ x7;OBJ x8;OBJ x9;OBJ x10;OBJ x11;OBJ x12;OBJ x13;OBJ x14;OBJ x15;OBJ x16;OBJ x17;OBJ x18;OBJ x19;OBJ x20;OBJ x21;OBJ x22;OBJ x23;OBJ x24;
#line 56
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_54);
#line 56
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_55);
#line 56
  COPY(x2,1);
#line 56
  x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_56);
#line 56
  x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_57);
#line 56
  x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_58);
#line 56
  x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_59);
#line 56
  x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_60);
#line 56
  x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_61);
#line 56
  x9=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_62);
#line 56
  x10=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_63);
#line 56
  x11=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_64);
#line 56
  x12=(*(OBJ(*)(OBJ,OBJ))METHOD(__ANat_60,1))(__ANat_60,__ATreeTest_65);
#line 56
  x13=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x2,__ABinTree_7);
#line 56
  x14=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x12,x13);
#line 56
  x15=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x11,x14);
#line 56
  x16=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x10,x15);
#line 56
  x17=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x9,x16);
#line 56
  x18=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x8,x17);
#line 56
  x19=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x7,x18);
#line 56
  x20=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x6,x19);
#line 56
  x21=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x5,x20);
#line 56
  x22=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x4,x21);
#line 56
  x23=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x3,x22);
#line 56
  x24=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x2,x23);
#line 56
  __ATreeTest_3=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ABinSearchTree_3,3))(__ABinSearchTree_3,__ANat_80,x1,x24);}}

static OBJ _mt_1_0_1(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 return r;}
static OBJ _mt_1_0_1_l(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 COPY(r,1);LZYCLS(t,r);
 return r;}

extern void init_ANat();
extern void init_ASeq();
extern void init_ABinTree();
extern void init_AOption();
extern void init_ADenotation();
extern void init_APrintTree();
extern void init_ANatConv();
extern void init_ASeqConv();
extern void init_ABinSearchTree();
extern void init_AStudentDB();
extern void init_AReal();
extern void init_AString();
extern void init_AChar();
extern void init_AInt();
void init_ATreeTest()
{
 static int visited=0; if(visited) return; visited=1;
 init_ANat();
 init_ASeq();
 init_ABinTree();
 init_AOption();
 init_ADenotation();
 init_APrintTree();
 init_ANatConv();
 init_ASeqConv();
 init_ABinSearchTree();
 init_AStudentDB();
 init_AReal();
 init_AString();
 init_AChar();
 init_AInt();
 DEN("9",__ATreeTest_63);
 DEN("\n",__ATreeTest_31);
 DEN("2",__ATreeTest_62);
 DEN("\n------------------------------------------------------\n",__ATreeTest_30);
 DEN("6",__ATreeTest_61);
 DEN("delete \n",__ATreeTest_29);
 DEN("24",__ATreeTest_60);
 DEN("before delete \n",__ATreeTest_28);
 DEN("32",__ATreeTest_59);
 DEN("\n",__ATreeTest_27);
 DEN("63",__ATreeTest_58);
 DEN("\n",__ATreeTest_26);
 DEN("54",__ATreeTest_57);
 DEN("after deleting 29 \n",__ATreeTest_25);
 DEN("10",__ATreeTest_56);
 DEN("\n",__ATreeTest_24);
 DEN("76",__ATreeTest_55);
 DEN("\n------------------------------------------------------\n",__ATreeTest_23);
 DEN("31",__ATreeTest_54);
 DEN("student tree \n",__ATreeTest_22);
 DEN("------------------------------------------------------\n",__ATreeTest_53);
 DEN("as a tree (only the matric number for simplicity) \n",__ATreeTest_21);
 DEN("Tree Test Module \n",__ATreeTest_52);
 DEN("\n",__ATreeTest_20);
 DEN("------------------------------------------------------\n",__ATreeTest_51);
 DEN("\n",__ATreeTest_19);
 DEN("preorder \n",__ATreeTest_50);
 DEN("as an ordered list \n",__ATreeTest_18);
 DEN("\n",__ATreeTest_49);
 CLS(1,_ATreeTest_17,__ATreeTest_17);
 DEN("\n",__ATreeTest_48);
 DEN("\n------------------------------------------------------",__ATreeTest_16);
 DEN("------------------------------------------------------\n",__ATreeTest_47);
 DEN("\n",__ATreeTest_15);
 DEN("inorder \n",__ATreeTest_46);
 DEN("29",__ATreeTest_14);
 DEN("\n",__ATreeTest_45);
 DEN("17",__ATreeTest_13);
 DEN("\n",__ATreeTest_44);
 DEN("80",__ATreeTest_12);
 DEN("\n",__ATreeTest_43);
 DEN("1",__ATreeTest_11);
 DEN("\n------------------------------------------------------\n",__ATreeTest_42);
 DEN("62",__ATreeTest_10);
 DEN("postorder \n",__ATreeTest_41);
 DEN("13",__ATreeTest_9);
 DEN("\n",__ATreeTest_40);
 DEN("2",__ATreeTest_8);
 DEN("\n",__ATreeTest_39);
 DEN("8",__ATreeTest_7);
 DEN("\n",__ATreeTest_38);
 DEN("99",__ATreeTest_6);
 DEN("\n------------------------------------------------------\n",__ATreeTest_37);
 DEN("56",__ATreeTest_5);
 DEN("delete \n",__ATreeTest_36);
 DEN("30",__ATreeTest_4);
 DEN("before delete \n",__ATreeTest_35);
 DEN("\n",__ATreeTest_34);
 DEN("29",__ATreeTest_65);
 DEN("\n",__ATreeTest_33);
 DEN("17",__ATreeTest_64);
 DEN("after deleting 17 \n",__ATreeTest_32);
 MTH(1,0,1,_mt_1_0_1);LZYMTH(1,0,1,_mt_1_0_1_l);
 ___ATreeTest_1();
 ___ATreeTest_3();
 ___ATreeTest_2();}

