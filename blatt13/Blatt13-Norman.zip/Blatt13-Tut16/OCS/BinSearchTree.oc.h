

#ifndef ABinSearchTree_included
#define ABinSearchTree_included

#define __ABinSearchTree_Ainsert __ABinSearchTree_3
#define _ABinSearchTree_Ainsert _ABinSearchTree_3
extern OBJ __ABinSearchTree_Ainsert;
extern OBJ _ABinSearchTree_Ainsert(OBJ,OBJ,OBJ);

#define __ABinSearchTree_Afind __ABinSearchTree_4
#define _ABinSearchTree_Afind _ABinSearchTree_4
extern OBJ __ABinSearchTree_Afind;
extern OBJ _ABinSearchTree_Afind(OBJ,OBJ,OBJ);

#define __ABinSearchTree_Adelete __ABinSearchTree_5
#define _ABinSearchTree_Adelete _ABinSearchTree_5
extern OBJ __ABinSearchTree_Adelete;
extern OBJ _ABinSearchTree_Adelete(OBJ,OBJ,OBJ);

#define __ABinSearchTree_AfindBiggest __ABinSearchTree_9
#define _ABinSearchTree_AfindBiggest _ABinSearchTree_9
extern OBJ __ABinSearchTree_AfindBiggest;
extern OBJ _ABinSearchTree_AfindBiggest(OBJ,OBJ);

#define __ABinSearchTree_Sg __ABinSearchTree_10
#define _ABinSearchTree_Sg _ABinSearchTree_10
extern OBJ __ABinSearchTree_Sg;
extern OBJ _ABinSearchTree_Sg(OBJ,OBJ,OBJ);

#define __ABinSearchTree_Se __ABinSearchTree_11
#define _ABinSearchTree_Se _ABinSearchTree_11
extern OBJ __ABinSearchTree_Se;
extern OBJ _ABinSearchTree_Se(OBJ,OBJ,OBJ);

#ifndef ABinSearchTree_Ainsert
#define ABinSearchTree_Ainsert(x1,x2,x3,x14) {x14=_ABinSearchTree_Ainsert(x1,x2,x3);}
#endif

#ifndef ABinSearchTree_Afind
#define ABinSearchTree_Afind(x1,x2,x3,x12) {x12=_ABinSearchTree_Afind(x1,x2,x3);}
#endif

#ifndef ABinSearchTree_Adelete
#define ABinSearchTree_Adelete(x1,x2,x3,x28) {x28=_ABinSearchTree_Adelete(x1,x2,x3);}
#endif

#ifndef ABinSearchTree_AfindBiggest
#define ABinSearchTree_AfindBiggest(x1,x2,x8) {x8=_ABinSearchTree_AfindBiggest(x1,x2);}
#endif

#ifndef ABinSearchTree_Sg
#define ABinSearchTree_Sg(x1,x2,x3,x4) {x4=_ABinSearchTree_Sg(x1,x2,x3);}
#endif

#ifndef ABinSearchTree_Se
#define ABinSearchTree_Se(x1,x2,x3,x8) {x8=_ABinSearchTree_Se(x1,x2,x3);}
#endif

#endif
