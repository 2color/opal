

#line 1 "Parser.impl"
#include "BUILTIN.h"
extern OBJ __AToken_2;
extern OBJ __AToken_3;
extern OBJ __AToken_5;
extern OBJ __AToken_7;
extern OBJ __AToken_9;
extern OBJ __AToken_11;
extern OBJ __AToken_13;
extern OBJ __AToken_15;
extern OBJ __AToken_17;
extern OBJ __AToken_19;
extern OBJ __AToken_21;
extern OBJ __AScanner_1;
extern OBJ __ASeq_2;
extern OBJ __ASeq_3;
extern OBJ __ASeq_4;
extern OBJ __ASeq_5;
extern OBJ __ABoolConv_1;
extern OBJ __ADenotation_4;
extern OBJ __ACompose_4;
extern OBJ __ABool_9;
extern OBJ __ABool_17;
extern OBJ _AParser_1(OBJ);OBJ __AParser_1; /* eval */
OBJ __AParser_3; /* fail */
extern OBJ _AParser_4(OBJ);OBJ __AParser_4; /* fail? */
OBJ __AParser_5; /* false */
extern OBJ _AParser_6(OBJ);OBJ __AParser_6; /* false? */
OBJ __AParser_7; /* true */
extern OBJ _AParser_8(OBJ);OBJ __AParser_8; /* true? */
OBJ __AParser_10; /* fail,1 */
extern OBJ _AParser_11(OBJ);OBJ __AParser_11; /* fail?,1 */
OBJ __AParser_12; /* equiv */
extern OBJ _AParser_13(OBJ);OBJ __AParser_13; /* equiv? */
OBJ __AParser_14; /* impl */
extern OBJ _AParser_15(OBJ);OBJ __AParser_15; /* impl? */
OBJ __AParser_16; /* or */
extern OBJ _AParser_17(OBJ);OBJ __AParser_17; /* or? */
OBJ __AParser_18; /* and */
extern OBJ _AParser_19(OBJ);OBJ __AParser_19; /* and? */
OBJ __AParser_21; /* fail,2 */
extern OBJ _AParser_22(OBJ);OBJ __AParser_22; /* fail?,2 */
extern OBJ _AParser_23(OBJ,OBJ,OBJ);OBJ __AParser_23; /* binOp */
extern OBJ _AParser_24(OBJ);OBJ __AParser_24; /* binOp? */
extern OBJ _AParser_25(OBJ);OBJ __AParser_25; /* right */
extern OBJ _AParser_26(OBJ);OBJ __AParser_26; /* left */
extern OBJ _AParser_27(OBJ);OBJ __AParser_27; /* op */
extern OBJ _AParser_28(OBJ);OBJ __AParser_28; /* not */
extern OBJ _AParser_29(OBJ);OBJ __AParser_29; /* not? */
extern OBJ _AParser_30(OBJ);OBJ __AParser_30; /* arg */
extern OBJ _AParser_31(OBJ);OBJ __AParser_31; /* boolLit */
extern OBJ _AParser_32(OBJ);OBJ __AParser_32; /* boolLit? */
extern OBJ _AParser_33(OBJ);OBJ __AParser_33; /* value */
extern OBJ _AParser_34(OBJ);OBJ __AParser_34; /* error? */
extern OBJ _AParser_35(OBJ);OBJ __AParser_35; /* parse */
extern TUP2 _AParser_36(OBJ);OBJ __AParser_36; /* parseExpr */
extern OBJ _AParser_37(OBJ);OBJ __AParser_37; /* parseClose */
extern TUP2 _AParser_38(OBJ);OBJ __AParser_38; /* parseBinOp */
extern OBJ _AParser_39(OBJ);OBJ __AParser_39; /* evalExpr */
extern OBJ _AParser_40(OBJ);OBJ __AParser_40; /* ` */
OBJ __AParser_41; /* eval'41 */
OBJ __AParser_42; /* `'42 */
OBJ __AParser_43; /* `'43 */
OBJ __AParser_44; /* `'44 */
OBJ __AParser_45; /* `'45 */
OBJ __AParser_46; /* `'46 */
OBJ __AParser_47; /* `'47 */
OBJ __AParser_48; /* `'48 */
OBJ __AParser_49; /* `'49 */
OBJ __AParser_50; /* `'50 */
OBJ __AParser_51; /* `'51 */
OBJ __AParser_52; /* `'52 */
OBJ __AParser_53; /* `'53 */
OBJ __AParser_54; /* `'54 */
OBJ __AParser_55; /* `'55 */
OBJ __AParser_56; /* `'56 */
OBJ __AParser_57; /* `'57 */
OBJ __AParser_58; /* `'58 */
OBJ __AParser_59; /* `'59 */

extern OBJ _AParser_1(OBJ x1) /* eval */
{OBJ r;
 CPCLS(__AParser_22,1);
 CPCLS(__AParser_35,1);
 CPCLS(__AScanner_1,1);
 CPCLS(__ACompose_4,1);
#line 88
 {OBJ x2;OBJ x3;
#line 90
  x2=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ACompose_4,3))(__ACompose_4,__AParser_35,__AScanner_1,x1);
#line 90
  COPY(x2,1);
#line 92
  x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_22,1))(__AParser_22,x2);
#line 92
  if(ISTGPRM(x3,1)){
#line 92
   FREE(x2,1);
#line 92
   CPPRD(__AParser_41,1);
#line 92
   r=__AParser_41;
#line 92
  }else{
#line 92
   CPCLS(__AParser_39,1);
#line 92
   CPCLS(__ABoolConv_1,1);
#line 92
   {OBJ x4;
#line 93
    x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_39,1))(__AParser_39,x2);
#line 93
    r=(*(OBJ(*)(OBJ,OBJ))METHOD(__ABoolConv_1,1))(__ABoolConv_1,x4);}}}
#line 93
 return r;}

extern OBJ _AParser_4(OBJ x1) /* fail? */
{OBJ r;
#line 20
 if(ISTGPRM(x1,2)){
#line 20
  r=__ABUILTIN_5;
#line 20
 }else{
#line 20
  r=__ABUILTIN_3;}
#line 20
 return r;}

extern OBJ _AParser_6(OBJ x1) /* false? */
{OBJ r;
#line 20
 if(ISTGPRM(x1,1)){
#line 20
  r=__ABUILTIN_5;
#line 20
 }else{
#line 20
  r=__ABUILTIN_3;}
#line 20
 return r;}

extern OBJ _AParser_8(OBJ x1) /* true? */
{OBJ r;
#line 20
 if(ISTGPRM(x1,0)){
#line 20
  r=__ABUILTIN_5;
#line 20
 }else{
#line 20
  r=__ABUILTIN_3;}
#line 20
 return r;}

extern OBJ _AParser_11(OBJ x1) /* fail?,1 */
{OBJ r;
#line 18
 if(ISTGPRM(x1,4)){
#line 18
  r=__ABUILTIN_5;
#line 18
 }else{
#line 18
  r=__ABUILTIN_3;}
#line 18
 return r;}

extern OBJ _AParser_13(OBJ x1) /* equiv? */
{OBJ r;
#line 18
 if(ISTGPRM(x1,3)){
#line 18
  r=__ABUILTIN_5;
#line 18
 }else{
#line 18
  r=__ABUILTIN_3;}
#line 18
 return r;}

extern OBJ _AParser_15(OBJ x1) /* impl? */
{OBJ r;
#line 18
 if(ISTGPRM(x1,2)){
#line 18
  r=__ABUILTIN_5;
#line 18
 }else{
#line 18
  r=__ABUILTIN_3;}
#line 18
 return r;}

extern OBJ _AParser_17(OBJ x1) /* or? */
{OBJ r;
#line 18
 if(ISTGPRM(x1,1)){
#line 18
  r=__ABUILTIN_5;
#line 18
 }else{
#line 18
  r=__ABUILTIN_3;}
#line 18
 return r;}

extern OBJ _AParser_19(OBJ x1) /* and? */
{OBJ r;
#line 18
 if(ISTGPRM(x1,0)){
#line 18
  r=__ABUILTIN_5;
#line 18
 }else{
#line 18
  r=__ABUILTIN_3;}
#line 18
 return r;}

extern OBJ _AParser_22(OBJ x1) /* fail?,2 */
{OBJ r;
#line 16
 if(ISPRM(x1)){
#line 16
  r=__ABUILTIN_5;
#line 16
 }else{
#line 16
  FREE(x1,1);
#line 16
  r=__ABUILTIN_3;}
#line 16
 return r;}

extern OBJ _AParser_23(OBJ x1,OBJ x2,OBJ x3) /* binOp */
{OBJ r;
 PRD(3,2,r);FLD(r,1)=x1;FLD(r,2)=x2;FLD(r,3)=x3;
 return r;}

extern OBJ _AParser_24(OBJ x1) /* binOp? */
{OBJ r;
#line 15
 if(ISPRD(x1)&&(ISTGPRD(x1,2))){
#line 15
  if(EXPRD(x1,1)){
#line 15
   DSPRD(x1);
#line 15
  }else{
#line 15
   DCPRD(x1,1);}
#line 15
  r=__ABUILTIN_5;
#line 15
 }else{
#line 15
  FREE(x1,1);
#line 15
  r=__ABUILTIN_3;}
#line 15
 return r;}

extern OBJ _AParser_25(OBJ x1) /* right */
{OBJ r;
#line 15
 if(ISPRD(x1)&&(ISTGPRD(x1,2))){
#line 15
  {OBJ x4=FLD(x1,3);
#line 15
   if(EXPRD(x1,1)){
#line 15
    FLD(x1,3)=NIL;DSPRD(x1);
#line 15
   }else{
#line 15
    COPY(x4,1);
#line 15
    FRPRD(x1,1);}
#line 15
   r=x4;}
#line 15
 }else{
#line 15
  HLT("Parser at <15,43-47> : undefined selection right\'Parser:expr->expr");}
#line 15
 return r;}

extern OBJ _AParser_26(OBJ x1) /* left */
{OBJ r;
#line 15
 if(ISPRD(x1)&&(ISTGPRD(x1,2))){
#line 15
  {OBJ x3=FLD(x1,2);
#line 15
   if(EXPRD(x1,1)){
#line 15
    FLD(x1,2)=NIL;DSPRD(x1);
#line 15
   }else{
#line 15
    COPY(x3,1);
#line 15
    FRPRD(x1,1);}
#line 15
   r=x3;}
#line 15
 }else{
#line 15
  HLT("Parser at <15,31-34> : undefined selection left\'Parser:expr->expr");}
#line 15
 return r;}

extern OBJ _AParser_27(OBJ x1) /* op */
{OBJ r;
#line 15
 if(ISPRD(x1)&&(ISTGPRD(x1,2))){
#line 15
  {OBJ x2=FLD(x1,1);
#line 15
   if(EXPRD(x1,1)){
#line 15
    DSPRD(x1);
#line 15
   }else{
#line 15
    FRPRD(x1,1);}
#line 15
   r=x2;}
#line 15
 }else{
#line 15
  HLT("Parser at <15,20-21> : undefined selection op\'Parser:expr->binOp");}
#line 15
 return r;}

extern OBJ _AParser_28(OBJ x1) /* not */
{OBJ r;
 PRD(1,1,r);FLD(r,1)=x1;
 return r;}

extern OBJ _AParser_29(OBJ x1) /* not? */
{OBJ r;
#line 14
 if(ISPRD(x1)&&(ISTGPRD(x1,1))){
#line 14
  if(EXPRD(x1,1)){
#line 14
   DSPRD(x1);
#line 14
  }else{
#line 14
   DCPRD(x1,1);}
#line 14
  r=__ABUILTIN_5;
#line 14
 }else{
#line 14
  FREE(x1,1);
#line 14
  r=__ABUILTIN_3;}
#line 14
 return r;}

extern OBJ _AParser_30(OBJ x1) /* arg */
{OBJ r;
#line 14
 if(ISPRD(x1)&&(ISTGPRD(x1,1))){
#line 14
  {OBJ x2=FLD(x1,1);
#line 14
   if(EXPRD(x1,1)){
#line 14
    DSPRDF(x1);
#line 14
   }else{
#line 14
    COPY(x2,1);
#line 14
    FRPRD(x1,1);}
#line 14
   r=x2;}
#line 14
 }else{
#line 14
  HLT("Parser at <14,18-20> : undefined selection arg\'Parser:expr->expr");}
#line 14
 return r;}

extern OBJ _AParser_31(OBJ x1) /* boolLit */
{OBJ r;
 PRDF(1,0,r);FLD(r,1)=x1;
 return r;}

extern OBJ _AParser_32(OBJ x1) /* boolLit? */
{OBJ r;
#line 13
 if(ISPRD(x1)&&(ISTGPRD(x1,0))){
#line 13
  if(EXPRD(x1,1)){
#line 13
   DSPRDF(x1);
#line 13
  }else{
#line 13
   DCPRD(x1,1);}
#line 13
  r=__ABUILTIN_5;
#line 13
 }else{
#line 13
  FREE(x1,1);
#line 13
  r=__ABUILTIN_3;}
#line 13
 return r;}

extern OBJ _AParser_33(OBJ x1) /* value */
{OBJ r;
#line 13
 if(ISPRD(x1)&&(ISTGPRD(x1,0))){
#line 13
  {OBJ x2=FLD(x1,1);
#line 13
   if(EXPRD(x1,1)){
#line 13
    DSPRDF(x1);
#line 13
   }else{
#line 13
    FRPRD(x1,1);}
#line 13
   r=x2;}
#line 13
 }else{
#line 13
  HLT("Parser at <13,22-26> : undefined selection value\'Parser:expr->boolLit");}
#line 13
 return r;}

extern OBJ _AParser_34(OBJ x1) /* error? */
{OBJ r;
 CPCLS(__ASeq_3,1);
 COPY(x1,1);
#line 25
 {OBJ x2;
#line 24
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_3,1))(__ASeq_3,x1);
#line 24
  if(ISTGPRM(x2,1)){
#line 24
   CPCLS(__AToken_3,1);
#line 24
   CPCLS(__ASeq_5,1);
#line 24
   {OBJ x3;OBJ x4;
#line 24
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_5,1))(__ASeq_5,x1);
#line 24
    x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_3,1))(__AToken_3,x3);
#line 24
    if(ISTGPRM(x4,1)){
#line 25
     r=__ABUILTIN_5;
#line 25
    }else{
#line 26
     r=__ABUILTIN_3;}}
#line 26
  }else{
#line 26
   FREE(x1,1);
#line 26
   r=__ABUILTIN_3;}}
#line 26
 return r;}

extern OBJ _AParser_35(OBJ x1) /* parse */
{OBJ r;
 CPCLS(__AParser_22,1);
 CPCLS(__AParser_34,1);
 CPCLS(__AParser_36,1);
 CPCLS(__ASeq_3,1);
#line 31
 {OBJ x3;OBJ x4;OBJ x5;OBJ x6;OBJ x7;OBJ x8;OBJ x9;
#line 33
  {OBJ t=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_36,1))(__AParser_36,x1);
#line 33
   x3=FLD1(t,1);
#line 33
   x4=FLD1(t,2);
#line 33
   DSPRDF(t);}
#line 33
  COPY(x3,1);
#line 33
  COPY(x4,1);
#line 35
  x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_3,1))(__ASeq_3,x4);
#line 35
  x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_22,1))(__AParser_22,x3);
#line 35
  x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_34,1))(__AParser_34,x4);
#line 35
  ABUILTIN_8(x6,x7,x8);
#line 35
  ABUILTIN_8(x5,x8,x9);
#line 35
  if(ISTGPRM(x9,1)){
#line 35
   FREE(x3,1);
#line 35
   r=__AParser_21;
#line 35
  }else{
#line 35
   r=x3;}}
#line 35
 return r;}

extern TUP2 _AParser_36(OBJ x1) /* parseExpr */
{TUP2 r;
 CPCLS(__ASeq_3,1);
 COPY(x1,1);
#line 48
 {OBJ x2;
#line 43
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_3,1))(__ASeq_3,x1);
#line 43
  if(ISTGPRM(x2,1)){
#line 43
   COPY(x1,1);
#line 43
   CPCLS(__AToken_11,1);
#line 43
   CPCLS(__ASeq_5,1);
#line 43
   {OBJ x3;OBJ x4;
#line 43
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_5,1))(__ASeq_5,x1);
#line 43
    COPY(x3,1);
#line 43
    x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_11,1))(__AToken_11,x3);
#line 43
    if(ISTGPRM(x4,1)){
#line 43
     FREE(x3,1);
#line 43
     CPPRD(__AParser_31,1);
#line 43
     CPCLS(__ASeq_4,1);
#line 43
     {OBJ x5;OBJ x6;
#line 48
      x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_4,1))(__ASeq_4,x1);
#line 48
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_31,1))(__AParser_31,__AParser_7);
#line 48
      r.c1=x6;r.c2=x5;}
#line 48
    }else{
#line 48
     COPY(x3,1);
#line 48
     CPCLS(__AToken_9,1);
#line 48
     {OBJ x7;
#line 43
      x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_9,1))(__AToken_9,x3);
#line 43
      if(ISTGPRM(x7,1)){
#line 43
       FREE(x3,1);
#line 43
       CPPRD(__AParser_31,1);
#line 43
       CPCLS(__ASeq_4,1);
#line 43
       {OBJ x8;OBJ x9;
#line 48
	x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_4,1))(__ASeq_4,x1);
#line 49
	x9=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_31,1))(__AParser_31,__AParser_5);
#line 49
	r.c1=x9;r.c2=x8;}
#line 49
      }else{
#line 49
       COPY(x3,1);
#line 49
       CPCLS(__AToken_7,1);
#line 49
       {OBJ x10;
#line 43
	x10=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_7,1))(__AToken_7,x3);
#line 43
	if(ISTGPRM(x10,1)){
#line 43
	 FREE(x3,1);
#line 43
	 CPCLS(__AParser_34,1);
#line 43
	 CPCLS(__AParser_36,2);
#line 43
	 CPCLS(__AParser_37,1);
#line 43
	 CPCLS(__AParser_38,1);
#line 43
	 CPCLS(__ASeq_4,1);
#line 43
	 {OBJ x11;OBJ x13;OBJ x14;OBJ x16;OBJ x17;OBJ x19;OBJ x20;OBJ x21;OBJ x22;
#line 48
	  x11=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_4,1))(__ASeq_4,x1);
#line 61
	  {OBJ t=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_36,1))(__AParser_36,x11);
#line 61
	   x13=FLD1(t,1);
#line 61
	   x14=FLD1(t,2);
#line 61
	   DSPRDF(t);}
#line 62
	  {OBJ t=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_38,1))(__AParser_38,x14);
#line 62
	   x16=FLD1(t,1);
#line 62
	   x17=FLD1(t,2);
#line 62
	   DSPRDF(t);}
#line 63
	  {OBJ t=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_36,1))(__AParser_36,x17);
#line 63
	   x19=FLD1(t,1);
#line 63
	   x20=FLD1(t,2);
#line 63
	   DSPRDF(t);}
#line 64
	  x21=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_37,1))(__AParser_37,x20);
#line 64
	  COPY(x21,1);
#line 66
	  x22=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_34,1))(__AParser_34,x21);
#line 66
	  if(ISTGPRM(x22,1)){
#line 66
	   FREE(x13,1);
#line 66
	   FREE(x19,1);
#line 66
	   r.c1=__AParser_21;r.c2=x21;
#line 66
	  }else{
#line 66
	   CPPRD(__AParser_23,1);
#line 66
	   {OBJ x23;
#line 67
	    x23=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__AParser_23,3))(__AParser_23,x16,x13,x19);
#line 67
	    r.c1=x23;r.c2=x21;}}}
#line 67
	}else{
#line 67
	 CPCLS(__AToken_17,1);
#line 67
	 {OBJ x24;
#line 43
	  x24=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_17,1))(__AToken_17,x3);
#line 43
	  if(ISTGPRM(x24,1)){
#line 43
	   CPPRD(__AParser_28,1);
#line 43
	   CPCLS(__AParser_36,1);
#line 43
	   CPCLS(__ASeq_4,1);
#line 43
	   {OBJ x25;OBJ x27;OBJ x28;OBJ x29;
#line 48
	    x25=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_4,1))(__ASeq_4,x1);
#line 61
	    {OBJ t=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_36,1))(__AParser_36,x25);
#line 61
	     x27=FLD1(t,1);
#line 61
	     x28=FLD1(t,2);
#line 61
	     DSPRDF(t);}
#line 56
	    x29=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_28,1))(__AParser_28,x27);
#line 56
	    r.c1=x29;r.c2=x28;}
#line 56
	  }else{
#line 56
	   COPY(__AToken_2,1);
#line 56
	   CPCLS(__ASeq_2,1);
#line 56
	   {OBJ x30;
#line 71
	    x30=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_2,2))(__ASeq_2,__AToken_2,x1);
#line 71
	    r.c1=__AParser_21;r.c2=x30;}}}}}}}}}
#line 71
  }else{
#line 71
   COPY(__AToken_2,1);
#line 71
   CPCLS(__ASeq_2,1);
#line 71
   {OBJ x31;
#line 71
    x31=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_2,2))(__ASeq_2,__AToken_2,x1);
#line 71
    r.c1=__AParser_21;r.c2=x31;}}}
#line 71
 return r;}
#line 71
extern OBJ _AParser_36_c(OBJ x1) /* parseExpr */
#line 71
{OBJ r;
#line 71
 {TUP2 t=_AParser_36(x1);
#line 71
  PRD1(2,r);
#line 71
  FLD1(r,1)=t.c1;
#line 71
  FLD1(r,2)=t.c2;}
#line 71
 return r;}

extern OBJ _AParser_37(OBJ x1) /* parseClose */
{OBJ r;
 CPCLS(__ASeq_3,1);
 COPY(x1,1);
#line 75
 {OBJ x2;
#line 74
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_3,1))(__ASeq_3,x1);
#line 74
  if(ISTGPRM(x2,1)){
#line 74
   COPY(x1,1);
#line 74
   CPCLS(__AToken_5,1);
#line 74
   CPCLS(__ASeq_5,1);
#line 74
   {OBJ x3;OBJ x4;
#line 74
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_5,1))(__ASeq_5,x1);
#line 74
    x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_5,1))(__AToken_5,x3);
#line 74
    if(ISTGPRM(x4,1)){
#line 74
     CPCLS(__ASeq_4,1);
#line 75
     r=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_4,1))(__ASeq_4,x1);
#line 75
    }else{
#line 75
     COPY(__AToken_2,1);
#line 75
     CPCLS(__ASeq_2,1);
#line 76
     r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_2,2))(__ASeq_2,__AToken_2,x1);}}
#line 76
  }else{
#line 76
   COPY(__AToken_2,1);
#line 76
   CPCLS(__ASeq_2,1);
#line 76
   r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_2,2))(__ASeq_2,__AToken_2,x1);}}
#line 76
 return r;}

extern TUP2 _AParser_38(OBJ x1) /* parseBinOp */
{TUP2 r;
 CPCLS(__ASeq_3,1);
 COPY(x1,1);
#line 80
 {OBJ x2;
#line 79
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_3,1))(__ASeq_3,x1);
#line 79
  if(ISTGPRM(x2,1)){
#line 79
   COPY(x1,1);
#line 79
   CPCLS(__AToken_19,1);
#line 79
   CPCLS(__ASeq_5,1);
#line 79
   {OBJ x3;OBJ x4;
#line 79
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_5,1))(__ASeq_5,x1);
#line 79
    COPY(x3,1);
#line 79
    x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_19,1))(__AToken_19,x3);
#line 79
    if(ISTGPRM(x4,1)){
#line 79
     FREE(x3,1);
#line 79
     CPCLS(__ASeq_4,1);
#line 79
     {OBJ x5;
#line 80
      x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_4,1))(__ASeq_4,x1);
#line 80
      r.c1=__AParser_18;r.c2=x5;}
#line 80
    }else{
#line 80
     COPY(x3,1);
#line 80
     CPCLS(__AToken_15,1);
#line 80
     {OBJ x6;
#line 79
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_15,1))(__AToken_15,x3);
#line 79
      if(ISTGPRM(x6,1)){
#line 79
       FREE(x3,1);
#line 79
       CPCLS(__ASeq_4,1);
#line 79
       {OBJ x7;
#line 80
	x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_4,1))(__ASeq_4,x1);
#line 82
	r.c1=__AParser_14;r.c2=x7;}
#line 82
      }else{
#line 82
       COPY(x3,1);
#line 82
       CPCLS(__AToken_13,1);
#line 82
       {OBJ x8;
#line 79
	x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_13,1))(__AToken_13,x3);
#line 79
	if(ISTGPRM(x8,1)){
#line 79
	 FREE(x3,1);
#line 79
	 CPCLS(__ASeq_4,1);
#line 79
	 {OBJ x9;
#line 80
	  x9=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_4,1))(__ASeq_4,x1);
#line 83
	  r.c1=__AParser_12;r.c2=x9;}
#line 83
	}else{
#line 83
	 CPCLS(__AToken_21,1);
#line 83
	 {OBJ x10;
#line 79
	  x10=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_21,1))(__AToken_21,x3);
#line 79
	  if(ISTGPRM(x10,1)){
#line 79
	   CPCLS(__ASeq_4,1);
#line 79
	   {OBJ x11;
#line 80
	    x11=(*(OBJ(*)(OBJ,OBJ))METHOD(__ASeq_4,1))(__ASeq_4,x1);
#line 81
	    r.c1=__AParser_16;r.c2=x11;}
#line 81
	  }else{
#line 81
	   COPY(__AToken_2,1);
#line 81
	   CPCLS(__ASeq_2,1);
#line 81
	   {OBJ x12;
#line 84
	    x12=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_2,2))(__ASeq_2,__AToken_2,x1);
#line 84
	    r.c1=__AParser_10;r.c2=x12;}}}}}}}}}
#line 84
  }else{
#line 84
   COPY(__AToken_2,1);
#line 84
   CPCLS(__ASeq_2,1);
#line 84
   {OBJ x13;
#line 84
    x13=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_2,2))(__ASeq_2,__AToken_2,x1);
#line 84
    r.c1=__AParser_10;r.c2=x13;}}}
#line 84
 return r;}
#line 84
extern OBJ _AParser_38_c(OBJ x1) /* parseBinOp */
#line 84
{OBJ r;
#line 84
 {TUP2 t=_AParser_38(x1);
#line 84
  PRD1(2,r);
#line 84
  FLD1(r,1)=t.c1;
#line 84
  FLD1(r,2)=t.c2;}
#line 84
 return r;}

extern OBJ _AParser_39(OBJ x1) /* evalExpr */
{OBJ r;
 CPCLS(__AParser_29,1);
 COPY(x1,1);
#line 98
 {OBJ x2;
#line 97
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_29,1))(__AParser_29,x1);
#line 97
  if(ISTGPRM(x2,1)){
#line 97
   CPCLS(__AParser_30,1);
#line 97
   CPCLS(__AParser_39,1);
#line 97
   {OBJ x3;OBJ x4;
#line 100
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_30,1))(__AParser_30,x1);
#line 100
    x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_39,1))(__AParser_39,x3);
#line 100
    ABUILTIN_7(x4,r);}
#line 100
  }else{
#line 100
   COPY(x1,1);
#line 100
   CPCLS(__AParser_24,1);
#line 100
   {OBJ x5;
#line 97
    x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_24,1))(__AParser_24,x1);
#line 97
    if(ISTGPRM(x5,1)){
#line 97
     COPY(x1,1);
#line 97
     CPCLS(__AParser_17,1);
#line 97
     CPCLS(__AParser_27,1);
#line 97
     {OBJ x6;OBJ x7;
#line 97
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_27,1))(__AParser_27,x1);
#line 97
      x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_17,1))(__AParser_17,x6);
#line 97
      if(ISTGPRM(x7,1)){
#line 97
       COPY(x1,1);
#line 97
       CPCLS(__AParser_25,1);
#line 97
       CPCLS(__AParser_26,1);
#line 97
       CPCLS(__AParser_39,2);
#line 97
       {OBJ x8;OBJ x9;OBJ x11;OBJ x10;
#line 102
	x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_26,1))(__AParser_26,x1);
#line 102
	x9=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_25,1))(__AParser_25,x1);
#line 102
	x11=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_39,1))(__AParser_39,x9);
#line 102
	x10=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_39,1))(__AParser_39,x8);
#line 102
	ABUILTIN_8(x10,x11,r);}
#line 102
      }else{
#line 102
       CPCLS(__AParser_15,1);
#line 102
       {OBJ x12;
#line 97
	x12=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_15,1))(__AParser_15,x6);
#line 97
	if(ISTGPRM(x12,1)){
#line 97
	 COPY(x1,1);
#line 97
	 CPCLS(__AParser_25,1);
#line 97
	 CPCLS(__AParser_26,1);
#line 97
	 CPCLS(__AParser_39,2);
#line 97
	 CPCLS(__ABool_17,1);
#line 97
	 {OBJ x13;OBJ x14;OBJ x16;OBJ x15;
#line 102
	  x13=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_26,1))(__AParser_26,x1);
#line 102
	  x14=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_25,1))(__AParser_25,x1);
#line 102
	  x16=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_39,1))(__AParser_39,x14);
#line 102
	  x15=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_39,1))(__AParser_39,x13);
#line 103
	  r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ABool_17,2))(__ABool_17,x15,x16);}
#line 103
	}else{
#line 103
	 CPCLS(__AParser_13,1);
#line 103
	 {OBJ x17;
#line 97
	  x17=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_13,1))(__AParser_13,x6);
#line 97
	  if(ISTGPRM(x17,1)){
#line 97
	   COPY(x1,1);
#line 97
	   CPCLS(__AParser_25,1);
#line 97
	   CPCLS(__AParser_26,1);
#line 97
	   CPCLS(__AParser_39,2);
#line 97
	   CPCLS(__ABool_9,1);
#line 97
	   {OBJ x18;OBJ x19;OBJ x21;OBJ x20;
#line 102
	    x18=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_26,1))(__AParser_26,x1);
#line 102
	    x19=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_25,1))(__AParser_25,x1);
#line 102
	    x21=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_39,1))(__AParser_39,x19);
#line 102
	    x20=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_39,1))(__AParser_39,x18);
#line 104
	    r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ABool_9,2))(__ABool_9,x20,x21);}
#line 104
	  }else{
#line 104
	   CPCLS(__AParser_19,1);
#line 104
	   {OBJ x22;
#line 97
	    x22=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_19,1))(__AParser_19,x6);
#line 97
	    if(ISTGPRM(x22,1)){
#line 97
	     COPY(x1,1);
#line 97
	     CPCLS(__AParser_25,1);
#line 97
	     CPCLS(__AParser_26,1);
#line 97
	     CPCLS(__AParser_39,2);
#line 97
	     {OBJ x23;OBJ x24;OBJ x26;OBJ x25;
#line 102
	      x23=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_26,1))(__AParser_26,x1);
#line 102
	      x24=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_25,1))(__AParser_25,x1);
#line 102
	      x26=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_39,1))(__AParser_39,x24);
#line 102
	      x25=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_39,1))(__AParser_39,x23);
#line 101
	      ABUILTIN_9(x25,x26,r);}
#line 101
	    }else{
#line 97
	     HLT("Parser at <97,5-12> : missing pattern for evalExpr(binOp(fail,_,_)) in evalExpr\'Parser:expr->bool");}}}}}}}}
#line 97
    }else{
#line 97
     COPY(x1,1);
#line 97
     CPCLS(__AParser_32,1);
#line 97
     {OBJ x27;
#line 97
      x27=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_32,1))(__AParser_32,x1);
#line 97
      if(ISTGPRM(x27,1)){
#line 97
       CPCLS(__AParser_8,1);
#line 97
       CPCLS(__AParser_33,1);
#line 97
       {OBJ x28;OBJ x29;
#line 97
	x28=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_33,1))(__AParser_33,x1);
#line 97
	x29=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_8,1))(__AParser_8,x28);
#line 97
	if(ISTGPRM(x29,1)){
#line 98
	 r=__ABUILTIN_5;
#line 98
	}else{
#line 98
	 CPCLS(__AParser_6,1);
#line 98
	 {OBJ x30;
#line 97
	  x30=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_6,1))(__AParser_6,x28);
#line 97
	  if(ISTGPRM(x30,1)){
#line 99
	   r=__ABUILTIN_3;
#line 99
	  }else{
#line 97
	   HLT("Parser at <97,5-12> : missing pattern for evalExpr(boolLit(fail)) in evalExpr\'Parser:expr->bool");}}}}
#line 97
      }else{
#line 97
       HLT("Parser at <97,5-12> : missing pattern for evalExpr(fail) in evalExpr\'Parser:expr->bool");}}}}}}
#line 97
 return r;}

extern OBJ _AParser_40(OBJ x1) /* ` */
{OBJ r;
 CPCLS(__AParser_29,1);
 COPY(x1,1);
#line 111
 {OBJ x2;
#line 110
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_29,1))(__AParser_29,x1);
#line 110
  if(ISTGPRM(x2,1)){
#line 110
   CPCLS(__AParser_30,1);
#line 110
   CPCLS(__AParser_40,1);
#line 110
   CPPRD(__AParser_59,1);
#line 110
   CPCLS(__ADenotation_4,1);
#line 110
   {OBJ x3;OBJ x4;
#line 114
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_30,1))(__AParser_30,x1);
#line 114
    x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_40,1))(__AParser_40,x3);
#line 114
    r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AParser_59,x4);}
#line 114
  }else{
#line 114
   COPY(x1,1);
#line 114
   CPCLS(__AParser_24,1);
#line 114
   {OBJ x5;
#line 110
    x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_24,1))(__AParser_24,x1);
#line 110
    if(ISTGPRM(x5,1)){
#line 110
     COPY(x1,1);
#line 110
     CPCLS(__AParser_17,1);
#line 110
     CPCLS(__AParser_27,1);
#line 110
     {OBJ x6;OBJ x7;
#line 110
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_27,1))(__AParser_27,x1);
#line 110
      x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_17,1))(__AParser_17,x6);
#line 110
      if(ISTGPRM(x7,1)){
#line 110
       COPY(x1,1);
#line 110
       CPCLS(__AParser_25,1);
#line 110
       CPCLS(__AParser_26,1);
#line 110
       CPCLS(__AParser_40,2);
#line 110
       CPPRD(__AParser_56,1);
#line 110
       CPPRD(__AParser_57,1);
#line 110
       CPPRD(__AParser_58,1);
#line 110
       CPCLS(__ADenotation_4,4);
#line 110
       {OBJ x8;OBJ x9;OBJ x11;OBJ x10;OBJ x12;OBJ x13;OBJ x14;
#line 116
	x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_26,1))(__AParser_26,x1);
#line 116
	x9=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_25,1))(__AParser_25,x1);
#line 116
	x11=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_40,1))(__AParser_40,x9);
#line 116
	x10=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_40,1))(__AParser_40,x8);
#line 116
	x12=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x11,__AParser_56);
#line 116
	x13=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AParser_57,x12);
#line 116
	x14=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x10,x13);
#line 116
	r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AParser_58,x14);}
#line 116
      }else{
#line 116
       CPCLS(__AParser_13,1);
#line 116
       {OBJ x15;
#line 110
	x15=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_13,1))(__AParser_13,x6);
#line 110
	if(ISTGPRM(x15,1)){
#line 110
	 COPY(x1,1);
#line 110
	 CPCLS(__AParser_25,1);
#line 110
	 CPCLS(__AParser_26,1);
#line 110
	 CPCLS(__AParser_40,2);
#line 110
	 CPPRD(__AParser_53,1);
#line 110
	 CPPRD(__AParser_54,1);
#line 110
	 CPPRD(__AParser_55,1);
#line 110
	 CPCLS(__ADenotation_4,4);
#line 110
	 {OBJ x16;OBJ x17;OBJ x19;OBJ x18;OBJ x20;OBJ x21;OBJ x22;
#line 116
	  x16=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_26,1))(__AParser_26,x1);
#line 116
	  x17=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_25,1))(__AParser_25,x1);
#line 116
	  x19=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_40,1))(__AParser_40,x17);
#line 116
	  x18=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_40,1))(__AParser_40,x16);
#line 116
	  x20=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x19,__AParser_53);
#line 118
	  x21=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AParser_54,x20);
#line 118
	  x22=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x18,x21);
#line 118
	  r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AParser_55,x22);}
#line 118
	}else{
#line 118
	 CPCLS(__AParser_11,1);
#line 118
	 {OBJ x23;
#line 110
	  x23=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_11,1))(__AParser_11,x6);
#line 110
	  if(ISTGPRM(x23,1)){
#line 110
	   FREE(x1,1);
#line 110
	   CPPRD(__AParser_52,1);
#line 110
	   r=__AParser_52;
#line 110
	  }else{
#line 110
	   CPCLS(__AParser_15,1);
#line 110
	   {OBJ x24;
#line 110
	    x24=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_15,1))(__AParser_15,x6);
#line 110
	    if(ISTGPRM(x24,1)){
#line 110
	     COPY(x1,1);
#line 110
	     CPCLS(__AParser_25,1);
#line 110
	     CPCLS(__AParser_26,1);
#line 110
	     CPCLS(__AParser_40,2);
#line 110
	     CPPRD(__AParser_49,1);
#line 110
	     CPPRD(__AParser_50,1);
#line 110
	     CPPRD(__AParser_51,1);
#line 110
	     CPCLS(__ADenotation_4,4);
#line 110
	     {OBJ x25;OBJ x26;OBJ x28;OBJ x27;OBJ x29;OBJ x30;OBJ x31;
#line 116
	      x25=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_26,1))(__AParser_26,x1);
#line 116
	      x26=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_25,1))(__AParser_25,x1);
#line 116
	      x28=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_40,1))(__AParser_40,x26);
#line 116
	      x27=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_40,1))(__AParser_40,x25);
#line 116
	      x29=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x28,__AParser_49);
#line 117
	      x30=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AParser_50,x29);
#line 117
	      x31=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x27,x30);
#line 117
	      r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AParser_51,x31);}
#line 117
	    }else{
#line 117
	     CPCLS(__AParser_19,1);
#line 117
	     {OBJ x32;
#line 110
	      x32=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_19,1))(__AParser_19,x6);
#line 110
	      if(ISTGPRM(x32,1)){
#line 110
	       COPY(x1,1);
#line 110
	       CPCLS(__AParser_25,1);
#line 110
	       CPCLS(__AParser_26,1);
#line 110
	       CPCLS(__AParser_40,2);
#line 110
	       CPPRD(__AParser_46,1);
#line 110
	       CPPRD(__AParser_47,1);
#line 110
	       CPPRD(__AParser_48,1);
#line 110
	       CPCLS(__ADenotation_4,4);
#line 110
	       {OBJ x33;OBJ x34;OBJ x36;OBJ x35;OBJ x37;OBJ x38;OBJ x39;
#line 116
		x33=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_26,1))(__AParser_26,x1);
#line 116
		x34=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_25,1))(__AParser_25,x1);
#line 116
		x36=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_40,1))(__AParser_40,x34);
#line 116
		x35=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_40,1))(__AParser_40,x33);
#line 116
		x37=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x36,__AParser_46);
#line 115
		x38=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AParser_47,x37);
#line 115
		x39=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,x35,x38);
#line 115
		r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ADenotation_4,2))(__ADenotation_4,__AParser_48,x39);}
#line 115
	      }else{
#line 110
	       HLT("Parser at <110,5> : missing else in `\'Parser:expr->denotation");}}}}}}}}}}
#line 110
    }else{
#line 110
     COPY(x1,1);
#line 110
     CPCLS(__AParser_22,1);
#line 110
     {OBJ x40;
#line 110
      x40=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_22,1))(__AParser_22,x1);
#line 110
      if(ISTGPRM(x40,1)){
#line 110
       FREE(x1,1);
#line 110
       CPPRD(__AParser_45,1);
#line 110
       r=__AParser_45;
#line 110
      }else{
#line 110
       COPY(x1,1);
#line 110
       CPCLS(__AParser_32,1);
#line 110
       {OBJ x41;
#line 110
	x41=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_32,1))(__AParser_32,x1);
#line 110
	if(ISTGPRM(x41,1)){
#line 110
	 CPCLS(__AParser_6,1);
#line 110
	 CPCLS(__AParser_33,1);
#line 110
	 {OBJ x42;OBJ x43;
#line 110
	  x42=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_33,1))(__AParser_33,x1);
#line 110
	  x43=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_6,1))(__AParser_6,x42);
#line 110
	  if(ISTGPRM(x43,1)){
#line 110
	   CPPRD(__AParser_44,1);
#line 110
	   r=__AParser_44;
#line 110
	  }else{
#line 110
	   CPCLS(__AParser_4,1);
#line 110
	   {OBJ x44;
#line 110
	    x44=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_4,1))(__AParser_4,x42);
#line 110
	    if(ISTGPRM(x44,1)){
#line 110
	     CPPRD(__AParser_43,1);
#line 110
	     r=__AParser_43;
#line 110
	    }else{
#line 110
	     CPCLS(__AParser_8,1);
#line 110
	     {OBJ x45;
#line 110
	      x45=(*(OBJ(*)(OBJ,OBJ))METHOD(__AParser_8,1))(__AParser_8,x42);
#line 110
	      if(ISTGPRM(x45,1)){
#line 110
	       CPPRD(__AParser_42,1);
#line 110
	       r=__AParser_42;
#line 110
	      }else{
#line 110
	       HLT("Parser at <110,5> : missing else in `\'Parser:expr->denotation");}}}}}}
#line 110
	}else{
#line 110
	 HLT("Parser at <110,5> : missing else in `\'Parser:expr->denotation");}}}}}}}}
#line 110
 return r;}










static OBJ _mt_1_0_1(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 return r;}
static OBJ _mt_1_0_1_l(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 COPY(r,1);LZYCLS(t,r);
 return r;}

static OBJ _mt_3_0_3(OBJ t,OBJ t1,OBJ t2,OBJ t3) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ,OBJ,OBJ))ENTRY(t))(t1,t2,t3);
 return r;}

extern void init_AToken();
extern void init_AScanner();
extern void init_ASeq();
extern void init_ABoolConv();
extern void init_ADenotation();
extern void init_ACompose();
extern void init_ABool();
extern void init_ANat();
extern void init_AChar();
extern void init_AOption();
void init_AParser()
{
 static int visited=0; if(visited) return; visited=1;
 init_AToken();
 init_AScanner();
 init_ASeq();
 init_ABoolConv();
 init_ADenotation();
 init_ACompose();
 init_ABool();
 init_ANat();
 init_AChar();
 init_AOption();
 CLS(1,_AParser_31,__AParser_31);
 CLS(1,_AParser_30,__AParser_30);
 CLS(1,_AParser_29,__AParser_29);
 CLS(1,_AParser_28,__AParser_28);
 DEN("not ",__AParser_59);
 CLS(1,_AParser_27,__AParser_27);
 DEN("(",__AParser_58);
 CLS(1,_AParser_26,__AParser_26);
 DEN(" or ",__AParser_57);
 CLS(1,_AParser_25,__AParser_25);
 DEN(")",__AParser_56);
 CLS(1,_AParser_24,__AParser_24);
 DEN("(",__AParser_55);
 CLS(3,_AParser_23,__AParser_23);
 DEN(" <-> ",__AParser_54);
 CLS(1,_AParser_22,__AParser_22);
 DEN(")",__AParser_53);
 DEN("-Unknown operation-",__AParser_52);
 DEN("(",__AParser_51);
 CLS(1,_AParser_19,__AParser_19);
 DEN(" -> ",__AParser_50);
 DEN(")",__AParser_49);
 CLS(1,_AParser_17,__AParser_17);
 DEN("(",__AParser_48);
 DEN(" and ",__AParser_47);
 CLS(1,_AParser_15,__AParser_15);
 DEN(")",__AParser_46);
 DEN("-Unkown expression-",__AParser_45);
 CLS(1,_AParser_13,__AParser_13);
 DEN("F",__AParser_44);
 DEN("-Unknown boolLiteral-",__AParser_43);
 CLS(1,_AParser_11,__AParser_11);
 DEN("T",__AParser_42);
 DEN("Parsing failed.",__AParser_41);
 CLS(1,_AParser_8,__AParser_8);
 CLS(1,_AParser_40,__AParser_40);
 CLS(1,_AParser_39,__AParser_39);
 CLS(1,_AParser_6,__AParser_6);
 CLS(1,_AParser_38_c,__AParser_38);
 CLS(1,_AParser_37,__AParser_37);
 CLS(1,_AParser_4,__AParser_4);
 CLS(1,_AParser_36_c,__AParser_36);
 CLS(1,_AParser_35,__AParser_35);
 CLS(1,_AParser_34,__AParser_34);
 CLS(1,_AParser_1,__AParser_1);
 CLS(1,_AParser_33,__AParser_33);
 CLS(1,_AParser_32,__AParser_32);
 MTH(1,0,1,_mt_1_0_1);LZYMTH(1,0,1,_mt_1_0_1_l);
 MTH(3,0,3,_mt_3_0_3);LZYMTH(3,0,3,_mt_3_0_3);
 PRM(2,__AParser_3);
 PRM(1,__AParser_5);
 PRM(0,__AParser_7);
 PRM(4,__AParser_10);
 PRM(3,__AParser_12);
 PRM(2,__AParser_14);
 PRM(1,__AParser_16);
 PRM(0,__AParser_18);
 PRM1(__AParser_21);}

