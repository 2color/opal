

#ifndef AParserTest_included
#define AParserTest_included

#define __AParserTest_Atest __AParserTest_1
extern OBJ __AParserTest_Atest;

#define __AParserTest_ArunTest __AParserTest_2
#define _AParserTest_ArunTest _AParserTest_2
extern OBJ __AParserTest_ArunTest;
extern OBJ _AParserTest_ArunTest(OBJ,OBJ,OBJ);

#ifndef AParserTest_ArunTest
#define AParserTest_ArunTest(x1,x2,x3,x17) {x17=_AParserTest_ArunTest(x1,x2,x3);}
#endif

#endif
