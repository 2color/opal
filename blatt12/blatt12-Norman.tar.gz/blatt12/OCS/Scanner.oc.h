

#ifndef AScanner_included
#define AScanner_included

#define __AScanner_Ascan __AScanner_1
#define _AScanner_Ascan _AScanner_1
extern OBJ __AScanner_Ascan;
extern OBJ _AScanner_Ascan(OBJ);

#define __AScanner_Apartition __AScanner_3
#define _AScanner_Apartition _AScanner_3
extern OBJ __AScanner_Apartition;
extern OBJ _AScanner_Apartition(OBJ);

#define __AScanner_Aseparator_ __AScanner_4
#define _AScanner_Aseparator_ _AScanner_4
extern OBJ __AScanner_Aseparator_;
extern OBJ _AScanner_Aseparator_(OBJ);

#define __AScanner_Aparens_ __AScanner_5
#define _AScanner_Aparens_ _AScanner_5
extern OBJ __AScanner_Aparens_;
extern OBJ _AScanner_Aparens_(OBJ);

#define __AScanner_Atranslate __AScanner_6
#define _AScanner_Atranslate _AScanner_6
extern OBJ __AScanner_Atranslate;
extern OBJ _AScanner_Atranslate(OBJ);

#define __AScanner_Atrans __AScanner_7
#define _AScanner_Atrans _AScanner_7
extern OBJ __AScanner_Atrans;
extern OBJ _AScanner_Atrans(OBJ);

#define __AScanner_Atable __AScanner_8
extern OBJ __AScanner_Atable;

#ifndef AScanner_Ascan
#define AScanner_Ascan(x1,x3) {x3=_AScanner_Ascan(x1);}
#endif

#ifndef AScanner_Apartition
#define AScanner_Apartition(x1,x16) {x16=_AScanner_Apartition(x1);}
#endif

#ifndef AScanner_Aseparator_
#define AScanner_Aseparator_(x1,x4) {x4=_AScanner_Aseparator_(x1);}
#endif

#ifndef AScanner_Aparens_
#define AScanner_Aparens_(x1,x6) {x6=_AScanner_Aparens_(x1);}
#endif

#ifndef AScanner_Atranslate
#define AScanner_Atranslate(x1,x2) {x2=_AScanner_Atranslate(x1);}
#endif

#ifndef AScanner_Atrans
#define AScanner_Atrans(x1,x3) {x3=_AScanner_Atrans(x1);}
#endif

#endif
