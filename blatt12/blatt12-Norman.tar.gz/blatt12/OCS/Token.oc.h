

#ifndef AToken_included
#define AToken_included

#define __AToken_Aerror __AToken_2
extern OBJ __AToken_Aerror;

#define __AToken_Aerror_ __AToken_3
#define _AToken_Aerror_ _AToken_3
extern OBJ __AToken_Aerror_;
extern OBJ _AToken_Aerror_(OBJ);

#define __AToken_Aclose __AToken_4
extern OBJ __AToken_Aclose;

#define __AToken_Aclose_ __AToken_5
#define _AToken_Aclose_ _AToken_5
extern OBJ __AToken_Aclose_;
extern OBJ _AToken_Aclose_(OBJ);

#define __AToken_Aopen __AToken_6
extern OBJ __AToken_Aopen;

#define __AToken_Aopen_ __AToken_7
#define _AToken_Aopen_ _AToken_7
extern OBJ __AToken_Aopen_;
extern OBJ _AToken_Aopen_(OBJ);

#define __AToken_Afalse __AToken_8
extern OBJ __AToken_Afalse;

#define __AToken_Afalse_ __AToken_9
#define _AToken_Afalse_ _AToken_9
extern OBJ __AToken_Afalse_;
extern OBJ _AToken_Afalse_(OBJ);

#define __AToken_Atrue __AToken_10
extern OBJ __AToken_Atrue;

#define __AToken_Atrue_ __AToken_11
#define _AToken_Atrue_ _AToken_11
extern OBJ __AToken_Atrue_;
extern OBJ _AToken_Atrue_(OBJ);

#define __AToken_Aequiv __AToken_12
extern OBJ __AToken_Aequiv;

#define __AToken_Aequiv_ __AToken_13
#define _AToken_Aequiv_ _AToken_13
extern OBJ __AToken_Aequiv_;
extern OBJ _AToken_Aequiv_(OBJ);

#define __AToken_Aimpl __AToken_14
extern OBJ __AToken_Aimpl;

#define __AToken_Aimpl_ __AToken_15
#define _AToken_Aimpl_ _AToken_15
extern OBJ __AToken_Aimpl_;
extern OBJ _AToken_Aimpl_(OBJ);

#define __AToken_Anot __AToken_16
extern OBJ __AToken_Anot;

#define __AToken_Anot_ __AToken_17
#define _AToken_Anot_ _AToken_17
extern OBJ __AToken_Anot_;
extern OBJ _AToken_Anot_(OBJ);

#define __AToken_Aand __AToken_18
extern OBJ __AToken_Aand;

#define __AToken_Aand_ __AToken_19
#define _AToken_Aand_ _AToken_19
extern OBJ __AToken_Aand_;
extern OBJ _AToken_Aand_(OBJ);

#define __AToken_Aor __AToken_20
extern OBJ __AToken_Aor;

#define __AToken_Aor_ __AToken_21
#define _AToken_Aor_ _AToken_21
extern OBJ __AToken_Aor_;
extern OBJ _AToken_Aor_(OBJ);

#define __AToken_Sq __AToken_22
#define _AToken_Sq _AToken_22
extern OBJ __AToken_Sq;
extern OBJ _AToken_Sq(OBJ);

#ifndef AToken_Aerror_
#define AToken_Aerror_(x1,x2) {x2=_AToken_Aerror_(x1);}
#endif

#ifndef AToken_Aclose_
#define AToken_Aclose_(x1,x2) {x2=_AToken_Aclose_(x1);}
#endif

#ifndef AToken_Aopen_
#define AToken_Aopen_(x1,x2) {x2=_AToken_Aopen_(x1);}
#endif

#ifndef AToken_Afalse_
#define AToken_Afalse_(x1,x2) {x2=_AToken_Afalse_(x1);}
#endif

#ifndef AToken_Atrue_
#define AToken_Atrue_(x1,x2) {x2=_AToken_Atrue_(x1);}
#endif

#ifndef AToken_Aequiv_
#define AToken_Aequiv_(x1,x2) {x2=_AToken_Aequiv_(x1);}
#endif

#ifndef AToken_Aimpl_
#define AToken_Aimpl_(x1,x2) {x2=_AToken_Aimpl_(x1);}
#endif

#ifndef AToken_Anot_
#define AToken_Anot_(x1,x2) {x2=_AToken_Anot_(x1);}
#endif

#ifndef AToken_Aand_
#define AToken_Aand_(x1,x2) {x2=_AToken_Aand_(x1);}
#endif

#ifndef AToken_Aor_
#define AToken_Aor_(x1,x2) {x2=_AToken_Aor_(x1);}
#endif

#ifndef AToken_Sq
#define AToken_Sq(x1,x12) {x12=_AToken_Sq(x1);}
#endif

#endif
