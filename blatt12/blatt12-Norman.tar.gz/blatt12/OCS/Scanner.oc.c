

#line 1 "Scanner.impl"
#include "BUILTIN.h"
extern OBJ __AToken_2;
extern OBJ __AToken_4;
extern OBJ __AToken_6;
extern OBJ __AToken_8;
extern OBJ __AToken_10;
extern OBJ __AToken_12;
extern OBJ __AToken_14;
extern OBJ __AToken_16;
extern OBJ __AToken_18;
extern OBJ __AToken_20;
extern OBJ __ASeq_2;
extern OBJ __ASeq_6;
extern OBJ __AChar_15;
extern OBJ __AChar_28;
extern OBJ __AChar_32;
extern OBJ __ASeqMap_3;
extern OBJ __AString_2;
extern OBJ __AString_3;
extern OBJ __AString_4;
extern OBJ __AString_5;
extern OBJ __AString_7;
extern OBJ __AString_12;
extern OBJ __AString_43;
extern OBJ __AString_49;
extern OBJ __AString_57;
extern OBJ __AStringFilter_5;
extern OBJ __ABool_4;
extern OBJ __ACompose_4;
extern OBJ __AMap_5;
extern OBJ __AMap_6;
extern OBJ __AMap_16;
extern OBJ __AMap_20;
extern OBJ _AScanner_1(OBJ);OBJ __AScanner_1; /* scan */
extern OBJ _AScanner_3(OBJ);OBJ __AScanner_3; /* partition */
extern OBJ _AScanner_4(OBJ);OBJ __AScanner_4; /* separator? */
extern OBJ _AScanner_5(OBJ);OBJ __AScanner_5; /* parens? */
extern OBJ _AScanner_6(OBJ);OBJ __AScanner_6; /* translate */
extern OBJ _AScanner_7(OBJ);OBJ __AScanner_7; /* trans */
OBJ __AScanner_8; /* table */
OBJ __AScanner_9; /* parens?'9 */
OBJ __AScanner_10; /* parens?'10 */
OBJ __AScanner_11; /* table'11 */
OBJ __AScanner_12; /* table'12 */
OBJ __AScanner_13; /* table'13 */
OBJ __AScanner_14; /* table'14 */
OBJ __AScanner_15; /* table'15 */
OBJ __AScanner_16; /* table'16 */
OBJ __AScanner_17; /* table'17 */
OBJ __AScanner_18; /* table'18 */
OBJ __AScanner_19; /* table'19 */

extern OBJ _AScanner_1(OBJ x1) /* scan */
{OBJ r;
 CPCLS(__AScanner_3,1);
 CPCLS(__AScanner_6,1);
 CPCLS(__AString_57,1);
 CPCLS(__ACompose_4,1);
#line 28
 {OBJ x2;
#line 28
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_57,1))(__AString_57,x1);
#line 28
  r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__ACompose_4,3))(__ACompose_4,__AScanner_6,__AScanner_3,x2);}
#line 28
 return r;}

extern OBJ _AScanner_3(OBJ x1) /* partition */
{OBJ r;
 CPCLS(__AString_7,1);
 COPY(x1,1);
#line 33
 {OBJ x2;
#line 32
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_7,1))(__AString_7,x1);
#line 32
  if(ISTGPRM(x2,1)){
#line 32
   FREE(x1,1);
#line 32
   COPY(__ASeq_6,1);
#line 33
   r=__ASeq_6;
#line 33
  }else{
#line 33
   COPY(x1,1);
#line 33
   CPCLS(__AString_3,1);
#line 33
   {OBJ x3;
#line 32
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_3,1))(__AString_3,x1);
#line 32
    if(ISTGPRM(x3,1)){
#line 32
     COPY(x1,1);
#line 32
     CPCLS(__AChar_28,1);
#line 32
     CPCLS(__AString_4,1);
#line 32
     CPCLS(__AString_5,1);
#line 32
     {OBJ x4;OBJ x5;OBJ x6;
#line 34
      x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_5,1))(__AString_5,x1);
#line 34
      COPY(x4,1);
#line 34
      x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_4,1))(__AString_4,x1);
#line 35
      x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__AChar_28,1))(__AChar_28,x4);
#line 35
      if(ISTGPRM(x6,1)){
#line 35
       FREE(x4,1);
#line 35
       CPCLS(__AScanner_3,1);
#line 35
       r=(*(OBJ(*)(OBJ,OBJ))METHOD(__AScanner_3,1))(__AScanner_3,x5);
#line 35
      }else{
#line 35
       COPY(x4,1);
#line 35
       CPCLS(__AScanner_5,1);
#line 35
       {OBJ x7;
#line 36
	x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__AScanner_5,1))(__AScanner_5,x4);
#line 36
	if(ISTGPRM(x7,1)){
#line 36
	 CPCLS(__AScanner_3,1);
#line 36
	 CPCLS(__ASeq_2,1);
#line 36
	 CPCLS(__AString_12,1);
#line 36
	 {OBJ x9;OBJ x8;
#line 36
	  x9=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_12,1))(__AString_12,x4);
#line 35
	  x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__AScanner_3,1))(__AScanner_3,x5);
#line 36
	  r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_2,2))(__ASeq_2,x9,x8);}
#line 36
	}else{
#line 36
	 CPCLS(__AScanner_3,1);
#line 36
	 CPCLS(__AScanner_4,1);
#line 36
	 CPCLS(__ASeq_2,1);
#line 36
	 CPCLS(__AString_2,1);
#line 36
	 CPCLS(__AStringFilter_5,1);
#line 36
	 CPCLS(__ABool_4,1);
#line 36
	 CPCLS(__ACompose_4,1);
#line 36
	 {OBJ x10;OBJ x11;OBJ x13;OBJ x14;OBJ x15;
#line 38
	  x10=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ACompose_4,2))(__ACompose_4,__ABool_4,__AScanner_4);
#line 38
	  x11=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__AString_2,2))(__AString_2,x4,x5);
#line 38
	  {OBJ t=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__AStringFilter_5,2))(__AStringFilter_5,x10,x11);
#line 38
	   x13=FLD1(t,1);
#line 38
	   x14=FLD1(t,2);
#line 38
	   DSPRDF(t);}
#line 39
	  x15=(*(OBJ(*)(OBJ,OBJ))METHOD(__AScanner_3,1))(__AScanner_3,x14);
#line 39
	  r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeq_2,2))(__ASeq_2,x13,x15);}}}}}
#line 39
    }else{
#line 32
     HLT("Scanner at <32,5-13> : missing else in partition\'Scanner:string->seq");}}}}
#line 32
 return r;}

extern OBJ _AScanner_4(OBJ x1) /* separator? */
{OBJ r;
 CPCLS(__AScanner_5,1);
 CPCLS(__AChar_28,1);
 COPY(x1,1);
#line 44
 {OBJ x2;OBJ x3;
#line 44
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__AChar_28,1))(__AChar_28,x1);
#line 44
  x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__AScanner_5,1))(__AScanner_5,x1);
#line 44
  ABUILTIN_8(x2,x3,r);}
#line 44
 return r;}

extern OBJ _AScanner_5(OBJ x1) /* parens? */
{OBJ r;
 CPPRD(__AScanner_9,1);
 CPPRD(__AScanner_10,1);
 CPCLS(__AChar_15,2);
 CPCLS(__AChar_32,2);
 COPY(x1,1);
#line 48
 {OBJ x2;OBJ x3;OBJ x4;OBJ x5;
#line 48
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__AChar_32,1))(__AChar_32,__AScanner_9);
#line 48
  x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__AChar_32,1))(__AChar_32,__AScanner_10);
#line 48
  x4=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__AChar_15,2))(__AChar_15,x1,x2);
#line 48
  x5=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__AChar_15,2))(__AChar_15,x1,x3);
#line 48
  ABUILTIN_8(x4,x5,r);}
#line 48
 return r;}

extern OBJ _AScanner_6(OBJ x1) /* translate */
{OBJ r;
 CPCLS(__AScanner_7,1);
 CPCLS(__ASeqMap_3,1);
#line 53
 r=(*(OBJ(*)(OBJ,OBJ,OBJ))METHOD(__ASeqMap_3,2))(__ASeqMap_3,__AScanner_7,x1);
#line 53
 return r;}

extern OBJ _AScanner_7(OBJ x1) /* trans */
{OBJ r;
 COPY(__AScanner_8,1);
 CPCLS(__AString_43,1);
 CPCLS(__AMap_20,1);
 COPY(x1,1);
#line 56
 {OBJ x2;
#line 56
  x2=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__AMap_20,3))(__AMap_20,__AString_43,x1,__AScanner_8);
#line 56
  if(ISTGPRM(x2,1)){
#line 56
   COPY(__AScanner_8,1);
#line 56
   CPCLS(__AString_43,1);
#line 56
   CPCLS(__AMap_16,1);
#line 56
   r=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ))METHOD(__AMap_16,3))(__AMap_16,__AString_43,__AScanner_8,x1);
#line 56
  }else{
#line 56
   FREE(x1,1);
#line 56
   COPY(__AToken_2,1);
#line 57
   r=__AToken_2;}}
#line 57
 return r;}

static void ___AScanner_8()
{
 CPPRD(__AScanner_11,1);
 CPPRD(__AScanner_12,1);
 CPPRD(__AScanner_13,1);
 CPPRD(__AScanner_14,1);
 CPPRD(__AScanner_15,1);
 CPPRD(__AScanner_16,1);
 CPPRD(__AScanner_17,1);
 CPPRD(__AScanner_18,1);
 CPPRD(__AScanner_19,1);
 COPY(__AToken_4,1);
 COPY(__AToken_6,1);
 COPY(__AToken_8,1);
 COPY(__AToken_10,1);
 COPY(__AToken_12,1);
 COPY(__AToken_14,1);
 COPY(__AToken_16,1);
 COPY(__AToken_18,1);
 COPY(__AToken_20,1);
 CPCLS(__AString_43,10);
 CPCLS(__AString_49,9);
 CPCLS(__AMap_5,1);
 CPCLS(__AMap_6,9);
 {OBJ x1;OBJ x2;OBJ x3;OBJ x4;OBJ x5;OBJ x6;OBJ x7;OBJ x8;OBJ x9;OBJ x10;OBJ x11;OBJ x12;OBJ x13;OBJ x14;OBJ x15;OBJ x16;OBJ x17;OBJ x18;
#line 61
  x1=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_49,1))(__AString_49,__AScanner_11);
#line 62
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_49,1))(__AString_49,__AScanner_12);
#line 63
  x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_49,1))(__AString_49,__AScanner_13);
#line 64
  x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_49,1))(__AString_49,__AScanner_14);
#line 65
  x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_49,1))(__AString_49,__AScanner_15);
#line 66
  x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_49,1))(__AString_49,__AScanner_16);
#line 67
  x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_49,1))(__AString_49,__AScanner_17);
#line 68
  x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_49,1))(__AString_49,__AScanner_18);
#line 69
  x9=(*(OBJ(*)(OBJ,OBJ))METHOD(__AString_49,1))(__AString_49,__AScanner_19);
#line 70
  x10=(*(OBJ(*)(OBJ,OBJ))METHOD(__AMap_5,1))(__AMap_5,__AString_43);
#line 69
  x11=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AMap_6,4))(__AMap_6,__AString_43,x9,__AToken_4,x10);
#line 68
  x12=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AMap_6,4))(__AMap_6,__AString_43,x8,__AToken_6,x11);
#line 67
  x13=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AMap_6,4))(__AMap_6,__AString_43,x7,__AToken_16,x12);
#line 66
  x14=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AMap_6,4))(__AMap_6,__AString_43,x6,__AToken_8,x13);
#line 65
  x15=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AMap_6,4))(__AMap_6,__AString_43,x5,__AToken_10,x14);
#line 64
  x16=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AMap_6,4))(__AMap_6,__AString_43,x4,__AToken_18,x15);
#line 63
  x17=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AMap_6,4))(__AMap_6,__AString_43,x3,__AToken_20,x16);
#line 62
  x18=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AMap_6,4))(__AMap_6,__AString_43,x2,__AToken_12,x17);
#line 61
  __AScanner_8=(*(OBJ(*)(OBJ,OBJ,OBJ,OBJ,OBJ))METHOD(__AMap_6,4))(__AMap_6,__AString_43,x1,__AToken_14,x18);}}

static OBJ _mt_1_0_1(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 return r;}
static OBJ _mt_1_0_1_l(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 COPY(r,1);LZYCLS(t,r);
 return r;}

extern void init_AToken();
extern void init_ADenotation();
extern void init_ASeq();
extern void init_ANat();
extern void init_AOption();
extern void init_AChar();
extern void init_ASeqMap();
extern void init_AString();
extern void init_AStringFilter();
extern void init_ABool();
extern void init_ACompose();
extern void init_AMap();
extern void init_ASet();
extern void init_APair();
void init_AScanner()
{
 static int visited=0; if(visited) return; visited=1;
 init_AToken();
 init_ADenotation();
 init_ASeq();
 init_ANat();
 init_AOption();
 init_AChar();
 init_ASeqMap();
 init_AString();
 init_AStringFilter();
 init_ABool();
 init_ACompose();
 init_AMap();
 init_ASet();
 init_APair();
 DEN(")",__AScanner_19);
 DEN("(",__AScanner_18);
 DEN("not",__AScanner_17);
 DEN("F",__AScanner_16);
 DEN("T",__AScanner_15);
 DEN("and",__AScanner_14);
 DEN("or",__AScanner_13);
 DEN("equiv",__AScanner_12);
 DEN("impl",__AScanner_11);
 DEN(")",__AScanner_10);
 DEN("(",__AScanner_9);
 CLS(1,_AScanner_7,__AScanner_7);
 CLS(1,_AScanner_6,__AScanner_6);
 CLS(1,_AScanner_5,__AScanner_5);
 CLS(1,_AScanner_4,__AScanner_4);
 CLS(1,_AScanner_3,__AScanner_3);
 CLS(1,_AScanner_1,__AScanner_1);
 MTH(1,0,1,_mt_1_0_1);LZYMTH(1,0,1,_mt_1_0_1_l);
 ___AScanner_8();}

