

#line 1 "Token.impl"
#include "BUILTIN.h"
OBJ __AToken_2; /* error */
extern OBJ _AToken_3(OBJ);OBJ __AToken_3; /* error? */
OBJ __AToken_4; /* close */
extern OBJ _AToken_5(OBJ);OBJ __AToken_5; /* close? */
OBJ __AToken_6; /* open */
extern OBJ _AToken_7(OBJ);OBJ __AToken_7; /* open? */
OBJ __AToken_8; /* false */
extern OBJ _AToken_9(OBJ);OBJ __AToken_9; /* false? */
OBJ __AToken_10; /* true */
extern OBJ _AToken_11(OBJ);OBJ __AToken_11; /* true? */
OBJ __AToken_12; /* equiv */
extern OBJ _AToken_13(OBJ);OBJ __AToken_13; /* equiv? */
OBJ __AToken_14; /* impl */
extern OBJ _AToken_15(OBJ);OBJ __AToken_15; /* impl? */
OBJ __AToken_16; /* not */
extern OBJ _AToken_17(OBJ);OBJ __AToken_17; /* not? */
OBJ __AToken_18; /* and */
extern OBJ _AToken_19(OBJ);OBJ __AToken_19; /* and? */
OBJ __AToken_20; /* or */
extern OBJ _AToken_21(OBJ);OBJ __AToken_21; /* or? */
extern OBJ _AToken_22(OBJ);OBJ __AToken_22; /* ` */
OBJ __AToken_23; /* `'23 */
OBJ __AToken_24; /* `'24 */
OBJ __AToken_25; /* `'25 */
OBJ __AToken_26; /* `'26 */
OBJ __AToken_27; /* `'27 */
OBJ __AToken_28; /* `'28 */
OBJ __AToken_29; /* `'29 */
OBJ __AToken_30; /* `'30 */
OBJ __AToken_31; /* `'31 */
OBJ __AToken_32; /* `'32 */

extern OBJ _AToken_3(OBJ x1) /* error? */
{OBJ r;
#line 7
 if(ISTGPRM(x1,9)){
#line 7
  r=__ABUILTIN_5;
#line 7
 }else{
#line 7
  r=__ABUILTIN_3;}
#line 7
 return r;}

extern OBJ _AToken_5(OBJ x1) /* close? */
{OBJ r;
#line 6
 if(ISTGPRM(x1,8)){
#line 6
  r=__ABUILTIN_5;
#line 6
 }else{
#line 6
  r=__ABUILTIN_3;}
#line 6
 return r;}

extern OBJ _AToken_7(OBJ x1) /* open? */
{OBJ r;
#line 6
 if(ISTGPRM(x1,7)){
#line 6
  r=__ABUILTIN_5;
#line 6
 }else{
#line 6
  r=__ABUILTIN_3;}
#line 6
 return r;}

extern OBJ _AToken_9(OBJ x1) /* false? */
{OBJ r;
#line 6
 if(ISTGPRM(x1,6)){
#line 6
  r=__ABUILTIN_5;
#line 6
 }else{
#line 6
  r=__ABUILTIN_3;}
#line 6
 return r;}

extern OBJ _AToken_11(OBJ x1) /* true? */
{OBJ r;
#line 6
 if(ISTGPRM(x1,5)){
#line 6
  r=__ABUILTIN_5;
#line 6
 }else{
#line 6
  r=__ABUILTIN_3;}
#line 6
 return r;}

extern OBJ _AToken_13(OBJ x1) /* equiv? */
{OBJ r;
#line 6
 if(ISTGPRM(x1,4)){
#line 6
  r=__ABUILTIN_5;
#line 6
 }else{
#line 6
  r=__ABUILTIN_3;}
#line 6
 return r;}

extern OBJ _AToken_15(OBJ x1) /* impl? */
{OBJ r;
#line 6
 if(ISTGPRM(x1,3)){
#line 6
  r=__ABUILTIN_5;
#line 6
 }else{
#line 6
  r=__ABUILTIN_3;}
#line 6
 return r;}

extern OBJ _AToken_17(OBJ x1) /* not? */
{OBJ r;
#line 6
 if(ISTGPRM(x1,2)){
#line 6
  r=__ABUILTIN_5;
#line 6
 }else{
#line 6
  r=__ABUILTIN_3;}
#line 6
 return r;}

extern OBJ _AToken_19(OBJ x1) /* and? */
{OBJ r;
#line 6
 if(ISTGPRM(x1,1)){
#line 6
  r=__ABUILTIN_5;
#line 6
 }else{
#line 6
  r=__ABUILTIN_3;}
#line 6
 return r;}

extern OBJ _AToken_21(OBJ x1) /* or? */
{OBJ r;
#line 6
 if(ISTGPRM(x1,0)){
#line 6
  r=__ABUILTIN_5;
#line 6
 }else{
#line 6
  r=__ABUILTIN_3;}
#line 6
 return r;}

extern OBJ _AToken_22(OBJ x1) /* ` */
{OBJ r;
 CPCLS(__AToken_15,1);
#line 12
 {OBJ x2;
#line 12
  x2=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_15,1))(__AToken_15,x1);
#line 12
  if(ISTGPRM(x2,1)){
#line 12
   CPPRD(__AToken_32,1);
#line 12
   r=__AToken_32;
#line 12
  }else{
#line 12
   CPCLS(__AToken_11,1);
#line 12
   {OBJ x3;
#line 12
    x3=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_11,1))(__AToken_11,x1);
#line 12
    if(ISTGPRM(x3,1)){
#line 12
     CPPRD(__AToken_31,1);
#line 12
     r=__AToken_31;
#line 12
    }else{
#line 12
     CPCLS(__AToken_7,1);
#line 12
     {OBJ x4;
#line 12
      x4=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_7,1))(__AToken_7,x1);
#line 12
      if(ISTGPRM(x4,1)){
#line 12
       CPPRD(__AToken_30,1);
#line 12
       r=__AToken_30;
#line 12
      }else{
#line 12
       CPCLS(__AToken_5,1);
#line 12
       {OBJ x5;
#line 12
	x5=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_5,1))(__AToken_5,x1);
#line 12
	if(ISTGPRM(x5,1)){
#line 12
	 CPPRD(__AToken_29,1);
#line 12
	 r=__AToken_29;
#line 12
	}else{
#line 12
	 CPCLS(__AToken_3,1);
#line 12
	 {OBJ x6;
#line 12
	  x6=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_3,1))(__AToken_3,x1);
#line 12
	  if(ISTGPRM(x6,1)){
#line 12
	   CPPRD(__AToken_28,1);
#line 12
	   r=__AToken_28;
#line 12
	  }else{
#line 12
	   CPCLS(__AToken_9,1);
#line 12
	   {OBJ x7;
#line 12
	    x7=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_9,1))(__AToken_9,x1);
#line 12
	    if(ISTGPRM(x7,1)){
#line 12
	     CPPRD(__AToken_27,1);
#line 12
	     r=__AToken_27;
#line 12
	    }else{
#line 12
	     CPCLS(__AToken_13,1);
#line 12
	     {OBJ x8;
#line 12
	      x8=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_13,1))(__AToken_13,x1);
#line 12
	      if(ISTGPRM(x8,1)){
#line 12
	       CPPRD(__AToken_26,1);
#line 12
	       r=__AToken_26;
#line 12
	      }else{
#line 12
	       CPCLS(__AToken_19,1);
#line 12
	       {OBJ x9;
#line 12
		x9=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_19,1))(__AToken_19,x1);
#line 12
		if(ISTGPRM(x9,1)){
#line 12
		 CPPRD(__AToken_25,1);
#line 12
		 r=__AToken_25;
#line 12
		}else{
#line 12
		 CPCLS(__AToken_17,1);
#line 12
		 {OBJ x10;
#line 12
		  x10=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_17,1))(__AToken_17,x1);
#line 12
		  if(ISTGPRM(x10,1)){
#line 12
		   CPPRD(__AToken_24,1);
#line 12
		   r=__AToken_24;
#line 12
		  }else{
#line 12
		   CPCLS(__AToken_21,1);
#line 12
		   {OBJ x11;
#line 12
		    x11=(*(OBJ(*)(OBJ,OBJ))METHOD(__AToken_21,1))(__AToken_21,x1);
#line 12
		    if(ISTGPRM(x11,1)){
#line 12
		     CPPRD(__AToken_23,1);
#line 12
		     r=__AToken_23;
#line 12
		    }else{
#line 12
		     HLT("Token at <unknown> : missing else in `\'Token:token->denotation");}}}}}}}}}}}}}}}}}}}}
#line 12
 return r;}











static OBJ _mt_1_0_1(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 return r;}
static OBJ _mt_1_0_1_l(OBJ t,OBJ t1) 
{OBJ r;
 DCCLS(t,1);
 r=(*(OBJ(*)(OBJ))ENTRY(t))(t1);
 COPY(r,1);LZYCLS(t,r);
 return r;}

extern void init_ADenotation();
extern void init_ANat();
extern void init_AChar();
void init_AToken()
{
 static int visited=0; if(visited) return; visited=1;
 init_ADenotation();
 init_ANat();
 init_AChar();
 DEN("T",__AToken_31);
 DEN("(",__AToken_30);
 DEN(")",__AToken_29);
 DEN("Unknown input",__AToken_28);
 DEN("F",__AToken_27);
 DEN("equiv",__AToken_26);
 DEN("and",__AToken_25);
 DEN("not",__AToken_24);
 DEN("or",__AToken_23);
 CLS(1,_AToken_22,__AToken_22);
 CLS(1,_AToken_21,__AToken_21);
 CLS(1,_AToken_19,__AToken_19);
 CLS(1,_AToken_17,__AToken_17);
 CLS(1,_AToken_15,__AToken_15);
 CLS(1,_AToken_13,__AToken_13);
 CLS(1,_AToken_11,__AToken_11);
 CLS(1,_AToken_9,__AToken_9);
 CLS(1,_AToken_7,__AToken_7);
 CLS(1,_AToken_5,__AToken_5);
 CLS(1,_AToken_3,__AToken_3);
 DEN("impl",__AToken_32);
 MTH(1,0,1,_mt_1_0_1);LZYMTH(1,0,1,_mt_1_0_1_l);
 PRM(9,__AToken_2);
 PRM(8,__AToken_4);
 PRM(7,__AToken_6);
 PRM(6,__AToken_8);
 PRM(5,__AToken_10);
 PRM(4,__AToken_12);
 PRM(3,__AToken_14);
 PRM(2,__AToken_16);
 PRM(1,__AToken_18);
 PRM(0,__AToken_20);}

