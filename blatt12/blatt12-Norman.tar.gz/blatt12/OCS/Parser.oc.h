

#ifndef AParser_included
#define AParser_included

#define __AParser_Aeval __AParser_1
#define _AParser_Aeval _AParser_1
extern OBJ __AParser_Aeval;
extern OBJ _AParser_Aeval(OBJ);

#define __AParser_Afail __AParser_3
extern OBJ __AParser_Afail;

#define __AParser_Afail_ __AParser_4
#define _AParser_Afail_ _AParser_4
extern OBJ __AParser_Afail_;
extern OBJ _AParser_Afail_(OBJ);

#define __AParser_Afalse __AParser_5
extern OBJ __AParser_Afalse;

#define __AParser_Afalse_ __AParser_6
#define _AParser_Afalse_ _AParser_6
extern OBJ __AParser_Afalse_;
extern OBJ _AParser_Afalse_(OBJ);

#define __AParser_Atrue __AParser_7
extern OBJ __AParser_Atrue;

#define __AParser_Atrue_ __AParser_8
#define _AParser_Atrue_ _AParser_8
extern OBJ __AParser_Atrue_;
extern OBJ _AParser_Atrue_(OBJ);

#define __AParser_Afail_O1 __AParser_10
extern OBJ __AParser_Afail_O1;

#define __AParser_Afail__O1 __AParser_11
#define _AParser_Afail__O1 _AParser_11
extern OBJ __AParser_Afail__O1;
extern OBJ _AParser_Afail__O1(OBJ);

#define __AParser_Aequiv __AParser_12
extern OBJ __AParser_Aequiv;

#define __AParser_Aequiv_ __AParser_13
#define _AParser_Aequiv_ _AParser_13
extern OBJ __AParser_Aequiv_;
extern OBJ _AParser_Aequiv_(OBJ);

#define __AParser_Aimpl __AParser_14
extern OBJ __AParser_Aimpl;

#define __AParser_Aimpl_ __AParser_15
#define _AParser_Aimpl_ _AParser_15
extern OBJ __AParser_Aimpl_;
extern OBJ _AParser_Aimpl_(OBJ);

#define __AParser_Aor __AParser_16
extern OBJ __AParser_Aor;

#define __AParser_Aor_ __AParser_17
#define _AParser_Aor_ _AParser_17
extern OBJ __AParser_Aor_;
extern OBJ _AParser_Aor_(OBJ);

#define __AParser_Aand __AParser_18
extern OBJ __AParser_Aand;

#define __AParser_Aand_ __AParser_19
#define _AParser_Aand_ _AParser_19
extern OBJ __AParser_Aand_;
extern OBJ _AParser_Aand_(OBJ);

#define __AParser_Afail_O2 __AParser_21
extern OBJ __AParser_Afail_O2;

#define __AParser_Afail__O2 __AParser_22
#define _AParser_Afail__O2 _AParser_22
extern OBJ __AParser_Afail__O2;
extern OBJ _AParser_Afail__O2(OBJ);

#define __AParser_AbinOp __AParser_23
#define _AParser_AbinOp _AParser_23
extern OBJ __AParser_AbinOp;
extern OBJ _AParser_AbinOp(OBJ,OBJ,OBJ);

#define __AParser_AbinOp_ __AParser_24
#define _AParser_AbinOp_ _AParser_24
extern OBJ __AParser_AbinOp_;
extern OBJ _AParser_AbinOp_(OBJ);

#define __AParser_Aright __AParser_25
#define _AParser_Aright _AParser_25
extern OBJ __AParser_Aright;
extern OBJ _AParser_Aright(OBJ);

#define __AParser_Aleft __AParser_26
#define _AParser_Aleft _AParser_26
extern OBJ __AParser_Aleft;
extern OBJ _AParser_Aleft(OBJ);

#define __AParser_Aop __AParser_27
#define _AParser_Aop _AParser_27
extern OBJ __AParser_Aop;
extern OBJ _AParser_Aop(OBJ);

#define __AParser_Anot __AParser_28
#define _AParser_Anot _AParser_28
extern OBJ __AParser_Anot;
extern OBJ _AParser_Anot(OBJ);

#define __AParser_Anot_ __AParser_29
#define _AParser_Anot_ _AParser_29
extern OBJ __AParser_Anot_;
extern OBJ _AParser_Anot_(OBJ);

#define __AParser_Aarg __AParser_30
#define _AParser_Aarg _AParser_30
extern OBJ __AParser_Aarg;
extern OBJ _AParser_Aarg(OBJ);

#define __AParser_AboolLit __AParser_31
#define _AParser_AboolLit _AParser_31
extern OBJ __AParser_AboolLit;
extern OBJ _AParser_AboolLit(OBJ);

#define __AParser_AboolLit_ __AParser_32
#define _AParser_AboolLit_ _AParser_32
extern OBJ __AParser_AboolLit_;
extern OBJ _AParser_AboolLit_(OBJ);

#define __AParser_Avalue __AParser_33
#define _AParser_Avalue _AParser_33
extern OBJ __AParser_Avalue;
extern OBJ _AParser_Avalue(OBJ);

#define __AParser_Aerror_ __AParser_34
#define _AParser_Aerror_ _AParser_34
extern OBJ __AParser_Aerror_;
extern OBJ _AParser_Aerror_(OBJ);

#define __AParser_Aparse __AParser_35
#define _AParser_Aparse _AParser_35
extern OBJ __AParser_Aparse;
extern OBJ _AParser_Aparse(OBJ);

#define __AParser_AparseExpr __AParser_36
#define _AParser_AparseExpr _AParser_36
extern OBJ __AParser_AparseExpr;
extern TUP2 _AParser_AparseExpr(OBJ);

#define __AParser_AparseClose __AParser_37
#define _AParser_AparseClose _AParser_37
extern OBJ __AParser_AparseClose;
extern OBJ _AParser_AparseClose(OBJ);

#define __AParser_AparseBinOp __AParser_38
#define _AParser_AparseBinOp _AParser_38
extern OBJ __AParser_AparseBinOp;
extern TUP2 _AParser_AparseBinOp(OBJ);

#define __AParser_AevalExpr __AParser_39
#define _AParser_AevalExpr _AParser_39
extern OBJ __AParser_AevalExpr;
extern OBJ _AParser_AevalExpr(OBJ);

#define __AParser_Sq __AParser_40
#define _AParser_Sq _AParser_40
extern OBJ __AParser_Sq;
extern OBJ _AParser_Sq(OBJ);

#ifndef AParser_Aeval
#define AParser_Aeval(x1,x5) {x5=_AParser_Aeval(x1);}
#endif

#ifndef AParser_Afail_
#define AParser_Afail_(x1,x2) {x2=_AParser_Afail_(x1);}
#endif

#ifndef AParser_Afalse_
#define AParser_Afalse_(x1,x2) {x2=_AParser_Afalse_(x1);}
#endif

#ifndef AParser_Atrue_
#define AParser_Atrue_(x1,x2) {x2=_AParser_Atrue_(x1);}
#endif

#ifndef AParser_Afail__O1
#define AParser_Afail__O1(x1,x2) {x2=_AParser_Afail__O1(x1);}
#endif

#ifndef AParser_Aequiv_
#define AParser_Aequiv_(x1,x2) {x2=_AParser_Aequiv_(x1);}
#endif

#ifndef AParser_Aimpl_
#define AParser_Aimpl_(x1,x2) {x2=_AParser_Aimpl_(x1);}
#endif

#ifndef AParser_Aor_
#define AParser_Aor_(x1,x2) {x2=_AParser_Aor_(x1);}
#endif

#ifndef AParser_Aand_
#define AParser_Aand_(x1,x2) {x2=_AParser_Aand_(x1);}
#endif

#ifndef AParser_Afail__O2
#define AParser_Afail__O2(x1,x2) {x2=_AParser_Afail__O2(x1);}
#endif

#ifndef AParser_AbinOp
#define AParser_AbinOp(x1,x2,x3,x4) {x4=_AParser_AbinOp(x1,x2,x3);}
#endif

#ifndef AParser_AbinOp_
#define AParser_AbinOp_(x1,x5) {x5=_AParser_AbinOp_(x1);}
#endif

#ifndef AParser_Aright
#define AParser_Aright(x1,x5) {x5=_AParser_Aright(x1);}
#endif

#ifndef AParser_Aleft
#define AParser_Aleft(x1,x5) {x5=_AParser_Aleft(x1);}
#endif

#ifndef AParser_Aop
#define AParser_Aop(x1,x5) {x5=_AParser_Aop(x1);}
#endif

#ifndef AParser_Anot
#define AParser_Anot(x1,x2) {x2=_AParser_Anot(x1);}
#endif

#ifndef AParser_Anot_
#define AParser_Anot_(x1,x3) {x3=_AParser_Anot_(x1);}
#endif

#ifndef AParser_Aarg
#define AParser_Aarg(x1,x3) {x3=_AParser_Aarg(x1);}
#endif

#ifndef AParser_AboolLit
#define AParser_AboolLit(x1,x2) {x2=_AParser_AboolLit(x1);}
#endif

#ifndef AParser_AboolLit_
#define AParser_AboolLit_(x1,x3) {x3=_AParser_AboolLit_(x1);}
#endif

#ifndef AParser_Avalue
#define AParser_Avalue(x1,x3) {x3=_AParser_Avalue(x1);}
#endif

#ifndef AParser_Aerror_
#define AParser_Aerror_(x1,x5) {x5=_AParser_Aerror_(x1);}
#endif

#ifndef AParser_Aparse
#define AParser_Aparse(x1,x10) {x10=_AParser_Aparse(x1);}
#endif

#ifndef AParser_AparseExpr
#define AParser_AparseExpr(x1,x32,x33) {TUP2 t;t=_AParser_AparseExpr(x1);x32=t.c1;x33=t.c2;}
#endif

#ifndef AParser_AparseClose
#define AParser_AparseClose(x1,x5) {x5=_AParser_AparseClose(x1);}
#endif

#ifndef AParser_AparseBinOp
#define AParser_AparseBinOp(x1,x14,x15) {TUP2 t;t=_AParser_AparseBinOp(x1);x14=t.c1;x15=t.c2;}
#endif

#ifndef AParser_AevalExpr
#define AParser_AevalExpr(x1,x31) {x31=_AParser_AevalExpr(x1);}
#endif

#ifndef AParser_Sq
#define AParser_Sq(x1,x46) {x46=_AParser_Sq(x1);}
#endif

#endif
